import type { Role, UserStatus } from "@/types";

export interface Actor {
  uid: string;
  role: Role;
  status: UserStatus;
}

export const isActive = (a: Actor) => a.status === "active";
export const isAdmin = (a: Actor) => a.role === "admin" && isActive(a);
export const isOwnerOf = (a: Actor, resource: { ownerId: string }) => isActive(a) && resource.ownerId === a.uid;
export const canManageResource = (a: Actor, resource: { ownerId: string }) => isAdmin(a) || isOwnerOf(a, resource);
/** Admin tidak boleh menyetujui transaksinya sendiri. */
export const canDecideTransaction = (a: Actor, tx: { ownerId: string }) => isAdmin(a) && tx.ownerId !== a.uid;
