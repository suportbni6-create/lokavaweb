import type { PlanDoc, SubscriptionDoc } from "@/types";

export type LimitKind = "businessPhotos" | "products" | "productPhotos" | "promotions";

export interface PlanLimits {
  maxBusinessPhotos: number;
  maxProducts: number;
  maxProductPhotos: number;
  maxPromotions: number;
}

export type PlanLike = Pick<PlanDoc, "id" | "name" | "features" | "price" | "durationDays"> & PlanLimits;

export function limitsOf(plan: PlanLimits): PlanLimits {
  return {
    maxBusinessPhotos: plan.maxBusinessPhotos,
    maxProducts: plan.maxProducts,
    maxProductPhotos: plan.maxProductPhotos,
    maxPromotions: plan.maxPromotions,
  };
}

const KEY: Record<LimitKind, keyof PlanLimits> = {
  businessPhotos: "maxBusinessPhotos",
  products: "maxProducts",
  productPhotos: "maxProductPhotos",
  promotions: "maxPromotions",
};

/** true jika jumlah `wanted` masih di dalam batas. */
export function withinLimit(limits: PlanLimits, kind: LimitKind, wanted: number): boolean {
  return wanted <= limits[KEY[kind]];
}

export function limitMessage(kind: LimitKind, max: number): string {
  const label = {
    businessPhotos: "foto bisnis",
    products: "produk",
    productPhotos: "foto per produk",
    promotions: "promosi aktif",
  }[kind];
  return `Batas paket Anda untuk ${label} adalah ${max}. Tingkatkan paket untuk menambah.`;
}

/**
 * Paket efektif: langganan aktif dan belum berakhir dipakai; jika kedaluwarsa jatuh ke
 * paket gratis tanpa menghapus data pemilik.
 */
export function resolveEffectivePlan(
  subscription: Pick<SubscriptionDoc, "status" | "expiresAt" | "planSnapshot"> | null,
  freePlan: PlanLike,
  now = new Date(),
): { plan: PlanLike; expired: boolean } {
  if (!subscription) return { plan: freePlan, expired: false };
  const expired =
    subscription.status !== "active" ||
    (subscription.expiresAt !== null && new Date(subscription.expiresAt).getTime() <= now.getTime());
  if (expired) return { plan: freePlan, expired: subscription.expiresAt !== null };
  return { plan: subscription.planSnapshot as PlanLike, expired: false };
}
