import "server-only";
import { db, now } from "@/lib/firebase/admin";

export async function audit(entry: {
  actorId: string;
  action: string;
  targetType: string;
  targetId: string;
  summary: string;
  result?: "success" | "failure";
}) {
  try {
    await db()
      .collection("auditLogs")
      .add({ ...entry, result: entry.result ?? "success", timestamp: now() });
  } catch (e) {
    console.error("[audit] gagal menulis log:", (e as Error).message);
  }
}
