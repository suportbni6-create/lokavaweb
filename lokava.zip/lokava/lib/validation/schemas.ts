import { z } from "zod";
import { normalizeWhatsapp } from "@/lib/utils/whatsapp";

const text = (max: number, min = 0) => z.string().trim().min(min).max(max);
export const imageSchema = z.object({ url: z.string().url().max(500), publicId: z.string().min(3).max(300) });

export const whatsappField = z
  .string()
  .trim()
  .transform((v, ctx) => {
    const n = normalizeWhatsapp(v);
    if (!n) ctx.addIssue({ code: "custom", message: "Nomor WhatsApp tidak valid. Contoh: 0812 3456 7890" });
    return n as string;
  });

export const registerSchema = z.object({
  idToken: z.string().min(20),
  displayName: text(80, 2),
  phone: z.string().trim().max(20).optional(),
});

export const sessionSchema = z.object({ idToken: z.string().min(20) });

const hourSchema = z.object({
  day: z.enum(["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"]),
  open: z.string().regex(/^\d{2}:\d{2}$/),
  close: z.string().regex(/^\d{2}:\d{2}$/),
  closed: z.boolean(),
});

const coord = (min: number, max: number) =>
  z
    .union([z.number(), z.string().trim().length(0), z.null()])
    .transform((v) => (typeof v === "number" ? v : null))
    .refine((v) => v === null || (v >= min && v <= max), "Koordinat di luar jangkauan.");

export const businessSchema = z.object({
  name: text(100, 3),
  description: text(2000, 20),
  categoryIds: z.array(z.string().min(1)).min(1, "Pilih minimal satu kategori.").max(5),
  address: text(300, 5),
  village: text(100, 2),
  district: text(100, 2),
  region: text(100, 2),
  latitude: coord(-90, 90).default(null),
  longitude: coord(-180, 180).default(null),
  whatsapp: whatsappField,
  publicContact: z.boolean().default(true),
  openingHours: z.array(hourSchema).max(7).default([]),
  coverImage: imageSchema.nullable(),
  gallery: z.array(imageSchema).max(30).default([]),
  submit: z.boolean().default(false), // true = ajukan untuk verifikasi
});
export type BusinessInput = z.infer<typeof businessSchema>;

export const productSchema = z.object({
  businessId: z.string().min(1),
  name: text(120, 2),
  description: text(1500),
  price: z.number().int().min(0).max(1_000_000_000),
  categoryId: z.string().nullable().default(null),
  kind: z.enum(["produk", "menu", "layanan", "kamar"]).default("produk"),
  availability: z.enum(["tersedia", "habis", "pesan_dulu"]).default("tersedia"),
  images: z.array(imageSchema).max(20).default([]),
  status: z.enum(["active", "inactive"]).default("active"),
});
export type ProductInput = z.infer<typeof productSchema>;

export const subscriptionTxSchema = z.object({
  businessId: z.string().min(1),
  planId: z.string().min(1),
  paymentMethodId: z.string().min(1),
});

export const promotionTxSchema = z.object({
  businessId: z.string().min(1),
  promotionTypeId: z.string().min(1),
  durationDays: z.number().int().min(1).max(365),
  productId: z.string().nullable().default(null),
  categoryId: z.string().nullable().default(null),
  bannerImage: imageSchema.nullable().default(null),
  paymentMethodId: z.string().min(1),
});

export const proofSchema = z.object({
  publicId: z.string().min(3).max(300),
  note: text(500).optional(),
});

export const decisionSchema = z.object({
  decision: z.enum(["approve", "reject", "correction"]),
  reason: text(500).optional(),
});

export const uploadSignSchema = z.object({
  purpose: z.enum(["business", "product", "proof", "promotion", "admin"]),
});

export const deleteAccountSchema = z.object({ confirm: z.literal("HAPUS AKUN SAYA") });

export const userStatusSchema = z.object({ status: z.enum(["active", "suspended"]), reason: text(300).optional() });

export const settingsSchema = z.object({
  appName: text(40, 2),
  tagline: text(120),
  description: text(500),
  logo: imageSchema.nullable(),
  contactEmail: z.union([z.string().email(), z.literal("")]),
  contactWhatsapp: z.union([whatsappField, z.literal("")]),
  footerContent: text(300),
  defaultRegion: text(100),
  seoTitle: text(70),
  seoDescription: text(170),
  privacyPolicy: text(8000),
  termsOfUse: text(8000),
  installPopupEnabled: z.boolean(),
  pwaThemeColor: z.string().regex(/^#[0-9a-fA-F]{6}$/),
  reverifyOnSensitiveChange: z.boolean().default(false),
});

export const telegramSettingsSchema = z.object({
  enabled: z.boolean(),
  destinationChatId: z.string().trim().max(40),
  allowedAdminIds: z.array(z.string().regex(/^\d{3,15}$/, "ID Telegram berupa angka.")).max(20),
  verificationMode: z.enum(["manual", "assisted", "auto"]),
  notifications: z.object({ business: z.boolean(), payment: z.boolean(), decisions: z.boolean(), errors: z.boolean() }),
  botToken: z.string().trim().max(200).optional(), // opsional, hanya untuk memperbarui
});

// ===== Koleksi admin generik =====
const baseAdmin = { active: z.boolean().default(true), sortOrder: z.number().int().min(0).max(9999).default(0) };
const optImage = imageSchema.nullable().default(null);

export const adminCollections = {
  categories: z.object({
    name: text(60, 2),
    slug: text(80).optional(),
    description: text(300).default(""),
    icon: text(8).default("📍"),
    group: z.enum(["wisata", "kuliner", "penginapan", "umkm", "jasa"]),
    image: optImage,
    ...baseAdmin,
  }),
  plans: z.object({
    name: text(40, 2),
    description: text(300).default(""),
    price: z.number().int().min(0).max(100_000_000),
    durationDays: z.number().int().min(0).max(3650),
    maxBusinessPhotos: z.number().int().min(0).max(500),
    maxProducts: z.number().int().min(0).max(100000),
    maxProductPhotos: z.number().int().min(0).max(50),
    maxPromotions: z.number().int().min(0).max(100),
    features: z.array(text(120)).max(20).default([]),
    ...baseAdmin,
  }),
  promotionTypes: z.object({
    kind: z.enum(["product", "category", "featured_business", "home_banner"]),
    name: text(60, 2),
    description: text(300).default(""),
    basePrice: z.number().int().min(0).max(100_000_000),
    baseDays: z.number().int().min(1).max(365).default(7),
    durations: z.array(z.number().int().min(1).max(365)).min(1).max(12),
    durationPrices: z.record(z.string(), z.number().int().min(0)).optional(),
    slotLimit: z.number().int().min(0).max(1000).default(0),
    requirements: z.object({ minPlanSortOrder: z.number().int().min(0).optional() }).default({}),
    active: z.boolean().default(true),
  }),
  paymentMethods: z.object({
    name: text(60, 2),
    provider: text(60),
    accountName: text(100),
    accountNumber: text(60).default(""),
    instructions: text(1000).default(""),
    qrImage: optImage,
    ...baseAdmin,
  }),
  banners: z.object({
    title: text(100, 2),
    image: imageSchema,
    targetUrl: z.string().max(300).regex(/^(\/|https:\/\/)/, "Tautan harus diawali / atau https://"),
    startsAt: z.string().datetime().nullable().default(null),
    expiresAt: z.string().datetime().nullable().default(null),
    active: z.boolean().default(true),
    sortOrder: z.number().int().min(0).default(0),
  }),
  destinations: z.object({
    name: text(120, 2),
    description: text(3000, 10),
    categoryIds: z.array(z.string()).max(5).default([]),
    address: text(300).default(""),
    district: text(100, 2),
    region: text(100, 2),
    latitude: coord(-90, 90).default(null),
    longitude: coord(-180, 180).default(null),
    accessInfo: text(1000).default(""),
    openingHours: text(300).default(""),
    ticketPrice: z.number().int().min(0).nullable().default(null),
    facilities: z.array(text(60)).max(30).default([]),
    contact: text(100).default(""),
    directions: text(1000).default(""),
    coverImage: optImage,
    gallery: z.array(imageSchema).max(30).default([]),
    verified: z.boolean().default(false),
    featured: z.boolean().default(false),
    active: z.boolean().default(true),
  }),
  regions: z.object({ name: text(100, 2), district: text(100, 2), ...baseAdmin }),
} as const;

export type AdminCollection = keyof typeof adminCollections;
export const isAdminCollection = (v: string): v is AdminCollection => v in adminCollections;
