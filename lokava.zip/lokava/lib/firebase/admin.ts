import "server-only";
import { cert, getApps, initializeApp, type App } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { Timestamp, getFirestore } from "firebase-admin/firestore";
import { serverEnv } from "@/lib/env";

function app(): App {
  if (getApps().length) return getApps()[0]!;
  const env = serverEnv();
  return initializeApp({
    credential: cert({
      projectId: env.FIREBASE_ADMIN_PROJECT_ID,
      clientEmail: env.FIREBASE_ADMIN_CLIENT_EMAIL,
      privateKey: env.FIREBASE_ADMIN_PRIVATE_KEY.replace(/\\n/g, "\n"),
    }),
  });
}

export const adminAuth = () => getAuth(app());
export const db = () => {
  const f = getFirestore(app());
  return f;
};

/** Ubah Timestamp Firestore menjadi string ISO secara rekursif agar aman dikirim ke klien. */
export function plain<T = Record<string, unknown>>(value: unknown): T {
  if (value instanceof Timestamp) return value.toDate().toISOString() as unknown as T;
  if (Array.isArray(value)) return value.map((v) => plain(v)) as unknown as T;
  if (value && typeof value === "object") {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value)) out[k] = plain(v);
    return out as T;
  }
  return value as T;
}

export function docPlain<T>(snap: FirebaseFirestore.DocumentSnapshot): T | null {
  if (!snap.exists) return null;
  return { id: snap.id, ...plain<Record<string, unknown>>(snap.data()) } as unknown as T;
}

export { Timestamp };
export const now = () => Timestamp.now();
export const ts = (d: Date) => Timestamp.fromDate(d);
