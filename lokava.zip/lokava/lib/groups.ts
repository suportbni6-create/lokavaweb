import type { CategoryDoc } from "@/types";
export const idsOfGroup = (cats: CategoryDoc[], group: CategoryDoc["group"]) => cats.filter((c) => c.group === group).map((c) => c.id);
