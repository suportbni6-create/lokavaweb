import "server-only";
import { NextResponse } from "next/server";
import { ZodError, type ZodTypeAny, type z } from "zod";
import { HttpError } from "@/lib/auth/session";
import { PricingError } from "@/lib/payments/pricing";

export function json(data: unknown, init?: number | ResponseInit) {
  const res = NextResponse.json(data, typeof init === "number" ? { status: init } : init);
  res.headers.set("Cache-Control", "no-store");
  return res;
}

export function handleError(e: unknown) {
  if (e instanceof HttpError) return json({ error: e.message }, e.status);
  if (e instanceof PricingError) return json({ error: e.message }, 400);
  if (e instanceof ZodError) {
    return json({ error: e.issues[0]?.message ?? "Data tidak valid.", fields: e.flatten().fieldErrors }, 400);
  }
  // Jangan membocorkan detail internal ke klien dan jangan mencetak rahasia.
  console.error("[api]", e instanceof Error ? e.message : "kesalahan tidak dikenal");
  return json({ error: "Terjadi kesalahan di server. Coba lagi beberapa saat." }, 500);
}

export async function parseBody<S extends ZodTypeAny>(req: Request, schema: S): Promise<z.infer<S>> {
  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    throw new HttpError(400, "Isi permintaan harus berupa JSON.");
  }
  return schema.parse(raw);
}

/** Pembatas laju sederhana per instance (best-effort). Untuk skala besar gunakan penyimpanan terpusat. */
const buckets = new Map<string, { count: number; reset: number }>();
export function rateLimit(key: string, limit: number, windowMs: number) {
  const now = Date.now();
  const b = buckets.get(key);
  if (!b || b.reset < now) {
    buckets.set(key, { count: 1, reset: now + windowMs });
    return;
  }
  b.count += 1;
  if (b.count > limit) throw new HttpError(429, "Terlalu banyak permintaan. Coba lagi sebentar lagi.");
  if (buckets.size > 5000) for (const [k, v] of buckets) if (v.reset < now) buckets.delete(k);
}

export function clientIp(req: Request): string {
  return req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
}
