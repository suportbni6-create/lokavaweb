import "server-only";
import { FieldValue } from "firebase-admin/firestore";
import { adminAuth, db, now, ts } from "@/lib/firebase/admin";
import { deleteAssets, deleteByPrefix } from "@/lib/cloudinary";
import { syncOwnerBusinesses } from "@/lib/data/business-core";
import { audit } from "@/lib/audit";
import { addDays } from "@/lib/payments/pricing";
import { sendToAdmins, esc } from "@/lib/telegram";

type StepName = "hide" | "promotions" | "products" | "businesses" | "assets" | "transactions" | "profile" | "auth";
const STEPS: StepName[] = ["hide", "promotions", "products", "businesses", "assets", "transactions", "profile", "auth"];

/** Langkah 1-7 alur penghapusan: sembunyikan konten publik SEGERA, lalu catat permintaan agar dapat dilanjutkan. */
export async function requestAccountDeletion(uid: string) {
  const userRef = db().collection("users").doc(uid);
  const existing = await db().collection("deletionRequests").where("userId", "==", uid).where("status", "in", ["requested", "processing", "failed"]).limit(1).get();
  if (!existing.empty) return { id: existing.docs[0]!.id, alreadyRequested: true };

  const biz = await db().collection("businesses").where("ownerId", "==", uid).get();
  const stamp = now();
  const reqRef = db().collection("deletionRequests").doc();
  await userRef.update({ status: "deletion_requested", deletionRequestedAt: stamp, updatedAt: stamp });
  await reqRef.set({
    userId: uid, businessIds: biz.docs.map((d) => d.id), status: "requested", requestedAt: stamp,
    processingStartedAt: null, completedAt: null, failureReason: null,
    steps: Object.fromEntries(STEPS.map((s) => [s, s === "hide" ? "done" : "pending"])),
    retentionNotes: "Catatan transaksi keuangan dipertahankan selama masa retensi dengan data pribadi diminimalkan.",
  });
  await syncOwnerBusinesses(uid); // konten publik hilang seketika (visible=false)
  await audit({ actorId: uid, action: "account.deletion_requested", targetType: "user", targetId: uid, summary: "Pemilik meminta penghapusan akun" });
  await sendToAdmins("decisions", `🗑️ Permintaan penghapusan akun\nUID: <code>${esc(uid)}</code>`);
  return { id: reqRef.id, alreadyRequested: false };
}

async function mark(reqId: string, step: StepName, state: "done" | "failed") {
  await db().collection("deletionRequests").doc(reqId).update({ [`steps.${step}`]: state });
}

/** Dapat dijalankan ulang dengan aman (idempoten). Setiap langkah yang sudah selesai dilewati. */
export async function processDeletion(reqId: string) {
  const ref = db().collection("deletionRequests").doc(reqId);
  const snap = await ref.get();
  if (!snap.exists) return { ok: false, error: "Permintaan tidak ditemukan." };
  const req = snap.data()!;
  if (req.status === "completed") return { ok: true };
  const uid = req.userId as string;
  await ref.update({ status: "processing", processingStartedAt: req.processingStartedAt ?? now(), failureReason: null });
  const steps = { ...(req.steps as Record<StepName, string>) };

  const run = async (name: StepName, fn: () => Promise<void>) => {
    if (steps[name] === "done") return;
    await fn();
    steps[name] = "done";
    await mark(reqId, name, "done");
  };

  try {
    await run("promotions", async () => {
      const s = await db().collection("promotions").where("ownerId", "==", uid).where("status", "in", ["active", "under_review", "pending_payment"]).get();
      for (const d of s.docs) await d.ref.update({ status: "cancelled", updatedAt: now() });
      for (const d of (await db().collection("banners").where("promotionId", "in", s.docs.length ? s.docs.map((x) => x.id).slice(0, 30) : ["_"]).get()).docs) await d.ref.delete();
    });
    await run("products", async () => {
      const s = await db().collection("products").where("ownerId", "==", uid).get();
      let batch = db().batch(); let n = 0;
      for (const d of s.docs) { batch.delete(d.ref); if (++n % 400 === 0) { await batch.commit(); batch = db().batch(); } }
      await batch.commit();
    });
    await run("businesses", async () => {
      const s = await db().collection("businesses").where("ownerId", "==", uid).get();
      for (const d of s.docs) await d.ref.delete();
      const subs = await db().collection("subscriptions").where("ownerId", "==", uid).get();
      for (const d of subs.docs) await d.ref.delete();
    });
    await run("assets", async () => {
      // Hanya folder milik uid ini; aset bersama/sistem (lokava/admin) tidak tersentuh.
      for (const p of ["business", "product", "promotion"]) await deleteByPrefix(`lokava/${p}/${uid}/`);
    });
    await run("transactions", async () => {
      // Catatan keuangan dipertahankan sampai masa retensi, data pribadi diminimalkan.
      const s = await db().collection("transactions").where("ownerId", "==", uid).get();
      for (const d of s.docs) {
        await d.ref.update({ ownerName: "Pengguna terhapus", businessName: "Bisnis terhapus", proofNote: null, ownerDeleted: true, updatedAt: now(),
          retentionUntil: d.data().retentionUntil ?? ts(addDays(new Date(), 1825)) });
      }
    });
    await run("profile", async () => {
      await db().collection("users").doc(uid).set({ uid, status: "deleted", role: "owner", email: FieldValue.delete(), displayName: "Pengguna terhapus", phone: FieldValue.delete(), updatedAt: now(), deletedAt: now() }, { merge: true });
    });
    await run("auth", async () => {
      try { await adminAuth().deleteUser(uid); } catch (e) { if ((e as { code?: string }).code !== "auth/user-not-found") throw e; }
    });
    await ref.update({ status: "completed", completedAt: now() });
    await audit({ actorId: "system", action: "account.deleted", targetType: "user", targetId: uid, summary: "Penghapusan akun selesai" });
    return { ok: true };
  } catch (e) {
    await ref.update({ status: "failed", failureReason: (e as Error).message.slice(0, 300) });
    await audit({ actorId: "system", action: "account.deletion_failed", targetType: "user", targetId: uid, summary: "Penghapusan akun gagal sebagian, akan dicoba ulang", result: "failure" });
    return { ok: false, error: "Sebagian langkah gagal; akan dilanjutkan otomatis." };
  }
}
export { deleteAssets };
