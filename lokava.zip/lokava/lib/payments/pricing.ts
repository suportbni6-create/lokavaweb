import type { PlanDoc, PromotionTypeDoc } from "@/types";

/** Harga paket SELALU dihitung dari konfigurasi server. */
export function planCharge(plan: Pick<PlanDoc, "price" | "durationDays">) {
  return { amount: plan.price, durationDays: plan.durationDays };
}

export class PricingError extends Error {}

export function promotionCharge(
  type: Pick<PromotionTypeDoc, "basePrice" | "baseDays" | "durations" | "durationPrices" | "active">,
  days: number,
): { amount: number; durationDays: number } {
  if (!type.active) throw new PricingError("Jenis promosi sedang tidak tersedia.");
  if (!Number.isInteger(days) || !type.durations.includes(days)) throw new PricingError("Durasi promosi tidak tersedia.");
  const override = type.durationPrices?.[String(days)];
  const amount = typeof override === "number" ? override : Math.round((type.basePrice * days) / Math.max(type.baseDays, 1));
  if (amount < 0) throw new PricingError("Harga tidak valid.");
  return { amount, durationDays: days };
}

export function addDays(from: Date, days: number): Date {
  return new Date(from.getTime() + days * 86_400_000);
}

const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
export function generateTransactionNumber(now = new Date(), rand: () => number = Math.random): string {
  const ymd = now.toISOString().slice(0, 10).replace(/-/g, "");
  let code = "";
  for (let i = 0; i < 6; i++) code += ALPHABET[Math.floor(rand() * ALPHABET.length)];
  return `LKV-${ymd}-${code}`;
}
