import "server-only";
import { FieldValue } from "firebase-admin/firestore";
import { db, docPlain, now, ts } from "@/lib/firebase/admin";
import { HttpError } from "@/lib/auth/session";
import { audit } from "@/lib/audit";
import { addDays, generateTransactionNumber, planCharge, promotionCharge } from "@/lib/payments/pricing";
import { assertOwnedAssets, verifyAssets } from "@/lib/cloudinary";
import { getEffectivePlan } from "@/lib/data/business-core";
import { withinLimit, limitsOf, limitMessage } from "@/lib/permissions/limits";
import { dashboardLink, esc, sendToAdmins } from "@/lib/telegram";
import { formatRupiah } from "@/lib/utils/format";
import type {
  BusinessDoc, PaymentMethodDoc, PlanDoc, PromotionDoc, PromotionTypeDoc, SessionUser, TransactionDoc, TransactionStatus,
} from "@/types";

const OPEN: TransactionStatus[] = ["pending_payment", "proof_submitted", "under_review"];
const PAYMENT_WINDOW_DAYS = 3;
export const TRANSACTION_RETENTION_DAYS = 1825; // 5 tahun; sesuaikan dengan kebijakan hukum/akuntansi Anda
const MAX_PROOF_ATTEMPTS = 5;

async function ownedApprovedBusiness(uid: string, businessId: string) {
  const snap = await db().collection("businesses").doc(businessId).get();
  const b = docPlain<BusinessDoc>(snap);
  if (!b || b.ownerId !== uid || b.deletedAt) throw new HttpError(404, "Bisnis tidak ditemukan.");
  if (b.verificationStatus !== "approved") throw new HttpError(409, "Bisnis harus disetujui terlebih dahulu.");
  return b;
}

async function activePaymentMethod(id: string) {
  const pm = docPlain<PaymentMethodDoc>(await db().collection("paymentMethods").doc(id).get());
  if (!pm || !pm.active) throw new HttpError(400, "Metode pembayaran tidak tersedia.");
  return pm;
}

async function assertNoOpenTransaction(uid: string, businessId: string, type: "subscription" | "promotion", match: (t: TransactionDoc) => boolean) {
  const recent = await db().collection("transactions").where("ownerId", "==", uid).orderBy("createdAt", "desc").limit(50).get();
  const open = recent.docs
    .map((d) => docPlain<TransactionDoc>(d)!)
    .find((t) => t.businessId === businessId && t.type === type && OPEN.includes(t.status) && new Date(t.expiresAt) > new Date() && match(t));
  if (open) throw new HttpError(409, `Masih ada transaksi berjalan (${open.transactionNumber}). Selesaikan atau tunggu hingga kedaluwarsa.`);
}

function baseTx(user: SessionUser, business: BusinessDoc, pm: PaymentMethodDoc | null) {
  const created = new Date();
  return {
    transactionNumber: generateTransactionNumber(created),
    ownerId: user.uid,
    ownerName: user.displayName,
    businessId: business.id,
    businessName: business.name,
    paymentMethodId: pm?.id ?? null,
    paymentMethodSnapshot: pm ? { name: pm.name, provider: pm.provider, accountName: pm.accountName, accountNumber: pm.accountNumber } : null,
    proof: null,
    proofNote: null,
    proofAttempts: 0,
    approvedBy: null,
    approvedAt: null,
    rejectionReason: null,
    expiresAt: ts(addDays(created, PAYMENT_WINDOW_DAYS)),
    createdAt: ts(created),
    updatedAt: ts(created),
    retentionUntil: ts(addDays(created, TRANSACTION_RETENTION_DAYS)),
  };
}

const histEntry = (status: TransactionStatus, by: string, note?: string) => ({ status, at: new Date().toISOString(), by, ...(note ? { note } : {}) });

/** Beralih ke paket gratis tidak memerlukan pembayaran. */
async function switchToFree(user: SessionUser, business: BusinessDoc, plan: PlanDoc) {
  const ref = db().collection("subscriptions").doc();
  await db().runTransaction(async (t) => {
    const olds = await t.get(db().collection("subscriptions").where("businessId", "==", business.id).where("status", "==", "active"));
    const stamp = now();
    olds.docs.forEach((d) => t.update(d.ref, { status: "replaced", updatedAt: stamp }));
    t.set(ref, {
      ownerId: user.uid, businessId: business.id, planId: plan.id,
      planSnapshot: snapshotOf(plan), status: "active", startsAt: stamp, expiresAt: null,
      transactionId: null, createdAt: stamp, updatedAt: stamp,
    });
    t.update(db().collection("businesses").doc(business.id), { subscriptionId: ref.id, updatedAt: stamp });
  });
  await audit({ actorId: user.uid, action: "subscription.free", targetType: "business", targetId: business.id, summary: `Beralih ke paket ${plan.name}` });
  return { switched: true as const };
}

export function snapshotOf(plan: PlanDoc) {
  return {
    id: plan.id, name: plan.name, price: plan.price, durationDays: plan.durationDays,
    maxBusinessPhotos: plan.maxBusinessPhotos, maxProducts: plan.maxProducts,
    maxProductPhotos: plan.maxProductPhotos, maxPromotions: plan.maxPromotions, features: plan.features,
  };
}

export async function createSubscriptionTransaction(user: SessionUser, input: { businessId: string; planId: string; paymentMethodId: string }) {
  const business = await ownedApprovedBusiness(user.uid, input.businessId);
  const plan = docPlain<PlanDoc>(await db().collection("plans").doc(input.planId).get());
  if (!plan || !plan.active) throw new HttpError(400, "Paket tidak tersedia.");
  if (plan.price === 0) return switchToFree(user, business, plan);

  const pm = await activePaymentMethod(input.paymentMethodId);
  await assertNoOpenTransaction(user.uid, business.id, "subscription", () => true);
  const charge = planCharge(plan); // harga dari server, bukan dari klien
  const ref = db().collection("transactions").doc();
  const data = {
    ...baseTx(user, business, pm),
    type: "subscription", planId: plan.id, promotionId: null,
    title: `Paket ${plan.name}`, amount: charge.amount, priceSnapshot: plan.price, durationSnapshot: charge.durationDays,
    planSnapshot: snapshotOf(plan), status: "pending_payment",
    statusHistory: [histEntry("pending_payment", user.uid)],
  };
  await ref.set(data);
  await audit({ actorId: user.uid, action: "transaction.create", targetType: "transaction", targetId: ref.id, summary: `${data.transactionNumber} ${data.title} ${formatRupiah(data.amount)}` });
  return { switched: false as const, id: ref.id, transactionNumber: data.transactionNumber };
}

export async function createPromotionTransaction(
  user: SessionUser,
  input: { businessId: string; promotionTypeId: string; durationDays: number; productId: string | null; categoryId: string | null; bannerImage: { url: string; publicId: string } | null; paymentMethodId: string },
) {
  const business = await ownedApprovedBusiness(user.uid, input.businessId);
  const type = docPlain<PromotionTypeDoc>(await db().collection("promotionTypes").doc(input.promotionTypeId).get());
  if (!type) throw new HttpError(400, "Jenis promosi tidak ditemukan.");
  const charge = promotionCharge(type, input.durationDays);
  const pm = await activePaymentMethod(input.paymentMethodId);

  const eff = await getEffectivePlan(business.id);
  if (type.requirements?.minPlanSortOrder !== undefined) {
    const p = docPlain<PlanDoc>(await db().collection("plans").doc(eff.plan.id).get());
    if (!p || p.sortOrder < type.requirements.minPlanSortOrder) throw new HttpError(403, "Jenis promosi ini memerlukan paket yang lebih tinggi.");
  }
  const mine = await db().collection("promotions").where("businessId", "==", business.id).where("status", "in", ["pending_payment", "under_review", "active"]).get();
  if (!withinLimit(limitsOf(eff.plan), "promotions", mine.size + 1)) throw new HttpError(403, limitMessage("promotions", eff.plan.maxPromotions));

  let productId: string | null = null;
  let categoryId: string | null = null;
  let bannerImage = null as { url: string; publicId: string } | null;
  if (type.kind === "product") {
    const p = input.productId ? await db().collection("products").doc(input.productId).get() : null;
    if (!p?.exists || p.data()!.businessId !== business.id || p.data()!.ownerId !== user.uid || p.data()!.status !== "active" || p.data()!.deletedAt)
      throw new HttpError(400, "Produk tidak valid atau tidak aktif.");
    productId = p.id;
  } else if (type.kind === "category") {
    if (!input.categoryId || !business.categoryIds.includes(input.categoryId)) throw new HttpError(400, "Pilih salah satu kategori bisnis Anda.");
    categoryId = input.categoryId;
  } else if (type.kind === "home_banner") {
    if (!input.bannerImage) throw new HttpError(400, "Unggah gambar banner terlebih dahulu.");
    assertOwnedAssets([input.bannerImage.publicId], ["promotion"], user.uid);
    await verifyAssets([input.bannerImage.publicId]);
    bannerImage = input.bannerImage;
  }
  await assertNoOpenTransaction(user.uid, business.id, "promotion", () => true);

  const created = now();
  const promoRef = db().collection("promotions").doc();
  const txRef = db().collection("transactions").doc();
  const base = baseTx(user, business, pm);
  const batch = db().batch();
  batch.set(promoRef, {
    ownerId: user.uid, businessId: business.id, productId, categoryId, promotionTypeId: type.id, kind: type.kind,
    durationDays: charge.durationDays, amount: charge.amount, bannerImage, status: "pending_payment",
    startsAt: null, expiresAt: null, transactionId: txRef.id, createdAt: created, updatedAt: created,
  });
  batch.set(txRef, {
    ...base, type: "promotion", planId: null, promotionId: promoRef.id,
    title: `${type.name} ${charge.durationDays} hari`, amount: charge.amount, priceSnapshot: charge.amount,
    durationSnapshot: charge.durationDays, status: "pending_payment", statusHistory: [histEntry("pending_payment", user.uid)],
  });
  await batch.commit();
  await audit({ actorId: user.uid, action: "transaction.create", targetType: "transaction", targetId: txRef.id, summary: `${base.transactionNumber} ${type.name} ${formatRupiah(charge.amount)}` });
  return { id: txRef.id, transactionNumber: base.transactionNumber };
}

export async function submitProof(user: SessionUser, txId: string, input: { publicId: string; note?: string }) {
  assertOwnedAssets([input.publicId], ["proof"], user.uid);
  const [asset] = await verifyAssets([input.publicId], "authenticated");
  const ref = db().collection("transactions").doc(txId);
  let result: TransactionDoc | null = null;
  await db().runTransaction(async (t) => {
    const snap = await t.get(ref);
    const tx = docPlain<TransactionDoc>(snap);
    if (!tx || tx.ownerId !== user.uid) throw new HttpError(404, "Transaksi tidak ditemukan.");
    if (!["pending_payment", "rejected"].includes(tx.status)) throw new HttpError(409, "Bukti pembayaran tidak dapat diunggah pada status ini.");
    if (tx.status === "pending_payment" && new Date(tx.expiresAt) < new Date()) throw new HttpError(409, "Transaksi sudah kedaluwarsa. Buat transaksi baru.");
    if (tx.proofAttempts >= MAX_PROOF_ATTEMPTS) throw new HttpError(429, "Batas pengunggahan bukti tercapai. Hubungi admin.");
    t.update(ref, {
      proof: { publicId: input.publicId, format: asset!.format, bytes: asset!.bytes },
      proofNote: input.note ?? null, proofAttempts: FieldValue.increment(1), status: "proof_submitted",
      rejectionReason: null, updatedAt: now(),
      statusHistory: FieldValue.arrayUnion(histEntry("proof_submitted", user.uid)),
    });
    if (tx.promotionId) t.update(db().collection("promotions").doc(tx.promotionId), { status: "under_review", updatedAt: now() });
    result = tx;
  });
  const tx = result as TransactionDoc | null;
  if (tx) {
    await sendToAdmins("payment",
      `💳 <b>Bukti pembayaran baru</b>\nNo: <code>${esc(tx.transactionNumber)}</code>\nPemilik: ${esc(tx.ownerName)}\nBisnis: ${esc(tx.businessName)}\nJenis: ${esc(tx.title)}\nNominal (server): <b>${formatRupiah(tx.amount)}</b>\nStatus: Bukti dikirim`,
      [[{ text: "✅ Setujui", callback_data: `t|a|${txId}` }, { text: "❌ Tolak", callback_data: `t|r|${txId}` }], [{ text: "Buka dashboard", url: dashboardLink(`/admin/transaksi?id=${txId}`) }]]);
  }
  return { ok: true };
}

export interface DecisionActor { id: string; label: string; isUser: boolean }

export async function decideTransaction(txId: string, decision: "approve" | "reject", actor: DecisionActor, reason?: string) {
  if (decision === "reject" && !reason?.trim()) throw new HttpError(400, "Alasan penolakan wajib diisi.");
  const ref = db().collection("transactions").doc(txId);
  const out = await db().runTransaction(async (t) => {
    const tx = docPlain<TransactionDoc>(await t.get(ref));
    if (!tx) throw new HttpError(404, "Transaksi tidak ditemukan.");
    if (actor.isUser && tx.ownerId === actor.id) throw new HttpError(403, "Anda tidak dapat memproses transaksi milik sendiri.");
    // Pencegahan persetujuan/penolakan ganda
    if (!["proof_submitted", "under_review"].includes(tx.status)) throw new HttpError(409, `Transaksi sudah berstatus "${tx.status}". Tidak diproses ulang.`);
    const stamp = now();

    if (decision === "reject") {
      t.update(ref, { status: "rejected", rejectionReason: reason!.trim(), approvedBy: actor.id, updatedAt: stamp, statusHistory: FieldValue.arrayUnion(histEntry("rejected", actor.id, reason)) });
      if (tx.promotionId) t.update(db().collection("promotions").doc(tx.promotionId), { status: "rejected", updatedAt: stamp });
      return { tx, approved: false };
    }

    if (tx.type === "subscription") {
      const plan = tx.planSnapshot!;
      const olds = await t.get(db().collection("subscriptions").where("businessId", "==", tx.businessId).where("status", "==", "active"));
      const start = new Date();
      const subRef = db().collection("subscriptions").doc();
      olds.docs.forEach((d) => t.update(d.ref, { status: "replaced", updatedAt: stamp }));
      t.set(subRef, {
        ownerId: tx.ownerId, businessId: tx.businessId, planId: tx.planId, planSnapshot: plan, status: "active",
        startsAt: ts(start), expiresAt: plan.durationDays > 0 ? ts(addDays(start, plan.durationDays)) : null,
        transactionId: txId, createdAt: stamp, updatedAt: stamp,
      });
      t.update(db().collection("businesses").doc(tx.businessId), { subscriptionId: subRef.id, updatedAt: stamp });
    } else {
      const promoRef = db().collection("promotions").doc(tx.promotionId!);
      const promo = docPlain<PromotionDoc>(await t.get(promoRef));
      const biz = await t.get(db().collection("businesses").doc(tx.businessId));
      const typeSnap = promo ? await t.get(db().collection("promotionTypes").doc(promo.promotionTypeId)) : null;
      if (!promo || !biz.exists || !biz.data()!.visible) throw new HttpError(409, "Bisnis atau promosi tidak lagi valid untuk diaktifkan.");
      if (promo.productId) {
        const p = await t.get(db().collection("products").doc(promo.productId));
        if (!p.exists || !p.data()!.visible) throw new HttpError(409, "Produk yang dipromosikan sudah tidak aktif.");
      }
      const slot = typeSnap?.data()?.slotLimit ?? 0;
      if (slot > 0) {
        const active = await t.get(db().collection("promotions").where("promotionTypeId", "==", promo.promotionTypeId).where("status", "==", "active"));
        const live = active.docs.filter((d) => d.data().expiresAt.toDate() > new Date()).length;
        if (live >= slot) throw new HttpError(409, "Slot promosi untuk jenis ini sudah penuh.");
      }
      const start = new Date();
      const end = addDays(start, promo.durationDays); // masa berlaku dihitung dari waktu persetujuan
      t.update(promoRef, { status: "active", startsAt: ts(start), expiresAt: ts(end), updatedAt: stamp });
      if (promo.kind === "home_banner" && promo.bannerImage) {
        t.set(db().collection("banners").doc(`promo_${promoRef.id}`), {
          title: tx.businessName, image: promo.bannerImage, targetUrl: `/bisnis/${biz.data()!.slug}`, active: true,
          startsAt: ts(start), expiresAt: ts(end), promotionId: promoRef.id, sortOrder: 0, createdAt: stamp, updatedAt: stamp,
        });
      }
    }
    t.update(ref, { status: "approved", approvedBy: actor.id, approvedAt: stamp, rejectionReason: null, updatedAt: stamp, statusHistory: FieldValue.arrayUnion(histEntry("approved", actor.id)) });
    return { tx, approved: true };
  });

  await audit({ actorId: actor.id, action: out.approved ? "transaction.approve" : "transaction.reject", targetType: "transaction", targetId: txId, summary: `${out.tx.transactionNumber} oleh ${actor.label}${reason ? `: ${reason}` : ""}` });
  await sendToAdmins("decisions", `${out.approved ? "✅ Transaksi disetujui" : "❌ Transaksi ditolak"}\nNo: <code>${esc(out.tx.transactionNumber)}</code>\nOleh: ${esc(actor.label)}${out.approved && out.tx.type === "promotion" ? "\nPromosi diaktifkan." : ""}`);
  return { status: out.approved ? "approved" : "rejected" };
}

/** Pemeliharaan harian: kedaluwarsakan langganan, promosi, banner, dan transaksi yang menggantung. */
export async function runExpiry() {
  const stamp = now();
  const summary = { subscriptions: 0, promotions: 0, banners: 0, transactions: 0 };
  const subs = await db().collection("subscriptions").where("status", "==", "active").where("expiresAt", "<", stamp).limit(300).get();
  for (const d of subs.docs) { await d.ref.update({ status: "expired", updatedAt: stamp }); summary.subscriptions++; }
  const promos = await db().collection("promotions").where("status", "==", "active").where("expiresAt", "<", stamp).limit(300).get();
  for (const d of promos.docs) { await d.ref.update({ status: "expired", updatedAt: stamp }); summary.promotions++; }
  const banners = await db().collection("banners").where("active", "==", true).where("expiresAt", "<", stamp).limit(300).get();
  for (const d of banners.docs) { await d.ref.update({ active: false, updatedAt: stamp }); summary.banners++; }
  const stale = await db().collection("transactions").where("status", "==", "pending_payment").where("expiresAt", "<", stamp).limit(300).get();
  for (const d of stale.docs) {
    await d.ref.update({ status: "expired", updatedAt: stamp, statusHistory: FieldValue.arrayUnion(histEntry("expired", "system")) });
    const promoId = d.data().promotionId as string | null;
    if (promoId) await db().collection("promotions").doc(promoId).update({ status: "cancelled", updatedAt: stamp }).catch(() => undefined);
    summary.transactions++;
  }
  return summary;
}
