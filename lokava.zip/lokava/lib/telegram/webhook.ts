import "server-only";
import { db, now } from "@/lib/firebase/admin";
import { HttpError } from "@/lib/auth/session";
import { audit } from "@/lib/audit";
import { decideBusiness } from "@/lib/admin/decisions";
import { decideTransaction } from "@/lib/payments/transactions";
import { answerCallback, editMessage, esc, getTelegramSettings, reply } from "@/lib/telegram";

interface Update {
  update_id: number;
  message?: { chat: { id: number; type: string }; from?: { id: number }; text?: string };
  callback_query?: { id: string; from: { id: number; first_name?: string }; data?: string; message?: { chat: { id: number }; message_id: number; text?: string } };
}

/** Kembalikan true jika update baru. Dokumen dibuat dengan create() sehingga callback berulang ditolak. */
async function firstTime(updateId: number) {
  try {
    await db().collection("telegramUpdates").doc(String(updateId)).create({ at: now() });
    return true;
  } catch {
    return false;
  }
}

export async function handleUpdate(update: Update) {
  if (!Number.isInteger(update.update_id)) return;
  if (!(await firstTime(update.update_id))) return;
  const settings = await getTelegramSettings();

  if (update.message?.text?.startsWith("/id") && update.message.chat.type === "private" && update.message.from) {
    await reply(update.message.chat.id, `ID Telegram Anda: <code>${update.message.from.id}</code>\nMasukkan ID ini di dashboard admin LOKAVA agar dapat menyetujui lewat bot.`);
    return;
  }

  const cb = update.callback_query;
  if (!cb?.data) return;
  const fromId = String(cb.from.id);
  const allowed = settings.enabled && settings.allowedAdminIds.includes(fromId);
  if (!allowed) {
    await answerCallback(cb.id, "Anda tidak diizinkan melakukan tindakan ini.");
    await audit({ actorId: `telegram:${fromId}`, action: "telegram.callback_denied", targetType: "telegram", targetId: cb.data.slice(0, 40), summary: "Callback dari pengguna tidak sah", result: "failure" });
    return;
  }
  const m = /^([bt])\|([arc])\|([A-Za-z0-9]{10,40})$/.exec(cb.data);
  if (!m) { await answerCallback(cb.id, "Perintah tidak dikenal."); return; }
  const [, scope, act, id] = m as unknown as [string, "b" | "t", "a" | "r" | "c", string];
  const actor = { id: `telegram:${fromId}`, label: `Telegram ${cb.from.first_name ?? fromId}`, isUser: false };
  try {
    let label = "";
    if (scope === "b") {
      const d = act === "a" ? "approve" : act === "r" ? "reject" : "correction";
      await decideBusiness(id, d, actor, act === "a" ? undefined : act === "r" ? "Pengajuan ditolak oleh admin melalui Telegram. Hubungi admin untuk rincian." : "Mohon lengkapi atau perbaiki data bisnis Anda, lalu ajukan kembali.");
      label = act === "a" ? "✅ Disetujui" : act === "r" ? "❌ Ditolak" : "✏️ Perbaikan diminta";
    } else {
      if (act === "c") throw new HttpError(400, "Tidak berlaku untuk transaksi.");
      await decideTransaction(id, act === "a" ? "approve" : "reject", actor, act === "r" ? "Pembayaran ditolak oleh admin melalui Telegram. Periksa bukti Anda dan unggah ulang." : undefined);
      label = act === "a" ? "✅ Disetujui" : "❌ Ditolak";
    }
    await answerCallback(cb.id, label);
    if (cb.message) await editMessage(cb.message.chat.id, cb.message.message_id, `${esc(cb.message.text ?? "")}\n\n<b>${label}</b> oleh ${esc(actor.label)}`);
  } catch (e) {
    const msg = e instanceof HttpError ? e.message : "Terjadi kesalahan. Coba lewat dashboard.";
    await answerCallback(cb.id, msg);
  }
}
