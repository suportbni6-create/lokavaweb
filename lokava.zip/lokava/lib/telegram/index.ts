import "server-only";
import { db, now } from "@/lib/firebase/admin";
import { serverEnv, appUrl } from "@/lib/env";
import { decryptSecret, encryptSecret } from "@/lib/crypto";
import { DEFAULT_TELEGRAM, type TelegramSettings } from "@/types";

export async function getTelegramSettings(): Promise<TelegramSettings> {
  const snap = await db().collection("telegramSettings").doc("default").get();
  const data = snap.exists ? (snap.data() as Partial<TelegramSettings>) : {};
  return {
    ...DEFAULT_TELEGRAM,
    ...data,
    notifications: { ...DEFAULT_TELEGRAM.notifications, ...(data.notifications ?? {}) },
  };
}

/** Token: environment variable lebih dulu, lalu token terenkripsi di telegramSecrets (tidak pernah dikirim ke klien). */
export async function getBotToken(): Promise<string | null> {
  const env = serverEnv();
  if (env.TELEGRAM_BOT_TOKEN) return env.TELEGRAM_BOT_TOKEN;
  const snap = await db().collection("telegramSecrets").doc("default").get();
  const enc = snap.exists ? (snap.data()?.botTokenEnc as string | undefined) : undefined;
  if (!enc) return null;
  try {
    return decryptSecret(enc, env.APP_ENCRYPTION_KEY);
  } catch {
    return null;
  }
}

export async function saveBotToken(token: string) {
  await db()
    .collection("telegramSecrets")
    .doc("default")
    .set({ botTokenEnc: encryptSecret(token, serverEnv().APP_ENCRYPTION_KEY), updatedAt: now() });
}

export async function isTokenConfigured() {
  return Boolean(await getBotToken());
}

async function call(method: string, body: Record<string, unknown>, token?: string) {
  const t = token ?? (await getBotToken());
  if (!t) return { ok: false, description: "Token bot belum dikonfigurasi." } as { ok: boolean; description?: string; result?: unknown };
  try {
    const res = await fetch(`https://api.telegram.org/bot${t}/${method}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(8000),
    });
    return (await res.json()) as { ok: boolean; description?: string; result?: unknown };
  } catch {
    // Jangan mencetak URL (mengandung token).
    return { ok: false, description: "Gagal menghubungi Telegram." };
  }
}

export const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

type Button = { text: string; callback_data?: string; url?: string };

export async function sendToAdmins(
  kind: keyof TelegramSettings["notifications"],
  text: string,
  buttons?: Button[][],
) {
  const settings = await getTelegramSettings();
  if (!settings.enabled || !settings.notifications[kind]) return { ok: false, skipped: true };
  const chatId = settings.destinationChatId || serverEnv().TELEGRAM_DEFAULT_CHAT_ID;
  if (!chatId) return { ok: false, skipped: true };
  return call("sendMessage", {
    chat_id: chatId,
    text,
    parse_mode: "HTML",
    disable_web_page_preview: true,
    ...(buttons ? { reply_markup: { inline_keyboard: buttons } } : {}),
  });
}

export async function testConnection() {
  const me = await call("getMe", {});
  if (!me.ok) return { ok: false, message: me.description ?? "Token tidak valid." };
  const sent = await sendToAdmins("errors", "✅ Uji koneksi LOKAVA berhasil.");
  return sent.ok ? { ok: true, message: "Koneksi dan notifikasi berhasil." } : { ok: false, message: "Bot aktif, tetapi pesan gagal terkirim. Periksa Chat ID dan status integrasi." };
}

export async function answerCallback(id: string, text: string) {
  return call("answerCallbackQuery", { callback_query_id: id, text: text.slice(0, 190), show_alert: false });
}

export async function editMessage(chatId: string | number, messageId: number, text: string) {
  return call("editMessageText", { chat_id: chatId, message_id: messageId, text, parse_mode: "HTML", disable_web_page_preview: true });
}

export async function registerWebhook() {
  const env = serverEnv();
  if (!env.TELEGRAM_WEBHOOK_SECRET) return { ok: false, message: "TELEGRAM_WEBHOOK_SECRET belum diatur." };
  const res = await call("setWebhook", {
    url: `${appUrl()}/api/telegram/webhook`,
    secret_token: env.TELEGRAM_WEBHOOK_SECRET,
    allowed_updates: ["callback_query", "message"],
    drop_pending_updates: true,
  });
  return { ok: res.ok, message: res.ok ? "Webhook terpasang." : (res.description ?? "Gagal memasang webhook.") };
}

export const dashboardLink = (path: string) => `${appUrl()}${path}`;

export async function reply(chatId: string | number, text: string) {
  return call("sendMessage", { chat_id: chatId, text, parse_mode: "HTML" });
}
