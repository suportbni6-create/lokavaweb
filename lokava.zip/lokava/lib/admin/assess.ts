import type { BusinessDoc } from "@/types";

export interface Assessment {
  complete: boolean;
  missing: string[];
  flags: string[]; // butuh pemeriksaan manusia
}

/** Penilaian kelengkapan formulir. TIDAK membuktikan identitas atau legalitas usaha. */
export function assessBusiness(b: Pick<BusinessDoc, "name" | "description" | "address" | "village" | "district" | "region" | "whatsapp" | "coverImage" | "categoryIds" | "latitude" | "longitude">): Assessment {
  const missing: string[] = [];
  if (!b.name || b.name.length < 3) missing.push("nama bisnis");
  if (!b.description || b.description.length < 20) missing.push("deskripsi");
  if (!b.address) missing.push("alamat");
  if (!b.village) missing.push("desa/kelurahan");
  if (!b.district) missing.push("kecamatan");
  if (!b.region) missing.push("wilayah");
  if (!b.whatsapp) missing.push("WhatsApp");
  if (!b.coverImage) missing.push("foto utama");
  if (!b.categoryIds?.length) missing.push("kategori");

  const flags: string[] = [];
  if (b.latitude !== null && b.longitude !== null) {
    // Kotak kasar Pulau Jawa; di luar itu patut diperiksa manusia.
    if (b.latitude < -8.8 || b.latitude > -5.8 || b.longitude < 105.0 || b.longitude > 114.8) flags.push("koordinat di luar Pulau Jawa");
  } else flags.push("koordinat belum diisi");
  if (/(.)\1{5,}/.test(b.name)) flags.push("nama bisnis mencurigakan");
  if (/https?:\/\//i.test(b.description)) flags.push("deskripsi berisi tautan");
  return { complete: missing.length === 0, missing, flags };
}
