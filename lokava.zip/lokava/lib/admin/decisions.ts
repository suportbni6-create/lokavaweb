import "server-only";
import { db, docPlain, now } from "@/lib/firebase/admin";
import { HttpError } from "@/lib/auth/session";
import { audit } from "@/lib/audit";
import { assessBusiness } from "@/lib/admin/assess";
import { getFreePlan, syncBusinessVisibility } from "@/lib/data/business-core";
import { snapshotOf } from "@/lib/payments/transactions";
import { dashboardLink, esc, sendToAdmins, getTelegramSettings } from "@/lib/telegram";
import { formatTanggal } from "@/lib/utils/format";
import type { BusinessDoc, PlanDoc } from "@/types";
import type { DecisionActor } from "@/lib/payments/transactions";

async function ensureFreeSubscription(b: BusinessDoc) {
  if (b.subscriptionId) return;
  const free = await getFreePlan();
  const plan = docPlain<PlanDoc>(await db().collection("plans").doc(free.id).get());
  const stamp = now();
  const ref = db().collection("subscriptions").doc();
  await ref.set({
    ownerId: b.ownerId, businessId: b.id, planId: free.id,
    planSnapshot: plan ? snapshotOf(plan) : { ...free }, status: "active",
    startsAt: stamp, expiresAt: null, transactionId: null, createdAt: stamp, updatedAt: stamp,
  });
  await db().collection("businesses").doc(b.id).update({ subscriptionId: ref.id });
}

export async function decideBusiness(id: string, decision: "approve" | "reject" | "correction", actor: DecisionActor, reason?: string) {
  if (decision !== "approve" && !reason?.trim()) throw new HttpError(400, "Alasan wajib diisi agar pemilik tahu apa yang perlu diperbaiki.");
  const ref = db().collection("businesses").doc(id);
  const b = docPlain<BusinessDoc>(await ref.get());
  if (!b || b.deletedAt) throw new HttpError(404, "Bisnis tidak ditemukan.");
  if (b.verificationStatus !== "pending") throw new HttpError(409, `Pengajuan sudah berstatus "${b.verificationStatus}". Tidak diproses ulang.`);

  if (decision === "approve") {
    const a = assessBusiness(b);
    if (!a.complete) throw new HttpError(400, `Data belum lengkap: ${a.missing.join(", ")}.`);
  }
  const verificationStatus = decision === "approve" ? "approved" : decision === "reject" ? "rejected" : "needs_correction";
  await db().runTransaction(async (t) => {
    const cur = await t.get(ref);
    if (cur.data()?.verificationStatus !== "pending") throw new HttpError(409, "Pengajuan sudah diproses.");
    t.update(ref, {
      verificationStatus, publicationStatus: decision === "approve" ? "published" : "unpublished",
      reviewNote: decision === "approve" ? null : reason!.trim(), updatedAt: now(),
    });
  });
  if (decision === "approve") await ensureFreeSubscription(b);
  await syncBusinessVisibility(id);
  await audit({ actorId: actor.id, action: `business.${decision}`, targetType: "business", targetId: id, summary: `${b.name} oleh ${actor.label}${reason ? `: ${reason}` : ""}` });
  await sendToAdmins("decisions", `${decision === "approve" ? "✅ Bisnis disetujui" : decision === "reject" ? "❌ Bisnis ditolak" : "✏️ Perbaikan diminta"}: <b>${esc(b.name)}</b>\nOleh: ${esc(actor.label)}`);
  return { status: verificationStatus };
}

/** Dipanggil saat pemilik mengajukan bisnis. Mengirim notifikasi dan, jika mode auto, memproses otomatis. */
export async function onBusinessSubmitted(b: BusinessDoc, ownerName: string) {
  const a = assessBusiness(b);
  const settings = await getTelegramSettings();
  const summary = a.complete ? "Data wajib lengkap." : `Belum lengkap: ${a.missing.join(", ")}.`;
  const flagText = a.flags.length ? `\n⚠️ Perlu dicek manusia: ${a.flags.join("; ")}` : "";
  await sendToAdmins("business",
    `🏝️ <b>Pengajuan bisnis baru</b>\nID: <code>${b.id}</code>\nBisnis: ${esc(b.name)}\nPemilik: ${esc(ownerName)}\nWilayah: ${esc(b.district)}, ${esc(b.region)}\nWaktu: ${formatTanggal(new Date(), true)}\nStatus: Pending\n${summary}${flagText}`,
    [[{ text: "✅ Setujui", callback_data: `b|a|${b.id}` }, { text: "❌ Tolak", callback_data: `b|r|${b.id}` }], [{ text: "✏️ Minta perbaikan", callback_data: `b|c|${b.id}` }, { text: "Buka dashboard", url: dashboardLink(`/admin/bisnis?id=${b.id}`) }]]);

  if (settings.verificationMode === "assisted" && !a.complete) {
    // Bantuan otomatis: kembalikan untuk diperbaiki hanya jika data wajib tidak lengkap.
    await decideBusiness(b.id, "correction", { id: "system:assist", label: "Asisten verifikasi", isUser: false }, `Data wajib belum lengkap: ${a.missing.join(", ")}.`).catch(() => undefined);
  } else if (settings.verificationMode === "auto" && a.complete && a.flags.length === 0) {
    await decideBusiness(b.id, "approve", { id: "system:auto", label: "Auto-approval", isUser: false }).catch(() => undefined);
  }
}
