import "server-only";
import { db, docPlain, now, ts } from "@/lib/firebase/admin";
import { HttpError } from "@/lib/auth/session";
import { audit } from "@/lib/audit";
import { assertOwnedAssets, verifyAssets } from "@/lib/cloudinary";
import { uniqueSlug } from "@/lib/data/business-core";
import { adminCollections, type AdminCollection } from "@/lib/validation/schemas";
import { slugify, tokenize } from "@/lib/utils/slug";
import type { SessionUser } from "@/types";

const SOFT_DELETE: AdminCollection[] = ["categories", "plans", "promotionTypes", "paymentMethods"];
const WITH_SLUG: AdminCollection[] = ["categories", "destinations"];
const SORT: Partial<Record<AdminCollection, [string, "asc" | "desc"]>> = {
  categories: ["sortOrder", "asc"], plans: ["sortOrder", "asc"], paymentMethods: ["sortOrder", "asc"],
  regions: ["sortOrder", "asc"], banners: ["sortOrder", "asc"], promotionTypes: ["createdAt", "asc"], destinations: ["createdAt", "desc"],
};

function collectImageIds(data: Record<string, unknown>): string[] {
  const ids: string[] = [];
  for (const k of ["image", "coverImage", "qrImage"]) {
    const v = data[k] as { publicId?: string } | null | undefined;
    if (v?.publicId) ids.push(v.publicId);
  }
  const g = data.gallery as { publicId: string }[] | undefined;
  if (Array.isArray(g)) g.forEach((x) => ids.push(x.publicId));
  return ids;
}

export async function adminList(name: AdminCollection) {
  const [field, dir] = SORT[name] ?? ["createdAt", "desc"];
  const s = await db().collection(name).orderBy(field, dir).limit(300).get();
  return s.docs.map((d) => {
    const x = docPlain<Record<string, unknown>>(d)!;
    delete x.searchTokens;
    return x;
  });
}

async function prepare(user: SessionUser, name: AdminCollection, raw: unknown, existingId?: string) {
  const data = adminCollections[name].parse(raw) as Record<string, unknown>;
  const existing = existingId ? docPlain<Record<string, unknown>>(await db().collection(name).doc(existingId).get()) : null;
  if (existingId && !existing) throw new HttpError(404, "Data tidak ditemukan.");
  const known = JSON.stringify(existing ?? {});
  const fresh = collectImageIds(data).filter((id) => !known.includes(id));
  assertOwnedAssets(fresh, ["admin"], user.uid, true);
  await verifyAssets(fresh);

  if (WITH_SLUG.includes(name)) data.slug = await uniqueSlug(name as "categories" | "destinations", slugify((data.slug as string) || (data.name as string)), existingId);
  if (name === "destinations") data.searchTokens = tokenize(data.name as string, data.description as string, data.district as string, data.region as string, data.address as string);
  for (const k of ["startsAt", "expiresAt"]) if (typeof data[k] === "string") data[k] = ts(new Date(data[k] as string));
  return { data, existing };
}

function diffSummary(name: string, before: Record<string, unknown> | null, after: Record<string, unknown>) {
  const keys = ["price", "basePrice", "durations", "durationDays", "accountNumber", "accountName", "active", "maxProducts", "maxBusinessPhotos", "maxProductPhotos", "maxPromotions", "slotLimit"];
  const changes = keys.filter((k) => before && JSON.stringify(before[k]) !== JSON.stringify(after[k])).map((k) => `${k}: ${JSON.stringify(before![k])} → ${JSON.stringify(after[k])}`);
  // Nomor rekening dimasking di log
  return `${name}${changes.length ? " — " + changes.join("; ").replace(/accountNumber: ".*?" → ".*?"/, "accountNumber diubah") : ""}`;
}

export async function adminCreate(user: SessionUser, name: AdminCollection, raw: unknown) {
  const { data } = await prepare(user, name, raw);
  const ref = db().collection(name).doc();
  await ref.set({ ...data, createdAt: now(), updatedAt: now() });
  await audit({ actorId: user.uid, action: `${name}.create`, targetType: name, targetId: ref.id, summary: diffSummary(String(data.name ?? data.title ?? ref.id), null, data) });
  return { id: ref.id };
}

export async function adminUpdate(user: SessionUser, name: AdminCollection, id: string, raw: unknown) {
  const { data, existing } = await prepare(user, name, raw, id);
  await db().collection(name).doc(id).set({ ...data, createdAt: existing!.createdAt ? ts(new Date(existing!.createdAt as string)) : now(), updatedAt: now() });
  await audit({ actorId: user.uid, action: `${name}.update`, targetType: name, targetId: id, summary: diffSummary(String(data.name ?? data.title ?? id), existing, data) });
  return { id };
}

export async function adminDelete(user: SessionUser, name: AdminCollection, id: string) {
  const ref = db().collection(name).doc(id);
  if (!(await ref.get()).exists) throw new HttpError(404, "Data tidak ditemukan.");
  if (SOFT_DELETE.includes(name)) await ref.update({ active: false, updatedAt: now() });
  else await ref.delete();
  await audit({ actorId: user.uid, action: `${name}.${SOFT_DELETE.includes(name) ? "deactivate" : "delete"}`, targetType: name, targetId: id, summary: id });
  return { id, softDeleted: SOFT_DELETE.includes(name) };
}
