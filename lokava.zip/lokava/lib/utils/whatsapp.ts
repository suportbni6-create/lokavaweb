/** Normalisasi nomor Indonesia ke format 62xxxxxxxxx. Mengembalikan null jika tidak valid. */
export function normalizeWhatsapp(input: string | null | undefined): string | null {
  if (!input) return null;
  let d = input.replace(/[\s\-().+]/g, "");
  if (!/^\d+$/.test(d)) return null;
  if (d.startsWith("0")) d = "62" + d.slice(1);
  else if (d.startsWith("8")) d = "62" + d;
  if (!d.startsWith("62")) return null;
  const rest = d.slice(2);
  if (!rest.startsWith("8")) return null; // nomor seluler Indonesia
  if (rest.length < 9 || rest.length > 12) return null;
  return d;
}

export function buildWhatsappLink(number: string, message: string): string {
  return `https://wa.me/${number}?text=${encodeURIComponent(message)}`;
}

export type WaIntent = "umum" | "harga" | "ketersediaan" | "informasi";

export function whatsappMessage(intent: WaIntent, opts: { businessName?: string; productName?: string } = {}): string {
  const target = opts.productName ? `"${opts.productName}"` : opts.businessName ? `usaha ${opts.businessName}` : "usaha Anda";
  const intro = "Halo, saya menemukan usaha Anda melalui LOKAVA.";
  switch (intent) {
    case "harga":
      return `${intro} Saya ingin menanyakan harga ${target}.`;
    case "ketersediaan":
      return `${intro} Apakah ${target} masih tersedia?`;
    case "informasi":
      return `${intro} Saya ingin meminta informasi lebih lanjut tentang ${target}.`;
    default:
      return opts.productName
        ? `${intro} Saya ingin bertanya tentang produk ${target}.`
        : `${intro} Saya ingin bertanya tentang produk atau layanan yang tersedia.`;
  }
}
