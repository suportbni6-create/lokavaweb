export function slugify(input: string): string {
  return input
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/&/g, " dan ")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}

export function tokenize(...parts: (string | null | undefined)[]): string[] {
  const set = new Set<string>();
  for (const p of parts) {
    if (!p) continue;
    for (const w of p
      .toLowerCase()
      .normalize("NFKD")
      .replace(/[\u0300-\u036f]/g, "")
      .split(/[^a-z0-9]+/)) {
      if (w.length >= 2) set.add(w);
    }
  }
  return Array.from(set).slice(0, 60);
}
