import "server-only";
import { v2 as cloudinary } from "cloudinary";
import { serverEnv } from "@/lib/env";
import { HttpError } from "@/lib/auth/session";

export type UploadPurpose = "business" | "product" | "proof" | "promotion" | "admin";

export const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
export const ALLOWED_FORMATS = ["jpg", "jpeg", "png", "webp"];

function configure() {
  const env = serverEnv();
  cloudinary.config({
    cloud_name: env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME,
    api_key: env.CLOUDINARY_API_KEY,
    api_secret: env.CLOUDINARY_API_SECRET,
    secure: true,
  });
  return env;
}

export function folderFor(purpose: UploadPurpose, uid: string) {
  return purpose === "admin" ? "lokava/admin" : `lokava/${purpose}/${uid}`;
}

/** Tanda tangan upload. Folder & tipe ditentukan SERVER, klien tidak bisa memilih lokasi/tipe lain. */
export function signUpload(purpose: UploadPurpose, uid: string) {
  const env = configure();
  const timestamp = Math.round(Date.now() / 1000);
  const params: Record<string, string | number> = {
    folder: folderFor(purpose, uid),
    timestamp,
    allowed_formats: ALLOWED_FORMATS.join(","),
    type: purpose === "proof" ? "authenticated" : "upload",
  };
  const signature = cloudinary.utils.api_sign_request(params, env.CLOUDINARY_API_SECRET);
  return {
    cloudName: env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME,
    apiKey: env.CLOUDINARY_API_KEY,
    signature,
    params,
    maxBytes: MAX_IMAGE_BYTES,
  };
}

/** Pastikan semua aset berada di folder milik user (mencegah memakai/menghapus aset orang lain). */
export function assertOwnedAssets(publicIds: string[], purposes: UploadPurpose[], uid: string, isAdmin = false) {
  for (const id of publicIds) {
    const ok = purposes.some((p) => id.startsWith(folderFor(p, uid) + "/")) || (isAdmin && id.startsWith("lokava/admin/"));
    if (!ok) throw new HttpError(403, "Foto tidak valid atau bukan milik Anda.");
  }
}

export async function verifyAssets(publicIds: string[], type: "upload" | "authenticated" = "upload") {
  if (publicIds.length === 0) return [];
  configure();
  const found: { public_id: string; bytes: number; format: string }[] = [];
  for (let i = 0; i < publicIds.length; i += 100) {
    const res = await cloudinary.api.resources_by_ids(publicIds.slice(i, i + 100), { type, resource_type: "image" });
    found.push(...res.resources);
  }
  const map = new Map(found.map((r) => [r.public_id, r]));
  for (const id of publicIds) {
    const r = map.get(id);
    if (!r) throw new HttpError(400, "Foto belum selesai diunggah atau tidak ditemukan.");
    if (r.bytes > MAX_IMAGE_BYTES || !ALLOWED_FORMATS.includes(r.format.toLowerCase())) {
      await deleteAssets([id], type).catch(() => undefined);
      throw new HttpError(400, "Foto melebihi 5 MB atau formatnya tidak didukung (JPG/PNG/WebP).");
    }
  }
  return found;
}

export async function deleteAssets(publicIds: string[], type: "upload" | "authenticated" = "upload") {
  if (publicIds.length === 0) return;
  configure();
  for (let i = 0; i < publicIds.length; i += 100) {
    await cloudinary.api.delete_resources(publicIds.slice(i, i + 100), { type, resource_type: "image" });
  }
}

export async function deleteByPrefix(prefix: string, type: "upload" | "authenticated" = "upload") {
  configure();
  if (!/^lokava\/[a-z]+\/[A-Za-z0-9_-]+\/$/.test(prefix)) throw new Error("Prefix aset tidak aman.");
  let next: string | undefined;
  do {
    const res = await cloudinary.api.delete_resources_by_prefix(prefix, { type, resource_type: "image", next_cursor: next });
    next = res.next_cursor;
  } while (next);
}

/** URL unduhan bukti pembayaran berumur pendek (5 menit). */
export function privateProofUrl(publicId: string, format: string) {
  configure();
  return cloudinary.utils.private_download_url(publicId, format, {
    type: "authenticated",
    resource_type: "image",
    expires_at: Math.floor(Date.now() / 1000) + 300,
  });
}
