import "server-only";
import { db } from "@/lib/firebase/admin";
import { HttpError, requireApiUser } from "@/lib/auth/session";

/** Admin utama (superAdmin=true) hanya dapat ditetapkan lewat skrip bootstrap. */
export async function requireSuperAdmin() {
  const user = await requireApiUser({ admin: true });
  const snap = await db().collection("users").doc(user.uid).get();
  if (!snap.data()?.superAdmin) throw new HttpError(403, "Hanya admin utama yang dapat mengubah pengaturan ini.");
  return user;
}
