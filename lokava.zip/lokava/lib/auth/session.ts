import "server-only";
import { cache } from "react";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { adminAuth, db } from "@/lib/firebase/admin";
import type { SessionUser } from "@/types";

export const SESSION_COOKIE = "lokava_session";
export const SESSION_MAX_AGE_MS = 5 * 24 * 60 * 60 * 1000; // 5 hari

export class HttpError extends Error {
  constructor(
    public status: number,
    message: string,
  ) {
    super(message);
  }
}

/** Sumber kebenaran role & status adalah dokumen users/{uid} yang hanya bisa ditulis server. */
export const getCurrentUser = cache(async (): Promise<SessionUser | null> => {
  const store = await cookies();
  const cookie = store.get(SESSION_COOKIE)?.value;
  if (!cookie) return null;
  try {
    const decoded = await adminAuth().verifySessionCookie(cookie, true);
    const snap = await db().collection("users").doc(decoded.uid).get();
    if (!snap.exists) return null;
    const u = snap.data()!;
    if (u.status === "deleted") return null;
    return {
      uid: decoded.uid,
      email: u.email,
      displayName: u.displayName,
      role: u.role,
      status: u.status,
    };
  } catch {
    return null;
  }
});

/** Untuk Route Handler: lempar HttpError agar dapat dipetakan ke respons JSON. */
export async function requireApiUser(opts: { admin?: boolean } = {}): Promise<SessionUser> {
  const user = await getCurrentUser();
  if (!user) throw new HttpError(401, "Silakan masuk terlebih dahulu.");
  if (user.status === "suspended") throw new HttpError(403, "Akun Anda ditangguhkan. Hubungi admin LOKAVA.");
  if (user.status !== "active") throw new HttpError(403, "Akun tidak aktif.");
  if (opts.admin && user.role !== "admin") throw new HttpError(403, "Akses ditolak.");
  return user;
}

/** Untuk halaman server: arahkan ke login jika tidak sah. */
export async function requirePageUser(opts: { admin?: boolean } = {}): Promise<SessionUser> {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (user.status !== "active") redirect("/login?alasan=" + user.status);
  if (opts.admin && user.role !== "admin") redirect("/dashboard");
  if (!opts.admin && user.role === "admin") redirect("/admin");
  return user;
}
