export type Tone = "netral" | "hijau" | "biru" | "merah" | "kuning";
export const STATUS_LABEL: Record<string, [string, Tone]> = {
  draft: ["Draf", "netral"], pending: ["Menunggu verifikasi", "kuning"], needs_correction: ["Perlu perbaikan", "kuning"], approved: ["Disetujui", "hijau"],
  rejected: ["Ditolak", "merah"], suspended: ["Ditangguhkan", "merah"], deleted: ["Dihapus", "netral"],
};
export const TX_TONE: Record<string, Tone> = { pending_payment: "kuning", proof_submitted: "biru", under_review: "biru", approved: "hijau", rejected: "merah", expired: "netral", cancelled: "netral" };
export const PROMO_STATUS: Record<string, [string, Tone]> = {
  pending_payment: ["Menunggu pembayaran", "kuning"], under_review: ["Diperiksa", "biru"], active: ["Aktif", "hijau"], expired: ["Berakhir", "netral"],
  rejected: ["Ditolak", "merah"], cancelled: ["Dibatalkan", "netral"], deactivated: ["Dinonaktifkan", "merah"],
};
