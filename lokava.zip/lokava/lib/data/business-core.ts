import "server-only";
import { db, docPlain, now, plain } from "@/lib/firebase/admin";
import { resolveEffectivePlan, type PlanLike } from "@/lib/permissions/limits";
import type { BusinessDoc, PlanDoc, SubscriptionDoc } from "@/types";

export const FALLBACK_FREE_PLAN: PlanLike = {
  id: "free",
  name: "FREE",
  price: 0,
  durationDays: 0,
  maxBusinessPhotos: 3,
  maxProducts: 5,
  maxProductPhotos: 1,
  maxPromotions: 0,
  features: [],
};

export async function getFreePlan(): Promise<PlanLike> {
  const snap = await db().collection("plans").where("active", "==", true).where("price", "==", 0).limit(5).get();
  if (snap.empty) return FALLBACK_FREE_PLAN;
  const plans = snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<PlanDoc, "id">) }));
  plans.sort((a, b) => a.sortOrder - b.sortOrder);
  return plans[0] as unknown as PlanLike;
}

export async function getEffectivePlan(businessId: string) {
  const bsnap = await db().collection("businesses").doc(businessId).get();
  const subId = bsnap.data()?.subscriptionId as string | undefined;
  const free = await getFreePlan();
  if (!subId) return { plan: free, expired: false, subscription: null as SubscriptionDoc | null };
  const sub = docPlain<SubscriptionDoc>(await db().collection("subscriptions").doc(subId).get());
  const r = resolveEffectivePlan(sub, free);
  return { ...r, subscription: sub };
}

export function computeVisible(b: Pick<BusinessDoc, "verificationStatus" | "publicationStatus" | "deletedAt">, ownerStatus: string) {
  return b.verificationStatus === "approved" && b.publicationStatus === "published" && ownerStatus === "active" && !b.deletedAt;
}

/** Hitung ulang `visible` pada bisnis dan semua produknya. Dipanggil setiap status bisnis/pemilik berubah. */
export async function syncBusinessVisibility(businessId: string) {
  const bref = db().collection("businesses").doc(businessId);
  const bsnap = await bref.get();
  if (!bsnap.exists) return;
  const b = plain<BusinessDoc>(bsnap.data());
  const owner = await db().collection("users").doc(b.ownerId).get();
  const visible = computeVisible(b, (owner.data()?.status as string) ?? "deleted");
  await bref.update({ visible, updatedAt: now() });

  const products = await db().collection("products").where("businessId", "==", businessId).get();
  let batch = db().batch();
  let n = 0;
  for (const p of products.docs) {
    const d = p.data();
    const pv = visible && d.status === "active" && !d.deletedAt;
    if (d.visible !== pv) {
      batch.update(p.ref, { visible: pv, updatedAt: now() });
      if (++n % 400 === 0) {
        await batch.commit();
        batch = db().batch();
      }
    }
  }
  await batch.commit();
}

export async function syncOwnerBusinesses(ownerId: string) {
  const snap = await db().collection("businesses").where("ownerId", "==", ownerId).get();
  for (const d of snap.docs) await syncBusinessVisibility(d.id);
}

export async function uniqueSlug(collection: "businesses" | "products" | "destinations" | "categories", base: string, excludeId?: string) {
  const root = base || "item";
  for (let i = 0; i < 20; i++) {
    const candidate = i === 0 ? root : `${root}-${i + 1}`;
    const s = await db().collection(collection).where("slug", "==", candidate).limit(1).get();
    if (s.empty || s.docs[0]!.id === excludeId) return candidate;
  }
  return `${root}-${Math.random().toString(36).slice(2, 6)}`;
}
