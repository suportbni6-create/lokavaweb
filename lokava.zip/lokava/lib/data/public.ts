import "server-only";
import { db, docPlain, plain, ts } from "@/lib/firebase/admin";
import { getEffectivePlan } from "@/lib/data/business-core";
import { tokenize } from "@/lib/utils/slug";
import {
  DEFAULT_SETTINGS, type AppSettings, type BannerDoc, type BusinessDoc, type CategoryDoc, type DestinationDoc,
  type ProductDoc, type PromotionDoc, type PromotionTypeDoc, type RegionDoc,
} from "@/types";

/** Jangan gagalkan halaman publik jika Firestore belum dikonfigurasi; catat tanpa membocorkan rahasia. */
export async function safe<T>(fn: () => Promise<T>, fallback: T): Promise<T> {
  try {
    return await fn();
  } catch (e) {
    console.error("[data]", e instanceof Error ? e.message.slice(0, 200) : "error");
    return fallback;
  }
}

export type PublicBusiness = Omit<BusinessDoc, "ownerId" | "subscriptionId" | "reviewNote" | "searchTokens" | "whatsapp"> & { whatsapp: string | null };
export function toPublicBusiness(b: BusinessDoc): PublicBusiness {
  const { ownerId: _o, subscriptionId: _s, reviewNote: _r, searchTokens: _t, ...rest } = b;
  void _o; void _s; void _r; void _t;
  return { ...rest, whatsapp: b.publicContact ? b.whatsapp : null };
}
export type PublicProduct = Omit<ProductDoc, "ownerId" | "searchTokens">;
const toPublicProduct = (p: ProductDoc): PublicProduct => {
  const { ownerId: _o, searchTokens: _t, ...rest } = p;
  void _o; void _t;
  return rest;
};

export async function getSettings(): Promise<AppSettings> {
  return safe(async () => {
    const s = await db().collection("appSettings").doc("default").get();
    return { ...DEFAULT_SETTINGS, ...(s.exists ? plain<Partial<AppSettings>>(s.data()) : {}) };
  }, DEFAULT_SETTINGS);
}

export const getCategories = () =>
  safe(async () => {
    const s = await db().collection("categories").where("active", "==", true).orderBy("sortOrder").limit(100).get();
    return s.docs.map((d) => docPlain<CategoryDoc>(d)!);
  }, [] as CategoryDoc[]);

export const getRegions = () =>
  safe(async () => {
    const s = await db().collection("regions").where("active", "==", true).orderBy("sortOrder").limit(100).get();
    return s.docs.map((d) => docPlain<RegionDoc>(d)!);
  }, [] as RegionDoc[]);

export interface BusinessQuery {
  district?: string;
  categoryIds?: string[];
  cursor?: string | null;
  limit?: number;
}

export async function listBusinesses(q: BusinessQuery = {}) {
  return safe(async () => {
    const limit = Math.min(q.limit ?? 12, 30);
    let query: FirebaseFirestore.Query = db().collection("businesses").where("visible", "==", true);
    if (q.district) query = query.where("district", "==", q.district);
    if (q.categoryIds?.length) query = query.where("categoryIds", "array-contains-any", q.categoryIds.slice(0, 30));
    query = query.orderBy("createdAt", "desc");
    if (q.cursor) query = query.startAfter(ts(new Date(q.cursor)));
    const snap = await query.limit(limit + 1).get();
    const items = snap.docs.slice(0, limit).map((d) => toPublicBusiness(docPlain<BusinessDoc>(d)!));
    const nextCursor = snap.docs.length > limit ? items[items.length - 1]!.createdAt : null;
    return { items, nextCursor };
  }, { items: [] as PublicBusiness[], nextCursor: null as string | null });
}

export const getBusinessBySlug = (slug: string) =>
  safe(async () => {
    const s = await db().collection("businesses").where("slug", "==", slug).where("visible", "==", true).limit(1).get();
    return s.empty ? null : toPublicBusiness(docPlain<BusinessDoc>(s.docs[0]!)!);
  }, null as PublicBusiness | null);

export const getBusinessProducts = (businessId: string) =>
  safe(async () => {
    const eff = await getEffectivePlan(businessId);
    const s = await db().collection("products").where("businessId", "==", businessId).where("visible", "==", true).orderBy("createdAt", "asc").limit(Math.min(eff.plan.maxProducts, 200)).get();
    return s.docs.map((d) => toPublicProduct(docPlain<ProductDoc>(d)!));
  }, [] as PublicProduct[]);

export const getProductBySlug = (slug: string) =>
  safe(async () => {
    const s = await db().collection("products").where("slug", "==", slug).where("visible", "==", true).limit(1).get();
    if (s.empty) return null;
    const p = toPublicProduct(docPlain<ProductDoc>(s.docs[0]!)!);
    const b = await db().collection("businesses").doc(p.businessId).get();
    if (!b.exists || !b.data()!.visible) return null;
    return { product: p, business: toPublicBusiness(docPlain<BusinessDoc>(b)!) };
  }, null as { product: PublicProduct; business: PublicBusiness } | null);

export const listFeaturedProducts = (limit = 8) =>
  safe(async () => {
    const s = await db().collection("products").where("visible", "==", true).orderBy("createdAt", "desc").limit(limit).get();
    return s.docs.map((d) => toPublicProduct(docPlain<ProductDoc>(d)!));
  }, [] as PublicProduct[]);

export async function listProducts(opts: { categoryId?: string; cursor?: string | null; limit?: number } = {}) {
  return safe(async () => {
    const limit = Math.min(opts.limit ?? 16, 40);
    let q: FirebaseFirestore.Query = db().collection("products").where("visible", "==", true);
    if (opts.categoryId) q = q.where("categoryId", "==", opts.categoryId);
    q = q.orderBy("createdAt", "desc");
    if (opts.cursor) q = q.startAfter(ts(new Date(opts.cursor)));
    const s = await q.limit(limit + 1).get();
    const items = s.docs.slice(0, limit).map((d) => toPublicProduct(docPlain<ProductDoc>(d)!));
    return { items, nextCursor: s.docs.length > limit ? items[items.length - 1]!.createdAt : null };
  }, { items: [] as PublicProduct[], nextCursor: null as string | null });
}

export interface ActivePromotion {
  promotion: PromotionDoc;
  type: PromotionTypeDoc | null;
  business: PublicBusiness;
  product: PublicProduct | null;
}

/** Validasi status & masa berlaku dilakukan di server, bukan di UI. */
export const getActivePromotions = (kinds?: string[]) =>
  safe(async () => {
    const nowTs = ts(new Date());
    const snap = await db().collection("promotions").where("status", "==", "active").where("expiresAt", ">", nowTs).orderBy("expiresAt", "asc").limit(60).get();
    const promos = snap.docs.map((d) => docPlain<PromotionDoc>(d)!).filter((p) => !kinds || kinds.includes(p.kind));
    const bizIds = [...new Set(promos.map((p) => p.businessId))];
    const bizMap = new Map<string, BusinessDoc>();
    for (let i = 0; i < bizIds.length; i += 30) {
      const s = await db().collection("businesses").where("__name__", "in", bizIds.slice(i, i + 30)).get();
      s.docs.forEach((d) => bizMap.set(d.id, docPlain<BusinessDoc>(d)!));
    }
    const prodIds = promos.map((p) => p.productId).filter(Boolean) as string[];
    const prodMap = new Map<string, ProductDoc>();
    for (let i = 0; i < prodIds.length; i += 30) {
      const s = await db().collection("products").where("__name__", "in", prodIds.slice(i, i + 30)).get();
      s.docs.forEach((d) => prodMap.set(d.id, docPlain<ProductDoc>(d)!));
    }
    const out: ActivePromotion[] = [];
    for (const p of promos) {
      const b = bizMap.get(p.businessId);
      if (!b || !b.visible) continue;
      const prod = p.productId ? prodMap.get(p.productId) : null;
      if (p.productId && (!prod || !prod.visible)) continue;
      out.push({ promotion: p, type: null, business: toPublicBusiness(b), product: prod ? toPublicProduct(prod) : null });
    }
    return out;
  }, [] as ActivePromotion[]);

export const getActiveBanners = () =>
  safe(async () => {
    const s = await db().collection("banners").where("active", "==", true).orderBy("sortOrder").limit(20).get();
    const t = Date.now();
    return s.docs
      .map((d) => docPlain<BannerDoc>(d)!)
      .filter((b) => (!b.startsAt || new Date(b.startsAt).getTime() <= t) && (!b.expiresAt || new Date(b.expiresAt).getTime() > t))
      .slice(0, 8);
  }, [] as BannerDoc[]);

export async function listDestinations(opts: { featured?: boolean; limit?: number; cursor?: string | null } = {}) {
  return safe(async () => {
    const limit = Math.min(opts.limit ?? 12, 30);
    let q: FirebaseFirestore.Query = db().collection("destinations").where("active", "==", true);
    if (opts.featured) q = q.where("featured", "==", true);
    q = q.orderBy("createdAt", "desc");
    if (opts.cursor) q = q.startAfter(ts(new Date(opts.cursor)));
    const s = await q.limit(limit + 1).get();
    const items = s.docs.slice(0, limit).map((d) => {
      const { searchTokens: _t, ...rest } = docPlain<DestinationDoc>(d)!;
      void _t;
      return rest;
    });
    return { items, nextCursor: s.docs.length > limit ? items[items.length - 1]!.createdAt : null };
  }, { items: [] as Omit<DestinationDoc, "searchTokens">[], nextCursor: null as string | null });
}

export const getDestinationBySlug = (slug: string) =>
  safe(async () => {
    const s = await db().collection("destinations").where("slug", "==", slug).where("active", "==", true).limit(1).get();
    if (s.empty) return null;
    const { searchTokens: _t, ...rest } = docPlain<DestinationDoc>(s.docs[0]!)!;
    void _t;
    return rest;
  }, null as Omit<DestinationDoc, "searchTokens"> | null);

export interface SearchFilters {
  q: string;
  categoryId?: string;
  district?: string;
  verified?: boolean;
  promoted?: boolean;
  minPrice?: number;
  maxPrice?: number;
}

/** Pencarian token sederhana (Firestore tidak punya full-text). Mengambil maksimal 60 kandidat per koleksi. */
export async function searchAll(f: SearchFilters) {
  return safe(async () => {
    const tokens = tokenize(f.q);
    const first = tokens[0];
    const need = tokens.slice(1);
    const match = (t: string[]) => need.every((n) => t.includes(n));

    const base = (c: string, extra: [string, FirebaseFirestore.WhereFilterOp, unknown][]) => {
      let q: FirebaseFirestore.Query = db().collection(c);
      for (const [a, b, v] of extra) q = q.where(a, b, v);
      if (first) q = q.where("searchTokens", "array-contains", first);
      return q.limit(60).get();
    };
    const [bs, ps, ds] = await Promise.all([
      base("businesses", [["visible", "==", true]]),
      base("products", [["visible", "==", true]]),
      base("destinations", [["active", "==", true]]),
    ]);
    let businesses = bs.docs.map((d) => docPlain<BusinessDoc>(d)!).filter((b) => match(b.searchTokens));
    let products = ps.docs.map((d) => docPlain<ProductDoc>(d)!).filter((p) => match(p.searchTokens));
    let destinations = ds.docs.map((d) => docPlain<DestinationDoc>(d)!).filter((x) => match(x.searchTokens));

    if (f.categoryId) {
      businesses = businesses.filter((b) => b.categoryIds.includes(f.categoryId!));
      products = products.filter((p) => p.categoryId === f.categoryId);
      destinations = destinations.filter((x) => x.categoryIds.includes(f.categoryId!));
    }
    if (f.district) {
      businesses = businesses.filter((b) => b.district === f.district);
      destinations = destinations.filter((x) => x.district === f.district);
    }
    if (f.minPrice !== undefined) products = products.filter((p) => p.price >= f.minPrice!);
    if (f.maxPrice !== undefined) products = products.filter((p) => p.price <= f.maxPrice!);
    if (f.verified) destinations = destinations.filter((x) => x.verified); // bisnis di direktori selalu terverifikasi
    if (f.promoted) {
      const promos = await getActivePromotions();
      const ids = new Set(promos.map((p) => p.business.id));
      businesses = businesses.filter((b) => ids.has(b.id));
      const pids = new Set(promos.map((p) => p.product?.id).filter(Boolean));
      products = products.filter((p) => pids.has(p.id));
      destinations = [];
    }
    return {
      businesses: businesses.slice(0, 20).map(toPublicBusiness),
      products: products.slice(0, 20).map(toPublicProduct),
      destinations: destinations.slice(0, 20).map(({ searchTokens: _t, ...r }) => { void _t; return r; }),
    };
  }, { businesses: [] as PublicBusiness[], products: [] as PublicProduct[], destinations: [] as Omit<DestinationDoc, "searchTokens">[] });
}

export interface MapPoint {
  id: string; kind: "bisnis" | "wisata"; name: string; slug: string; lat: number; lng: number;
  categoryIds: string[]; address: string;
}
export const getMapPoints = () =>
  safe(async () => {
    const [b, d] = await Promise.all([
      db().collection("businesses").where("visible", "==", true).limit(500).get(),
      db().collection("destinations").where("active", "==", true).limit(500).get(),
    ]);
    const pts: MapPoint[] = [];
    b.docs.forEach((x) => { const v = x.data(); if (typeof v.latitude === "number" && typeof v.longitude === "number") pts.push({ id: x.id, kind: "bisnis", name: v.name, slug: v.slug, lat: v.latitude, lng: v.longitude, categoryIds: v.categoryIds ?? [], address: v.address }); });
    d.docs.forEach((x) => { const v = x.data(); if (typeof v.latitude === "number" && typeof v.longitude === "number") pts.push({ id: x.id, kind: "wisata", name: v.name, slug: v.slug, lat: v.latitude, lng: v.longitude, categoryIds: v.categoryIds ?? [], address: v.address }); });
    return pts;
  }, [] as MapPoint[]);

export const getSitemapEntries = () =>
  safe(async () => {
    const [b, p, d] = await Promise.all([
      db().collection("businesses").where("visible", "==", true).limit(1000).get(),
      db().collection("products").where("visible", "==", true).limit(1000).get(),
      db().collection("destinations").where("active", "==", true).limit(1000).get(),
    ]);
    const pick = (s: FirebaseFirestore.QuerySnapshot) => s.docs.map((x) => ({ slug: x.data().slug as string, updatedAt: plain<string>(x.data().updatedAt) }));
    return { businesses: pick(b), products: pick(p), destinations: pick(d) };
  }, { businesses: [], products: [], destinations: [] } as { businesses: { slug: string; updatedAt: string }[]; products: { slug: string; updatedAt: string }[]; destinations: { slug: string; updatedAt: string }[] });
