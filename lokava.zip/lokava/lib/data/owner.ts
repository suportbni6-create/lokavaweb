import "server-only";
import { db, docPlain } from "@/lib/firebase/admin";
import type { BusinessDoc, ProductDoc, PromotionDoc, SubscriptionDoc, TransactionDoc } from "@/types";

export const getOwnerBusinesses = async (uid: string) => {
  const s = await db().collection("businesses").where("ownerId", "==", uid).orderBy("createdAt", "desc").limit(20).get();
  return s.docs.map((d) => docPlain<BusinessDoc>(d)!).filter((b) => !b.deletedAt);
};
export const getOwnerProducts = async (uid: string, businessId: string) => {
  const s = await db().collection("products").where("ownerId", "==", uid).where("businessId", "==", businessId).orderBy("createdAt", "desc").limit(300).get();
  return s.docs.map((d) => docPlain<ProductDoc>(d)!).filter((p) => !p.deletedAt);
};
export const getOwnerTransactions = async (uid: string) => {
  const s = await db().collection("transactions").where("ownerId", "==", uid).orderBy("createdAt", "desc").limit(50).get();
  return s.docs.map((d) => {
    const t = docPlain<TransactionDoc>(d)!;
    return { ...t, hasProof: Boolean(t.proof), proof: undefined as never };
  });
};
export const getOwnerPromotions = async (uid: string) => {
  const s = await db().collection("promotions").where("ownerId", "==", uid).orderBy("createdAt", "desc").limit(50).get();
  return s.docs.map((d) => docPlain<PromotionDoc>(d)!);
};
export const getOwnerSubscriptions = async (uid: string) => {
  const s = await db().collection("subscriptions").where("ownerId", "==", uid).orderBy("createdAt", "desc").limit(20).get();
  return s.docs.map((d) => docPlain<SubscriptionDoc>(d)!);
};

import type { CategoryDoc, PaymentMethodDoc, PlanDoc, PromotionTypeDoc, RegionDoc } from "@/types";
export const getPurchasables = async () => {
  const [plans, pms, types, cats, regions] = await Promise.all([
    db().collection("plans").where("active", "==", true).orderBy("sortOrder").get(),
    db().collection("paymentMethods").where("active", "==", true).orderBy("sortOrder").get(),
    db().collection("promotionTypes").where("active", "==", true).get(),
    db().collection("categories").where("active", "==", true).orderBy("sortOrder").get(),
    db().collection("regions").where("active", "==", true).orderBy("sortOrder").get(),
  ]);
  return {
    plans: plans.docs.map((d) => docPlain<PlanDoc>(d)!),
    paymentMethods: pms.docs.map((d) => docPlain<PaymentMethodDoc>(d)!),
    promotionTypes: types.docs.map((d) => docPlain<PromotionTypeDoc>(d)!),
    categories: cats.docs.map((d) => docPlain<CategoryDoc>(d)!),
    regions: regions.docs.map((d) => docPlain<RegionDoc>(d)!),
  };
};
