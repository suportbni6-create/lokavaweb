import "server-only";
import { db, docPlain, now } from "@/lib/firebase/admin";
import { HttpError } from "@/lib/auth/session";
import { audit } from "@/lib/audit";
import { assertOwnedAssets, deleteAssets, verifyAssets } from "@/lib/cloudinary";
import { getEffectivePlan, getFreePlan, syncBusinessVisibility, uniqueSlug } from "@/lib/data/business-core";
import { getSettings } from "@/lib/data/public";
import { onBusinessSubmitted } from "@/lib/admin/decisions";
import { limitMessage, limitsOf, withinLimit } from "@/lib/permissions/limits";
import { slugify, tokenize } from "@/lib/utils/slug";
import type { BusinessInput, ProductInput } from "@/lib/validation/schemas";
import type { BusinessDoc, ProductDoc, SessionUser } from "@/types";

const MAX_BUSINESSES_PER_OWNER = 3;

export async function saveBusiness(user: SessionUser, input: BusinessInput, existingId?: string) {
  const isAdmin = user.role === "admin";
  let existing: BusinessDoc | null = null;
  if (existingId) {
    existing = docPlain<BusinessDoc>(await db().collection("businesses").doc(existingId).get());
    if (!existing || existing.deletedAt || (!isAdmin && existing.ownerId !== user.uid)) throw new HttpError(404, "Bisnis tidak ditemukan.");
    if (!isAdmin && existing.verificationStatus === "suspended") throw new HttpError(403, "Bisnis ditangguhkan. Hubungi admin LOKAVA.");
  } else {
    if (isAdmin) throw new HttpError(400, "Admin tidak membuat bisnis baru dari sini.");
    const mine = await db().collection("businesses").where("ownerId", "==", user.uid).get();
    if (mine.docs.filter((d) => !d.data().deletedAt).length >= MAX_BUSINESSES_PER_OWNER) throw new HttpError(403, `Maksimal ${MAX_BUSINESSES_PER_OWNER} bisnis per akun.`);
  }
  const ownerId = existing?.ownerId ?? user.uid;

  // Validasi kategori ada & aktif
  const cats = await db().collection("categories").where("__name__", "in", input.categoryIds.slice(0, 10)).get();
  if (cats.size !== new Set(input.categoryIds).size || cats.docs.some((c) => !c.data().active)) throw new HttpError(400, "Ada kategori yang tidak valid.");

  // Batas foto dari konfigurasi paket di server
  const images = [...(input.coverImage ? [input.coverImage] : []), ...input.gallery];
  const resolved = existing ? (await getEffectivePlan(existing.id)).plan : await getFreePlan();
  if (!withinLimit(limitsOf(resolved), "businessPhotos", images.length)) throw new HttpError(403, limitMessage("businessPhotos", resolved.maxBusinessPhotos));
  if (!isAdmin) assertOwnedAssets(images.map((i) => i.publicId), ["business"], user.uid);
  const oldIds = new Set([...(existing?.coverImage ? [existing.coverImage.publicId] : []), ...(existing?.gallery.map((g) => g.publicId) ?? [])]);
  await verifyAssets(images.map((i) => i.publicId).filter((id) => !oldIds.has(id)));

  const sensitiveChanged = existing && (existing.name !== input.name || existing.address !== input.address || existing.district !== input.district || existing.region !== input.region);
  const settings = await getSettings();
  const { submit, ...fields } = input;
  const data: Record<string, unknown> = {
    ...fields, ownerId,
    searchTokens: tokenize(input.name, input.description, input.village, input.district, input.region, ...cats.docs.map((c) => c.data().name as string)),
    updatedAt: now(),
  };

  let status: BusinessDoc["verificationStatus"] = existing?.verificationStatus ?? "draft";
  if (!isAdmin) {
    if (submit && ["draft", "needs_correction", "rejected"].includes(status)) status = "pending";
    else if (existing?.verificationStatus === "approved" && sensitiveChanged && settings.reverifyOnSensitiveChange) status = "pending";
  }
  data.verificationStatus = status;

  let id = existingId ?? "";
  if (existing) {
    if (existing.name !== input.name) data.slug = await uniqueSlug("businesses", slugify(input.name), existing.id);
    if (status === "pending" && existing.verificationStatus !== "pending") data.publicationStatus = "unpublished";
    await db().collection("businesses").doc(existing.id).update(data);
  } else {
    const ref = db().collection("businesses").doc();
    id = ref.id;
    await ref.set({
      ...data, slug: await uniqueSlug("businesses", slugify(input.name)), publicationStatus: "unpublished", reviewNote: null,
      visible: false, subscriptionId: null, createdAt: now(), deletedAt: null,
    });
  }
  // Hapus foto lama yang dibuang pemilik
  const newIds = new Set(images.map((i) => i.publicId));
  const removed = [...oldIds].filter((x) => !newIds.has(x));
  if (removed.length) await deleteAssets(removed).catch(() => undefined);

  await syncBusinessVisibility(id);
  await audit({ actorId: user.uid, action: existing ? "business.update" : "business.create", targetType: "business", targetId: id, summary: `${input.name} (${status})` });

  const saved = docPlain<BusinessDoc>(await db().collection("businesses").doc(id).get())!;
  if (status === "pending" && existing?.verificationStatus !== "pending") await onBusinessSubmitted(saved, user.displayName);
  return saved;
}

export async function saveProduct(user: SessionUser, input: ProductInput, existingId?: string) {
  const bsnap = await db().collection("businesses").doc(input.businessId).get();
  const b = docPlain<BusinessDoc>(bsnap);
  if (!b || b.ownerId !== user.uid || b.deletedAt) throw new HttpError(404, "Bisnis tidak ditemukan.");
  if (b.verificationStatus === "suspended") throw new HttpError(403, "Bisnis ditangguhkan.");

  const eff = (await getEffectivePlan(b.id)).plan;
  let existing: ProductDoc | null = null;
  if (existingId) {
    existing = docPlain<ProductDoc>(await db().collection("products").doc(existingId).get());
    if (!existing || existing.ownerId !== user.uid || existing.deletedAt || existing.businessId !== b.id) throw new HttpError(404, "Produk tidak ditemukan.");
  } else {
    const count = (await db().collection("products").where("businessId", "==", b.id).get()).docs.filter((d) => !d.data().deletedAt).length;
    if (!withinLimit(limitsOf(eff), "products", count + 1)) throw new HttpError(403, limitMessage("products", eff.maxProducts));
  }
  if (!withinLimit(limitsOf(eff), "productPhotos", input.images.length)) throw new HttpError(403, limitMessage("productPhotos", eff.maxProductPhotos));
  assertOwnedAssets(input.images.map((i) => i.publicId), ["product"], user.uid);
  const oldIds = new Set(existing?.images.map((i) => i.publicId) ?? []);
  await verifyAssets(input.images.map((i) => i.publicId).filter((x) => !oldIds.has(x)));
  if (input.categoryId) {
    const c = await db().collection("categories").doc(input.categoryId).get();
    if (!c.exists || !c.data()!.active) throw new HttpError(400, "Kategori tidak valid.");
  }

  const visible = Boolean(b.visible && input.status === "active");
  const base = {
    ...input, ownerId: user.uid, visible,
    searchTokens: tokenize(input.name, input.description, b.name, b.district),
    updatedAt: now(),
  };
  let id = existingId ?? "";
  if (existing) {
    await db().collection("products").doc(existing.id).update({ ...base, ...(existing.name !== input.name ? { slug: await uniqueSlug("products", slugify(input.name), existing.id) } : {}) });
  } else {
    const ref = db().collection("products").doc();
    id = ref.id;
    await ref.set({ ...base, slug: await uniqueSlug("products", slugify(input.name)), createdAt: now(), deletedAt: null });
  }
  const keep = new Set(input.images.map((i) => i.publicId));
  const removed = [...oldIds].filter((x) => !keep.has(x));
  if (removed.length) await deleteAssets(removed).catch(() => undefined);
  await audit({ actorId: user.uid, action: existing ? "product.update" : "product.create", targetType: "product", targetId: id, summary: `${input.name} Rp${input.price}` });
  return docPlain<ProductDoc>(await db().collection("products").doc(id).get())!;
}

export async function deleteProduct(user: SessionUser, id: string) {
  const ref = db().collection("products").doc(id);
  const p = docPlain<ProductDoc>(await ref.get());
  if (!p || p.ownerId !== user.uid || p.deletedAt) throw new HttpError(404, "Produk tidak ditemukan.");
  await ref.update({ status: "inactive", visible: false, deletedAt: now(), updatedAt: now() });
  const promos = await db().collection("promotions").where("productId", "==", id).where("status", "in", ["active", "under_review", "pending_payment"]).get();
  for (const d of promos.docs) await d.ref.update({ status: "deactivated", updatedAt: now() });
  await deleteAssets(p.images.map((i) => i.publicId)).catch(() => undefined);
  await audit({ actorId: user.uid, action: "product.delete", targetType: "product", targetId: id, summary: p.name });
}
