import { describe, expect, it } from "vitest";
import { decryptSecret, encryptSecret, safeEqual } from "@/lib/crypto";

const KEY = "a".repeat(64);

describe("enkripsi rahasia", () => {
  it("round-trip dan tidak memuat teks asli", () => {
    const enc = encryptSecret("123456:ABC-token", KEY);
    expect(enc).not.toContain("ABC-token");
    expect(decryptSecret(enc, KEY)).toBe("123456:ABC-token");
  });
  it("IV acak: dua enkripsi berbeda", () => {
    expect(encryptSecret("x", KEY)).not.toBe(encryptSecret("x", KEY));
  });
  it("gagal bila kunci salah atau data diubah", () => {
    const enc = encryptSecret("rahasia", KEY);
    expect(() => decryptSecret(enc, "b".repeat(64))).toThrow();
    const parts = enc.split(".");
    parts[3] = Buffer.from("rusak").toString("base64url");
    expect(() => decryptSecret(parts.join("."), KEY)).toThrow();
  });
  it("menolak kunci yang bukan 64 hex", () => {
    expect(() => encryptSecret("x", "pendek")).toThrow();
  });
  it("safeEqual", () => {
    expect(safeEqual("abc", "abc")).toBe(true);
    expect(safeEqual("abc", "abd")).toBe(false);
    expect(safeEqual("", "abc")).toBe(false);
  });
});
