import { describe, expect, it } from "vitest";
import { buildWhatsappLink, normalizeWhatsapp, whatsappMessage } from "@/lib/utils/whatsapp";

describe("nomor WhatsApp", () => {
  it("menormalkan berbagai format ke 62", () => {
    expect(normalizeWhatsapp("0812 3456 7890")).toBe("6281234567890");
    expect(normalizeWhatsapp("+62 812-3456-7890")).toBe("6281234567890");
    expect(normalizeWhatsapp("81234567890")).toBe("6281234567890");
  });
  it("menolak nomor tidak valid", () => {
    for (const bad of ["", "abc", "12345", "0211234567", "+1 202 555 0100", "0812", "62812345678901234"]) expect(normalizeWhatsapp(bad)).toBeNull();
    expect(normalizeWhatsapp(null)).toBeNull();
  });
  it("pesan di-encode sehingga karakter khusus tidak merusak tautan", () => {
    const link = buildWhatsappLink("6281234567890", 'Halo & "tes" #1?');
    expect(link).toBe("https://wa.me/6281234567890?text=Halo%20%26%20%22tes%22%20%231%3F");
    expect(new URL(link).searchParams.get("text")).toBe('Halo & "tes" #1?');
  });
  it("pesan memuat nama produk bila ada", () => {
    expect(whatsappMessage("harga", { productName: "Ikan Bakar" })).toContain('"Ikan Bakar"');
    expect(whatsappMessage("umum")).toContain("melalui LOKAVA");
  });
});
