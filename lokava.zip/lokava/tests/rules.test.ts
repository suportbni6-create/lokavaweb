// Pengujian Firestore Security Rules. Butuh emulator: npm run test:rules
import { readFileSync } from "node:fs";
import { afterAll, beforeAll, describe, it } from "vitest";
import { assertFails, assertSucceeds, initializeTestEnvironment, type RulesTestEnvironment } from "@firebase/rules-unit-testing";
import { doc, getDoc, setDoc, updateDoc, deleteDoc, collection, getDocs } from "firebase/firestore";

let env: RulesTestEnvironment;

beforeAll(async () => {
  env = await initializeTestEnvironment({ projectId: "lokava-test", firestore: { rules: readFileSync("firestore.rules", "utf8"), host: "127.0.0.1", port: 8080 } });
  await env.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore();
    await setDoc(doc(db, "users/owner1"), { role: "owner", status: "active" });
    await setDoc(doc(db, "users/owner2"), { role: "owner", status: "active" });
    await setDoc(doc(db, "businesses/b1"), { ownerId: "owner1", name: "A", verificationStatus: "pending" });
    await setDoc(doc(db, "transactions/t1"), { ownerId: "owner1", amount: 50000, status: "pending_payment" });
    await setDoc(doc(db, "transactions/t2"), { ownerId: "owner2", amount: 25000, status: "pending_payment" });
    await setDoc(doc(db, "auditLogs/l1"), { actorId: "x" });
    await setDoc(doc(db, "telegramSecrets/default"), { botTokenEnc: "v1.x.y.z" });
    await setDoc(doc(db, "plans/free"), { price: 0 });
  });
});
afterAll(async () => env?.cleanup());

describe("Firestore rules (default-deny)", () => {
  it("pengunjung tidak dapat membaca data privat", async () => {
    const db = env.unauthenticatedContext().firestore();
    await assertFails(getDoc(doc(db, "users/owner1")));
    await assertFails(getDoc(doc(db, "transactions/t1")));
    await assertFails(getDoc(doc(db, "businesses/b1")));
    await assertFails(getDocs(collection(db, "transactions")));
  });
  it("pemilik membaca datanya sendiri, bukan milik orang lain", async () => {
    const db = env.authenticatedContext("owner1").firestore();
    await assertSucceeds(getDoc(doc(db, "users/owner1")));
    await assertSucceeds(getDoc(doc(db, "transactions/t1")));
    await assertFails(getDoc(doc(db, "transactions/t2")));
    await assertFails(getDoc(doc(db, "users/owner2")));
  });
  it("pemilik tidak dapat mengubah role menjadi admin", async () => {
    const db = env.authenticatedContext("owner1").firestore();
    await assertFails(updateDoc(doc(db, "users/owner1"), { role: "admin" }));
    await assertFails(setDoc(doc(db, "users/owner1"), { role: "admin", status: "active" }));
  });
  it("pemilik tidak dapat mengubah nominal atau menyetujui transaksi sendiri", async () => {
    const db = env.authenticatedContext("owner1").firestore();
    await assertFails(updateDoc(doc(db, "transactions/t1"), { amount: 1 }));
    await assertFails(updateDoc(doc(db, "transactions/t1"), { status: "approved" }));
    await assertFails(setDoc(doc(db, "transactions/baru"), { ownerId: "owner1", amount: 1, status: "approved" }));
  });
  it("pemilik tidak dapat mengubah status verifikasi bisnis", async () => {
    const db = env.authenticatedContext("owner1").firestore();
    await assertFails(updateDoc(doc(db, "businesses/b1"), { verificationStatus: "approved" }));
    await assertFails(deleteDoc(doc(db, "businesses/b1")));
  });
  it("audit log, rahasia, dan konfigurasi tertutup untuk semua klien", async () => {
    const db = env.authenticatedContext("owner1").firestore();
    await assertFails(getDoc(doc(db, "auditLogs/l1")));
    await assertFails(setDoc(doc(db, "auditLogs/l2"), { actorId: "owner1" }));
    await assertFails(getDoc(doc(db, "telegramSecrets/default")));
    await assertFails(setDoc(doc(db, "plans/free"), { price: 0 }));
  });
});
