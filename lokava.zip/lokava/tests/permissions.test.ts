import { describe, expect, it } from "vitest";
import { canDecideTransaction, canManageResource, isAdmin } from "@/lib/permissions";

const owner = { uid: "u1", role: "owner" as const, status: "active" as const };
const admin = { uid: "a1", role: "admin" as const, status: "active" as const };

describe("izin", () => {
  it("pemilik hanya mengelola miliknya", () => {
    expect(canManageResource(owner, { ownerId: "u1" })).toBe(true);
    expect(canManageResource(owner, { ownerId: "u2" })).toBe(false);
  });
  it("akun ditangguhkan tidak dapat mengelola apa pun", () => {
    expect(canManageResource({ ...owner, status: "suspended" }, { ownerId: "u1" })).toBe(false);
    expect(isAdmin({ ...admin, status: "suspended" })).toBe(false);
  });
  it("pemilik tidak bisa menyetujui transaksi; admin tidak bisa menyetujui miliknya sendiri", () => {
    expect(canDecideTransaction(owner, { ownerId: "u1" })).toBe(false);
    expect(canDecideTransaction(admin, { ownerId: "a1" })).toBe(false);
    expect(canDecideTransaction(admin, { ownerId: "u1" })).toBe(true);
  });
});
