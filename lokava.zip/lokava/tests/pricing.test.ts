import { describe, expect, it } from "vitest";
import { PricingError, addDays, generateTransactionNumber, planCharge, promotionCharge } from "@/lib/payments/pricing";

const type = { basePrice: 20000, baseDays: 7, durations: [7, 14, 21, 30], active: true };

describe("harga dihitung server", () => {
  it("harga paket mengikuti konfigurasi, bukan input klien", () => {
    expect(planCharge({ price: 25000, durationDays: 30 })).toEqual({ amount: 25000, durationDays: 30 });
    // Perubahan harga oleh admin langsung tercermin
    expect(planCharge({ price: 30000, durationDays: 30 }).amount).toBe(30000);
  });
  it("promosi 7 hari = harga dasar; durasi lain proporsional", () => {
    expect(promotionCharge(type, 7).amount).toBe(20000);
    expect(promotionCharge(type, 14).amount).toBe(40000);
    expect(promotionCharge(type, 30).amount).toBe(85714);
  });
  it("override harga per durasi dipakai bila ada", () => {
    expect(promotionCharge({ ...type, durationPrices: { "30": 70000 } }, 30).amount).toBe(70000);
  });
  it("menolak durasi yang tidak tersedia dan jenis nonaktif", () => {
    expect(() => promotionCharge(type, 10)).toThrow(PricingError);
    expect(() => promotionCharge(type, 0)).toThrow(PricingError);
    expect(() => promotionCharge(type, 7.5)).toThrow(PricingError);
    expect(() => promotionCharge({ ...type, active: false }, 7)).toThrow(PricingError);
  });
  it("masa berlaku dihitung dari waktu persetujuan", () => {
    const start = new Date("2026-10-12T00:00:00Z");
    expect(addDays(start, 7).toISOString()).toBe("2026-10-19T00:00:00.000Z");
  });
  it("nomor transaksi berformat LKV-YYYYMMDD-XXXXXX", () => {
    expect(generateTransactionNumber(new Date("2026-10-12T05:00:00Z"), () => 0)).toBe("LKV-20261012-AAAAAA");
    expect(generateTransactionNumber()).toMatch(/^LKV-\d{8}-[A-Z2-9]{6}$/);
  });
});
