import { describe, expect, it } from "vitest";
import { formatRupiah, formatTanggal, sisaHari } from "@/lib/utils/format";
import { slugify, tokenize } from "@/lib/utils/slug";
import { assessBusiness } from "@/lib/admin/assess";

describe("format Indonesia", () => {
  it("rupiah", () => {
    expect(formatRupiah(25000).replace(/\s/g, " ")).toMatch(/^Rp\s?25\.000$/);
    expect(formatRupiah(null)).toBe("-");
  });
  it("tanggal Indonesia", () => {
    expect(formatTanggal("2026-10-12T05:00:00Z")).toBe("12 Oktober 2026");
    expect(formatTanggal(null)).toBe("-");
  });
  it("sisa hari", () => {
    expect(sisaHari("2026-10-19T00:00:00Z", new Date("2026-10-12T00:00:00Z"))).toBe(7);
    expect(sisaHari(null)).toBeNull();
  });
});

describe("slug & token", () => {
  it("slug ramah URL", () => {
    expect(slugify("Warung Ikan Bakar & Seafood Ujung Genteng!")).toBe("warung-ikan-bakar-dan-seafood-ujung-genteng");
    expect(slugify("  Café   Pantai  ")).toBe("cafe-pantai");
  });
  it("token pencarian unik dan huruf kecil", () => {
    expect(tokenize("Seafood Segar", "seafood")).toEqual(["seafood", "segar"]);
  });
});

describe("penilaian kelengkapan bisnis", () => {
  const base = { name: "Warung Laut", description: "Warung seafood di tepi pantai dengan menu segar.", address: "Jl. Pantai", village: "Ciwaru", district: "Ciracap", region: "Sukabumi Selatan", whatsapp: "6281234567890", coverImage: { url: "https://x/y.jpg", publicId: "lokava/business/u/y" }, categoryIds: ["seafood"], latitude: -7.3, longitude: 106.4 };
  it("lengkap tanpa tanda curiga", () => {
    const a = assessBusiness(base);
    expect(a.complete).toBe(true);
    expect(a.flags).toEqual([]);
  });
  it("menyebut data yang kurang", () => {
    const a = assessBusiness({ ...base, whatsapp: null, coverImage: null });
    expect(a.complete).toBe(false);
    expect(a.missing).toEqual(["WhatsApp", "foto utama"]);
  });
  it("menandai koordinat janggal dan deskripsi bertautan untuk pemeriksaan manusia", () => {
    expect(assessBusiness({ ...base, latitude: 40, longitude: -74 }).flags).toContain("koordinat di luar Pulau Jawa");
    expect(assessBusiness({ ...base, description: "Kunjungi http://spam.example untuk promo besar" }).flags).toContain("deskripsi berisi tautan");
    expect(assessBusiness({ ...base, latitude: null, longitude: null }).flags).toContain("koordinat belum diisi");
  });
});
