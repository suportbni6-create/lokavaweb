import { describe, expect, it } from "vitest";
import { limitsOf, resolveEffectivePlan, withinLimit, type PlanLike } from "@/lib/permissions/limits";

const free: PlanLike = { id: "free", name: "FREE", price: 0, durationDays: 0, maxBusinessPhotos: 3, maxProducts: 5, maxProductPhotos: 1, maxPromotions: 0, features: [] };
const premium: PlanLike = { id: "premium", name: "PREMIUM", price: 25000, durationDays: 30, maxBusinessPhotos: 10, maxProducts: 50, maxProductPhotos: 5, maxPromotions: 1, features: [] };
const now = new Date("2026-10-12T00:00:00Z");

describe("batas paket", () => {
  it("memeriksa jumlah terhadap batas", () => {
    const l = limitsOf(free);
    expect(withinLimit(l, "products", 5)).toBe(true);
    expect(withinLimit(l, "products", 6)).toBe(false);
    expect(withinLimit(l, "productPhotos", 2)).toBe(false);
    expect(withinLimit(l, "promotions", 1)).toBe(false);
  });
  it("langganan aktif memakai batas paketnya", () => {
    const r = resolveEffectivePlan({ status: "active", expiresAt: "2026-11-01T00:00:00Z", planSnapshot: premium }, free, now);
    expect(r.plan.maxProducts).toBe(50);
    expect(r.expired).toBe(false);
  });
  it("langganan kedaluwarsa jatuh ke batas gratis tanpa menghapus data", () => {
    const r = resolveEffectivePlan({ status: "active", expiresAt: "2026-10-01T00:00:00Z", planSnapshot: premium }, free, now);
    expect(r.plan.maxProducts).toBe(5);
    expect(r.expired).toBe(true);
  });
  it("tanpa langganan memakai paket gratis; paket tanpa kedaluwarsa tetap aktif", () => {
    expect(resolveEffectivePlan(null, free, now).plan.id).toBe("free");
    expect(resolveEffectivePlan({ status: "active", expiresAt: null, planSnapshot: free }, free, now).expired).toBe(false);
    expect(resolveEffectivePlan({ status: "replaced", expiresAt: null, planSnapshot: premium }, free, now).plan.id).toBe("free");
  });
});
