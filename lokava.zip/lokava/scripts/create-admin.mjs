// Menjadikan akun yang SUDAH terdaftar sebagai admin. Dijalankan manual oleh pemilik proyek:
//   npm run create-admin -- email@anda.com
// Tidak ada endpoint publik untuk membuat admin.
import { init } from "./_admin.mjs";

const email = process.argv[2];
if (!email) { console.error("Pemakaian: npm run create-admin -- email@anda.com"); process.exit(1); }
const { auth, db } = init();
const user = await auth.getUserByEmail(email).catch(() => null);
if (!user) { console.error("Akun belum ada. Daftar dulu lewat /register, lalu jalankan ulang."); process.exit(1); }
const admins = await db.collection("users").where("role", "==", "admin").limit(1).get();
const first = admins.empty;
const now = new Date();
await db.collection("users").doc(user.uid).set(
  { uid: user.uid, email, displayName: user.displayName ?? "Admin LOKAVA", role: "admin", status: "active", superAdmin: first || undefined, createdAt: now, updatedAt: now },
  { merge: true },
);
await auth.setCustomUserClaims(user.uid, { role: "admin" });
console.log(`✔ ${email} sekarang admin${first ? " utama" : ""}. Keluar lalu masuk lagi.`);
