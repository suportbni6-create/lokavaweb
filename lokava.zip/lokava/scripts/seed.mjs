// Mengisi data konfigurasi awal (kategori, paket, jenis promosi, wilayah). BUKAN data bisnis/wisata.
// Aman dijalankan ulang: dokumen yang sudah ada tidak ditimpa.
import { init } from "./_admin.mjs";

const { db } = init();
const now = new Date();
const base = { createdAt: now, updatedAt: now };

const categories = [
  ["wisata", "Wisata", "wisata", "🏝️"], ["pantai", "Pantai", "wisata", "🌊"], ["wisata-alam", "Wisata alam", "wisata", "🌴"],
  ["kuliner", "Kuliner", "kuliner", "🍽️"], ["seafood", "Seafood", "kuliner", "🦐"],
  ["penginapan", "Penginapan", "penginapan", "🛏️"], ["hotel", "Hotel", "penginapan", "🏨"], ["homestay", "Homestay", "penginapan", "🏡"],
  ["umkm", "UMKM", "umkm", "🧺"], ["produk-lokal", "Produk lokal", "umkm", "🛍️"], ["hasil-laut", "Hasil laut", "umkm", "🐟"],
  ["jasa", "Jasa", "jasa", "🛠️"], ["transportasi", "Transportasi", "jasa", "🚐"], ["layanan-wisata", "Layanan wisata", "jasa", "🧭"],
];
const plans = [
  ["free", { name: "FREE", description: "Profil bisnis dasar.", price: 0, durationDays: 0, maxBusinessPhotos: 3, maxProducts: 5, maxProductPhotos: 1, maxPromotions: 0, features: ["Profil bisnis dasar", "Tampil di direktori"], sortOrder: 0 }],
  ["premium", { name: "PREMIUM", description: "Lebih banyak foto dan produk.", price: 25000, durationDays: 30, maxBusinessPhotos: 10, maxProducts: 50, maxProductPhotos: 5, maxPromotions: 1, features: ["Hingga 50 produk", "Ajukan 1 promosi"], sortOrder: 1 }],
  ["business", { name: "BUSINESS", description: "Untuk usaha yang aktif berpromosi.", price: 50000, durationDays: 30, maxBusinessPhotos: 20, maxProducts: 200, maxProductPhotos: 8, maxPromotions: 5, features: ["Hingga 200 produk", "Beberapa promosi"], sortOrder: 2 }],
];
const promoTypes = [
  ["promo-produk", { kind: "product", name: "Promosi produk", description: "Produk tampil di bagian promosi.", basePrice: 20000, baseDays: 7, durations: [7, 14, 21, 30], slotLimit: 0, requirements: {} }],
  ["promo-kategori", { kind: "category", name: "Promosi kategori", description: "Tampil sebagai unggulan di kategori.", basePrice: 30000, baseDays: 7, durations: [7, 14, 21, 30], slotLimit: 0, requirements: {} }],
  ["promo-unggulan", { kind: "featured_business", name: "Bisnis unggulan", description: "Tampil di bagian unggulan beranda dan direktori.", basePrice: 50000, baseDays: 7, durations: [7, 14, 21, 30], slotLimit: 0, requirements: {} }],
  ["promo-banner", { kind: "home_banner", name: "Banner beranda", description: "Banner di halaman utama.", basePrice: 100000, baseDays: 7, durations: [7, 14, 21, 30], slotLimit: 5, requirements: {} }],
];
const regions = [["ujunggenteng", "Ujunggenteng", "Ciracap"], ["ciracap", "Ciracap", "Ciracap"]];

async function put(col, id, data) {
  const ref = db.collection(col).doc(id);
  if ((await ref.get()).exists) return console.log(`• ${col}/${id} sudah ada, dilewati`);
  await ref.set({ ...data, ...base });
  console.log(`✔ ${col}/${id}`);
}
let i = 0;
for (const [id, name, group, icon] of categories) await put("categories", id, { name, slug: id, description: "", icon, group, image: null, active: true, sortOrder: i++ });
for (const [id, p] of plans) await put("plans", id, { ...p, active: true });
for (const [id, p] of promoTypes) await put("promotionTypes", id, { ...p, active: true });
i = 0;
for (const [id, name, district] of regions) await put("regions", id, { name, district, active: true, sortOrder: i++ });
await put("telegramSettings", "default", { enabled: false, destinationChatId: "", allowedAdminIds: [], verificationMode: "assisted", notifications: { business: true, payment: true, decisions: true, errors: true } });
console.log("Selesai. Metode pembayaran, destinasi wisata, dan data bisnis diisi admin lewat dashboard.");
