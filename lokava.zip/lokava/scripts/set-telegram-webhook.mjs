// Memasang webhook Telegram ke URL production. Jalankan SETELAH deployment dan setelah rahasia diisi.
const { TELEGRAM_BOT_TOKEN, TELEGRAM_WEBHOOK_SECRET, NEXT_PUBLIC_APP_URL } = process.env;
if (!TELEGRAM_BOT_TOKEN || !TELEGRAM_WEBHOOK_SECRET || !NEXT_PUBLIC_APP_URL?.startsWith("https://")) {
  console.error("Butuh TELEGRAM_BOT_TOKEN, TELEGRAM_WEBHOOK_SECRET, dan NEXT_PUBLIC_APP_URL (https). Webhook tidak dipasang.");
  process.exit(1);
}
const res = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/setWebhook`, {
  method: "POST", headers: { "content-type": "application/json" },
  body: JSON.stringify({ url: `${NEXT_PUBLIC_APP_URL.replace(/\/$/, "")}/api/telegram/webhook`, secret_token: TELEGRAM_WEBHOOK_SECRET, allowed_updates: ["callback_query", "message"], drop_pending_updates: true }),
});
const j = await res.json();
console.log(j.ok ? "✔ Webhook terpasang." : `✘ Gagal: ${j.description}`);
