// Tipe domain LOKAVA. Tanggal dikirim ke klien sebagai string ISO.

export type Role = "owner" | "admin";
export type UserStatus = "active" | "suspended" | "deletion_requested" | "deleted";

export interface ImageAsset {
  url: string;
  publicId: string;
}

export interface UserDoc {
  uid: string;
  email: string;
  displayName: string;
  phone?: string;
  role: Role;
  status: UserStatus;
  createdAt: string;
  updatedAt: string;
  deletionRequestedAt?: string | null;
}

export type VerificationStatus =
  | "draft"
  | "pending"
  | "needs_correction"
  | "approved"
  | "rejected"
  | "suspended"
  | "deleted";
export type PublicationStatus = "published" | "unpublished";

export interface OpeningHour {
  day: "Senin" | "Selasa" | "Rabu" | "Kamis" | "Jumat" | "Sabtu" | "Minggu";
  open: string; // "08:00"
  close: string; // "17:00"
  closed: boolean;
}

export interface BusinessDoc {
  id: string;
  ownerId: string;
  name: string;
  slug: string;
  description: string;
  categoryIds: string[];
  address: string;
  village: string;
  district: string;
  region: string;
  latitude: number | null;
  longitude: number | null;
  whatsapp: string | null; // format 62xxxxxxxxxx
  publicContact: boolean;
  openingHours: OpeningHour[];
  coverImage: ImageAsset | null;
  gallery: ImageAsset[];
  verificationStatus: VerificationStatus;
  publicationStatus: PublicationStatus;
  reviewNote?: string | null;
  visible: boolean; // hasil denormalisasi: approved + published + pemilik aktif + tidak dihapus
  subscriptionId?: string | null;
  searchTokens: string[];
  createdAt: string;
  updatedAt: string;
  deletedAt?: string | null;
}

export type ProductStatus = "active" | "inactive";
export interface ProductDoc {
  id: string;
  businessId: string;
  ownerId: string;
  name: string;
  slug: string;
  description: string;
  price: number;
  categoryId: string | null;
  kind: "produk" | "menu" | "layanan" | "kamar";
  availability: "tersedia" | "habis" | "pesan_dulu";
  images: ImageAsset[];
  status: ProductStatus;
  visible: boolean;
  searchTokens: string[];
  createdAt: string;
  updatedAt: string;
  deletedAt?: string | null;
}

export interface PlanDoc {
  id: string;
  name: string;
  description: string;
  price: number;
  durationDays: number; // 0 = tidak berakhir (paket gratis)
  maxBusinessPhotos: number;
  maxProducts: number;
  maxProductPhotos: number;
  maxPromotions: number;
  features: string[];
  active: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
}

export type SubscriptionStatus = "active" | "expired" | "replaced" | "cancelled";
export interface SubscriptionDoc {
  id: string;
  ownerId: string;
  businessId: string;
  planId: string;
  planSnapshot: Omit<PlanDoc, "createdAt" | "updatedAt" | "active" | "sortOrder" | "description">;
  status: SubscriptionStatus;
  startsAt: string;
  expiresAt: string | null;
  transactionId: string | null;
  createdAt: string;
  updatedAt: string;
}

export type PromotionKind = "product" | "category" | "featured_business" | "home_banner";
export const PROMOTION_KIND_LABEL: Record<PromotionKind, string> = {
  product: "Promosi produk",
  category: "Promosi kategori",
  featured_business: "Bisnis unggulan",
  home_banner: "Banner beranda",
};

export interface PromotionTypeDoc {
  id: string;
  kind: PromotionKind;
  name: string;
  description: string;
  basePrice: number; // harga untuk baseDays
  baseDays: number;
  durations: number[]; // hari
  durationPrices?: Record<string, number>; // override harga per durasi
  active: boolean;
  slotLimit: number; // 0 = tanpa batas
  requirements: { minPlanSortOrder?: number };
  createdAt: string;
  updatedAt: string;
}

export type PromotionStatus = "pending_payment" | "under_review" | "active" | "expired" | "rejected" | "cancelled" | "deactivated";
export interface PromotionDoc {
  id: string;
  ownerId: string;
  businessId: string;
  productId: string | null;
  categoryId: string | null;
  promotionTypeId: string;
  kind: PromotionKind;
  durationDays: number;
  amount: number;
  bannerImage: ImageAsset | null;
  status: PromotionStatus;
  startsAt: string | null;
  expiresAt: string | null;
  transactionId: string;
  createdAt: string;
  updatedAt: string;
}

export type TransactionStatus =
  | "pending_payment"
  | "proof_submitted"
  | "under_review"
  | "approved"
  | "rejected"
  | "expired"
  | "cancelled";
export const TRANSACTION_STATUS_LABEL: Record<TransactionStatus, string> = {
  pending_payment: "Menunggu pembayaran",
  proof_submitted: "Bukti dikirim",
  under_review: "Sedang diperiksa",
  approved: "Disetujui",
  rejected: "Ditolak",
  expired: "Kedaluwarsa",
  cancelled: "Dibatalkan",
};

export interface TransactionDoc {
  id: string;
  transactionNumber: string;
  ownerId: string;
  ownerName: string;
  businessId: string;
  businessName: string;
  type: "subscription" | "promotion";
  planId: string | null;
  promotionId: string | null;
  title: string; // ringkasan, mis. "Paket PREMIUM" atau "Bisnis unggulan 7 hari"
  amount: number;
  priceSnapshot: number;
  durationSnapshot: number;
  paymentMethodId: string | null;
  planSnapshot?: SubscriptionDoc["planSnapshot"] | null;
  paymentMethodSnapshot: { name: string; provider: string; accountName: string; accountNumber: string } | null;
  proof: { publicId: string; format: string; bytes: number } | null;
  proofNote: string | null;
  proofAttempts: number;
  status: TransactionStatus;
  approvedBy: string | null;
  approvedAt: string | null;
  rejectionReason: string | null;
  statusHistory: { status: TransactionStatus; at: string; by: string; note?: string }[];
  expiresAt: string; // batas waktu menunggu pembayaran
  createdAt: string;
  updatedAt: string;
}

export interface PaymentMethodDoc {
  id: string;
  name: string;
  provider: string;
  accountName: string;
  accountNumber: string;
  instructions: string;
  qrImage: ImageAsset | null;
  active: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
}

export interface CategoryDoc {
  id: string;
  name: string;
  slug: string;
  description: string;
  icon: string;
  group: "wisata" | "kuliner" | "penginapan" | "umkm" | "jasa";
  image: ImageAsset | null;
  active: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
}

export interface BannerDoc {
  id: string;
  title: string;
  image: ImageAsset | null;
  targetUrl: string;
  active: boolean;
  startsAt: string | null;
  expiresAt: string | null;
  promotionId: string | null;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
}

export interface DestinationDoc {
  id: string;
  name: string;
  slug: string;
  description: string;
  categoryIds: string[];
  address: string;
  district: string;
  region: string;
  latitude: number | null;
  longitude: number | null;
  accessInfo: string;
  openingHours: string;
  ticketPrice: number | null;
  facilities: string[];
  contact: string;
  directions: string;
  coverImage: ImageAsset | null;
  gallery: ImageAsset[];
  verified: boolean;
  featured: boolean;
  active: boolean;
  searchTokens: string[];
  createdAt: string;
  updatedAt: string;
}

export interface RegionDoc {
  id: string;
  name: string;
  district: string;
  active: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
}

export interface AppSettings {
  appName: string;
  tagline: string;
  description: string;
  logo: ImageAsset | null;
  contactEmail: string;
  contactWhatsapp: string;
  footerContent: string;
  defaultRegion: string;
  seoTitle: string;
  seoDescription: string;
  privacyPolicy: string;
  termsOfUse: string;
  installPopupEnabled: boolean;
  pwaThemeColor: string;
  reverifyOnSensitiveChange: boolean;
  updatedAt?: string;
}

export type VerificationMode = "manual" | "assisted" | "auto";
export interface TelegramSettings {
  enabled: boolean;
  destinationChatId: string;
  allowedAdminIds: string[];
  verificationMode: VerificationMode;
  notifications: { business: boolean; payment: boolean; decisions: boolean; errors: boolean };
  tokenConfigured?: boolean;
  updatedAt?: string;
}

export interface AuditLogDoc {
  id: string;
  actorId: string;
  action: string;
  targetType: string;
  targetId: string;
  summary: string;
  result: "success" | "failure";
  timestamp: string;
}

export interface DeletionRequestDoc {
  id: string;
  userId: string;
  businessIds: string[];
  status: "requested" | "processing" | "completed" | "failed";
  requestedAt: string;
  processingStartedAt: string | null;
  completedAt: string | null;
  failureReason: string | null;
  steps: Record<string, "pending" | "done" | "failed">;
  retentionNotes: string;
}

export interface SessionUser {
  uid: string;
  email: string;
  displayName: string;
  role: Role;
  status: UserStatus;
}

export const DEFAULT_SETTINGS: AppSettings = {
  appName: "LOKAVA",
  tagline: "Laut, Alam, dan Cerita.",
  description:
    "Platform digital untuk menemukan wisata, kuliner, penginapan, produk lokal, dan usaha masyarakat di Ujunggenteng serta kawasan Sukabumi Selatan.",
  logo: null,
  contactEmail: "",
  contactWhatsapp: "",
  footerContent: "LOKAVA — Temukan pesona Sukabumi Selatan.",
  defaultRegion: "Sukabumi Selatan",
  seoTitle: "LOKAVA — Wisata, Kuliner, dan UMKM Sukabumi Selatan",
  seoDescription:
    "Temukan pantai, kuliner seafood, penginapan, dan produk lokal Ujunggenteng serta Sukabumi Selatan. Hubungi pemilik usaha langsung lewat WhatsApp.",
  privacyPolicy:
    "LOKAVA hanya menyimpan data yang diperlukan untuk menjalankan layanan. Data kontak usaha yang ditampilkan publik hanya yang sudah disetujui pemiliknya. Anda dapat menghapus akun kapan saja dari dashboard.",
  termsOfUse:
    "Pemilik usaha bertanggung jawab atas kebenaran informasi, harga, dan foto yang diunggah. LOKAVA berhak menolak atau menangguhkan konten yang tidak sesuai.",
  installPopupEnabled: true,
  pwaThemeColor: "#154f69",
  reverifyOnSensitiveChange: false,
};

export const DEFAULT_TELEGRAM: TelegramSettings = {
  enabled: false,
  destinationChatId: "",
  allowedAdminIds: [],
  verificationMode: "assisted",
  notifications: { business: true, payment: true, decisions: true, errors: true },
};
