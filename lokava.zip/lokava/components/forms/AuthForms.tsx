"use client";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useState } from "react";
import { createUserWithEmailAndPassword, sendPasswordResetEmail, signInWithEmailAndPassword } from "firebase/auth";
import { firebaseAuth } from "@/lib/firebase/client";
import { Button } from "@/components/ui/Button";
import { api } from "@/components/ui/fetcher";

function pesan(e: unknown): string {
  const code = (e as { code?: string }).code ?? "";
  const map: Record<string, string> = {
    "auth/invalid-credential": "Email atau kata sandi salah.",
    "auth/wrong-password": "Email atau kata sandi salah.",
    "auth/user-not-found": "Email atau kata sandi salah.",
    "auth/too-many-requests": "Terlalu banyak percobaan. Tunggu beberapa menit lalu coba lagi.",
    "auth/email-already-in-use": "Email sudah terdaftar. Silakan masuk.",
    "auth/weak-password": "Kata sandi minimal 8 karakter.",
    "auth/invalid-email": "Format email tidak valid.",
    "auth/network-request-failed": "Tidak dapat terhubung. Periksa koneksi internet Anda.",
  };
  return map[code] ?? (e instanceof Error && !code ? e.message : "Terjadi kesalahan. Coba lagi.");
}

async function startSession(): Promise<"owner" | "admin"> {
  const token = await firebaseAuth().currentUser!.getIdToken(true);
  const r = await api<{ role: "owner" | "admin" }>("/api/auth/session", "POST", { idToken: token });
  return r.role;
}

function Shell({ title, children, footer }: { title: string; children: React.ReactNode; footer: React.ReactNode }) {
  return (
    <div className="wadah flex max-w-md flex-col py-12">
      <div className="kartu p-6 sm:p-8">
        <h1 className="judul mb-5 text-2xl font-semibold">{title}</h1>
        {children}
      </div>
      <p className="mt-4 text-center text-sm text-samudra-700">{footer}</p>
    </div>
  );
}

const Err = ({ text }: { text: string }) => (text ? <p role="alert" className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-800">{text}</p> : null);

export function LoginForm() {
  const router = useRouter();
  const sp = useSearchParams();
  const [email, setEmail] = useState(""); const [pw, setPw] = useState(""); const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  const alasan = sp.get("alasan");
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setErr(""); setBusy(true);
    try {
      await signInWithEmailAndPassword(firebaseAuth(), email.trim(), pw);
      const role = await startSession();
      router.replace(role === "admin" ? "/admin" : "/dashboard"); router.refresh();
    } catch (x) { setErr(pesan(x)); } finally { setBusy(false); }
  }
  return (
    <Shell title="Masuk" footer={<>Belum punya akun? <Link href="/register" className="font-semibold text-toska-700">Daftar</Link></>}>
      <form onSubmit={submit} className="space-y-4">
        {alasan === "suspended" && <Err text="Akun Anda ditangguhkan. Hubungi admin LOKAVA." />}
        {alasan === "deletion_requested" && <Err text="Akun ini sedang dalam proses penghapusan." />}
        <div><label className="label" htmlFor="email">Email</label><input id="email" type="email" autoComplete="email" required className="input" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
        <div><label className="label" htmlFor="pw">Kata sandi</label><input id="pw" type="password" autoComplete="current-password" required className="input" value={pw} onChange={(e) => setPw(e.target.value)} /></div>
        <Err text={err} />
        <Button type="submit" loading={busy} className="w-full">Masuk</Button>
        <p className="text-center text-sm"><Link href="/lupa-password" className="text-samudra-700 underline">Lupa kata sandi?</Link></p>
      </form>
    </Shell>
  );
}

export function RegisterForm() {
  const router = useRouter();
  const [f, setF] = useState({ name: "", email: "", phone: "", pw: "", pw2: "", setuju: false });
  const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof f, v: string | boolean) => setF((s) => ({ ...s, [k]: v }));
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setErr("");
    if (f.pw.length < 8) return setErr("Kata sandi minimal 8 karakter.");
    if (f.pw !== f.pw2) return setErr("Konfirmasi kata sandi tidak sama.");
    if (!f.setuju) return setErr("Setujui syarat penggunaan terlebih dahulu.");
    setBusy(true);
    try {
      const cred = await createUserWithEmailAndPassword(firebaseAuth(), f.email.trim(), f.pw);
      await api("/api/auth/register", "POST", { idToken: await cred.user.getIdToken(), displayName: f.name.trim(), phone: f.phone.trim() || undefined });
      await startSession();
      router.replace("/dashboard"); router.refresh();
    } catch (x) { setErr(pesan(x)); } finally { setBusy(false); }
  }
  return (
    <Shell title="Daftar sebagai pemilik usaha" footer={<>Sudah punya akun? <Link href="/login" className="font-semibold text-toska-700">Masuk</Link></>}>
      <form onSubmit={submit} className="space-y-4">
        <div><label className="label" htmlFor="nama">Nama pemilik</label><input id="nama" required minLength={2} autoComplete="name" className="input" value={f.name} onChange={(e) => set("name", e.target.value)} /></div>
        <div><label className="label" htmlFor="email">Email</label><input id="email" type="email" required autoComplete="email" className="input" value={f.email} onChange={(e) => set("email", e.target.value)} /></div>
        <div><label className="label" htmlFor="hp">Nomor WhatsApp (opsional)</label><input id="hp" inputMode="tel" autoComplete="tel" className="input" value={f.phone} onChange={(e) => set("phone", e.target.value)} placeholder="0812 3456 7890" /></div>
        <div><label className="label" htmlFor="pw">Kata sandi</label><input id="pw" type="password" required autoComplete="new-password" className="input" value={f.pw} onChange={(e) => set("pw", e.target.value)} /><p className="bantuan">Minimal 8 karakter.</p></div>
        <div><label className="label" htmlFor="pw2">Ulangi kata sandi</label><input id="pw2" type="password" required autoComplete="new-password" className="input" value={f.pw2} onChange={(e) => set("pw2", e.target.value)} /></div>
        <label className="flex items-start gap-2 text-sm"><input type="checkbox" className="mt-0.5 h-5 w-5" checked={f.setuju} onChange={(e) => set("setuju", e.target.checked)} /><span>Saya menyetujui <Link href="/syarat" className="underline" target="_blank">syarat penggunaan</Link> dan <Link href="/privasi" className="underline" target="_blank">kebijakan privasi</Link>.</span></label>
        <Err text={err} />
        <Button type="submit" loading={busy} className="w-full">Buat akun</Button>
      </form>
    </Shell>
  );
}

export function ResetForm() {
  const [email, setEmail] = useState(""); const [done, setDone] = useState(false); const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setErr(""); setBusy(true);
    try { await sendPasswordResetEmail(firebaseAuth(), email.trim()); } catch (x) { if ((x as { code?: string }).code !== "auth/user-not-found") { setErr(pesan(x)); setBusy(false); return; } }
    setDone(true); setBusy(false);
  }
  return (
    <Shell title="Pulihkan kata sandi" footer={<Link href="/login" className="font-semibold text-toska-700">Kembali ke halaman masuk</Link>}>
      {done ? <p role="status" className="text-samudra-800">Jika email terdaftar, tautan untuk mengatur ulang kata sandi sudah dikirim. Periksa kotak masuk dan folder spam.</p> : (
        <form onSubmit={submit} className="space-y-4">
          <div><label className="label" htmlFor="email">Email akun</label><input id="email" type="email" required className="input" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
          <Err text={err} />
          <Button type="submit" loading={busy} className="w-full">Kirim tautan</Button>
        </form>
      )}
    </Shell>
  );
}
