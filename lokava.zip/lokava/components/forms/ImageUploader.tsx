"use client";
import { useRef, useState } from "react";
import { Button } from "@/components/ui/Button";
import { api } from "@/components/ui/fetcher";
import type { ImageAsset } from "@/types";

type Purpose = "business" | "product" | "proof" | "promotion" | "admin";
const OK_TYPES = ["image/jpeg", "image/png", "image/webp"];
const MAX = 5 * 1024 * 1024;

interface Sign { cloudName: string; apiKey: string; signature: string; params: Record<string, string | number> }

export async function uploadImage(file: File, purpose: Purpose): Promise<ImageAsset> {
  if (!OK_TYPES.includes(file.type)) throw new Error("Format foto harus JPG, PNG, atau WebP.");
  if (file.size > MAX) throw new Error("Ukuran foto maksimal 5 MB.");
  const s = await api<Sign>("/api/uploads/sign", "POST", { purpose });
  const fd = new FormData();
  fd.append("file", file);
  fd.append("api_key", s.apiKey);
  fd.append("signature", s.signature);
  for (const [k, v] of Object.entries(s.params)) fd.append(k, String(v));
  const res = await fetch(`https://api.cloudinary.com/v1_1/${s.cloudName}/image/upload`, { method: "POST", body: fd });
  const j = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(j?.error?.message ? "Unggah gagal: periksa format dan ukuran foto." : "Unggah gagal. Coba lagi.");
  return { url: j.secure_url as string, publicId: j.public_id as string };
}

export function ImageUploader({ purpose, value, onChange, max = 1, label, help }: { purpose: Purpose; value: ImageAsset[]; onChange: (v: ImageAsset[]) => void; max?: number; label: string; help?: string }) {
  const input = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  async function pick(files: FileList | null) {
    if (!files?.length) return;
    setErr("");
    const room = max - value.length;
    if (room <= 0) return setErr(`Maksimal ${max} foto.`);
    setBusy(true);
    const added: ImageAsset[] = [];
    try {
      for (const f of Array.from(files).slice(0, room)) added.push(await uploadImage(f, purpose));
    } catch (e) { setErr((e as Error).message); }
    if (added.length) onChange([...value, ...added]);
    setBusy(false);
    if (input.current) input.current.value = "";
  }

  return (
    <div>
      <span className="label">{label}</span>
      <ul className="flex flex-wrap gap-2">
        {value.map((img, i) => (
          <li key={img.publicId} className="relative">
            {purpose === "proof" ? <span className="flex h-20 w-20 items-center justify-center rounded-xl bg-samudra-100 p-1 text-center text-xs">Bukti terunggah</span> : /* eslint-disable-next-line @next/next/no-img-element */ <img src={img.url} alt={`${label} ${i + 1}`} className="h-20 w-20 rounded-xl object-cover" />}
            <button type="button" aria-label={`Hapus ${label} ${i + 1}`} onClick={() => onChange(value.filter((x) => x.publicId !== img.publicId))} className="absolute -right-2 -top-2 h-6 w-6 rounded-full bg-karang-500 text-xs font-bold text-white">×</button>
          </li>
        ))}
        {value.length < max && (
          <li><Button type="button" variant="garis" loading={busy} onClick={() => input.current?.click()} className="h-20 w-20 !flex-col !px-1 text-xs">{busy ? "" : "+ Foto"}</Button></li>
        )}
      </ul>
      <input ref={input} type="file" accept="image/jpeg,image/png,image/webp" multiple={max > 1} className="sr-only" aria-label={label} onChange={(e) => pick(e.target.files)} />
      <p className="bantuan">{help ?? "JPG, PNG, atau WebP. Maksimal 5 MB per foto."} ({value.length}/{max})</p>
      {err && <p role="alert" className="mt-1 text-sm text-red-700">{err}</p>}
    </div>
  );
}
