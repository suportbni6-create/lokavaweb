"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Button } from "@/components/ui/Button";
import { api } from "@/components/ui/fetcher";
import { useToast } from "@/components/ui/Toast";
import { ImageUploader } from "@/components/forms/ImageUploader";
import type { BusinessDoc, CategoryDoc, ImageAsset, OpeningHour, RegionDoc } from "@/types";

const DAYS: OpeningHour["day"][] = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"];
const defaultHours = (): OpeningHour[] => DAYS.map((day) => ({ day, open: "08:00", close: "17:00", closed: false }));

export function BusinessForm({ business, categories, regions, maxPhotos }: { business?: BusinessDoc; categories: CategoryDoc[]; regions: RegionDoc[]; maxPhotos: number }) {
  const router = useRouter();
  const toast = useToast();
  const locked = business?.verificationStatus === "suspended";
  const [f, setF] = useState({
    name: business?.name ?? "", description: business?.description ?? "", categoryIds: business?.categoryIds ?? [] as string[],
    address: business?.address ?? "", village: business?.village ?? "", district: business?.district ?? "", region: business?.region ?? "",
    latitude: business?.latitude?.toString() ?? "", longitude: business?.longitude?.toString() ?? "",
    whatsapp: business?.whatsapp ? `0${business.whatsapp.slice(2)}` : "", publicContact: business?.publicContact ?? true,
    openingHours: business?.openingHours?.length ? business.openingHours : defaultHours(),
    cover: business?.coverImage ? [business.coverImage] : ([] as ImageAsset[]), gallery: business?.gallery ?? ([] as ImageAsset[]),
  });
  const [busy, setBusy] = useState(false);
  const set = <K extends keyof typeof f>(k: K, v: (typeof f)[K]) => setF((s) => ({ ...s, [k]: v }));
  const status = business?.verificationStatus ?? "draft";
  const canSubmit = ["draft", "needs_correction", "rejected"].includes(status);

  async function save(submit: boolean) {
    setBusy(true);
    const num = (v: string) => (v.trim() === "" ? null : Number(v.replace(",", ".")));
    const payload = {
      name: f.name, description: f.description, categoryIds: f.categoryIds, address: f.address, village: f.village, district: f.district, region: f.region,
      latitude: num(f.latitude), longitude: num(f.longitude), whatsapp: f.whatsapp, publicContact: f.publicContact, openingHours: f.openingHours,
      coverImage: f.cover[0] ?? null, gallery: f.gallery, submit,
    };
    try {
      const r = business
        ? await api<{ id: string }>(`/api/owner/business/${business.id}`, "PUT", payload)
        : await api<{ id: string }>("/api/owner/business", "POST", payload);
      toast(submit ? "Bisnis diajukan untuk verifikasi." : "Perubahan disimpan.");
      router.replace(`/dashboard/bisnis?id=${r.id}`); router.refresh();
    } catch (e) { toast((e as Error).message, "error"); } finally { setBusy(false); }
  }
  const toggleCat = (id: string) => set("categoryIds", f.categoryIds.includes(id) ? f.categoryIds.filter((x) => x !== id) : [...f.categoryIds, id]);

  return (
    <form onSubmit={(e) => { e.preventDefault(); save(false); }} className="space-y-6">
      <fieldset disabled={locked || busy} className="space-y-5">
        <div className="kartu space-y-4 p-5">
          <h2 className="judul text-lg font-semibold">Informasi usaha</h2>
          <div><label className="label" htmlFor="name">Nama bisnis</label><input id="name" required className="input" value={f.name} onChange={(e) => set("name", e.target.value)} /></div>
          <div><label className="label" htmlFor="desc">Deskripsi</label><textarea id="desc" required rows={5} className="input" value={f.description} onChange={(e) => set("description", e.target.value)} /><p className="bantuan">Minimal 20 karakter. Tulis hanya informasi yang benar.</p></div>
          <fieldset><legend className="label">Kategori</legend><div className="flex flex-wrap gap-2">{categories.map((c) => (<label key={c.id} className={`cursor-pointer rounded-full border px-3 py-1.5 text-sm font-semibold ${f.categoryIds.includes(c.id) ? "border-toska-500 bg-toska-100" : "border-samudra-200 bg-white"}`}><input type="checkbox" className="sr-only" checked={f.categoryIds.includes(c.id)} onChange={() => toggleCat(c.id)} />{c.icon} {c.name}</label>))}</div></fieldset>
        </div>

        <div className="kartu space-y-4 p-5">
          <h2 className="judul text-lg font-semibold">Alamat dan lokasi</h2>
          <div><label className="label" htmlFor="addr">Alamat</label><input id="addr" required className="input" value={f.address} onChange={(e) => set("address", e.target.value)} /></div>
          <div className="grid gap-4 sm:grid-cols-3">
            <div><label className="label" htmlFor="vil">Desa / kelurahan</label><input id="vil" required className="input" value={f.village} onChange={(e) => set("village", e.target.value)} /></div>
            <div><label className="label" htmlFor="dis">Kecamatan</label><input id="dis" required list="daftar-kec" className="input" value={f.district} onChange={(e) => set("district", e.target.value)} /><datalist id="daftar-kec">{[...new Set(regions.map((r) => r.district))].map((d) => <option key={d} value={d} />)}</datalist></div>
            <div><label className="label" htmlFor="reg">Wilayah</label><input id="reg" required list="daftar-wil" className="input" value={f.region} onChange={(e) => set("region", e.target.value)} /><datalist id="daftar-wil">{regions.map((r) => <option key={r.id} value={r.name} />)}</datalist></div>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div><label className="label" htmlFor="lat">Latitude (opsional)</label><input id="lat" inputMode="decimal" className="input" value={f.latitude} onChange={(e) => set("latitude", e.target.value)} placeholder="-7.xxxxx" /></div>
            <div><label className="label" htmlFor="lng">Longitude (opsional)</label><input id="lng" inputMode="decimal" className="input" value={f.longitude} onChange={(e) => set("longitude", e.target.value)} placeholder="106.xxxxx" /></div>
          </div>
          <p className="bantuan">Buka Google Maps atau OpenStreetMap di lokasi usaha, tekan lama pada titik, lalu salin koordinatnya. Isi hanya jika Anda yakin akurat.</p>
        </div>

        <div className="kartu space-y-4 p-5">
          <h2 className="judul text-lg font-semibold">Kontak dan jam buka</h2>
          <div><label className="label" htmlFor="wa">Nomor WhatsApp</label><input id="wa" required inputMode="tel" className="input" value={f.whatsapp} onChange={(e) => set("whatsapp", e.target.value)} placeholder="0812 3456 7890" /></div>
          <label className="flex items-start gap-2 text-sm"><input type="checkbox" className="mt-0.5 h-5 w-5" checked={f.publicContact} onChange={(e) => set("publicContact", e.target.checked)} /><span>Tampilkan nomor ini dan tombol WhatsApp kepada pengunjung. Jika dimatikan, pengunjung tidak dapat menghubungi Anda lewat LOKAVA.</span></label>
          <div className="space-y-2">
            {f.openingHours.map((h, i) => (
              <div key={h.day} className="grid grid-cols-[5rem_1fr_1fr_auto] items-center gap-2 text-sm">
                <span className="font-semibold">{h.day}</span>
                <input aria-label={`${h.day} buka`} type="time" className="input !py-1.5" disabled={h.closed} value={h.open} onChange={(e) => set("openingHours", f.openingHours.map((x, j) => j === i ? { ...x, open: e.target.value } : x))} />
                <input aria-label={`${h.day} tutup`} type="time" className="input !py-1.5" disabled={h.closed} value={h.close} onChange={(e) => set("openingHours", f.openingHours.map((x, j) => j === i ? { ...x, close: e.target.value } : x))} />
                <label className="flex items-center gap-1"><input type="checkbox" checked={h.closed} onChange={(e) => set("openingHours", f.openingHours.map((x, j) => j === i ? { ...x, closed: e.target.checked } : x))} />Tutup</label>
              </div>
            ))}
          </div>
        </div>

        <div className="kartu space-y-5 p-5">
          <h2 className="judul text-lg font-semibold">Foto</h2>
          <ImageUploader purpose="business" label="Foto utama" value={f.cover} onChange={(v) => set("cover", v)} max={1} />
          <ImageUploader purpose="business" label="Galeri" value={f.gallery} onChange={(v) => set("gallery", v)} max={Math.max(maxPhotos - 1, 0)} help={`Paket Anda: total ${maxPhotos} foto bisnis (termasuk foto utama).`} />
        </div>
      </fieldset>

      {!locked && (
        <div className="sticky bottom-0 -mx-4 flex flex-wrap gap-3 border-t border-samudra-100 bg-white/95 px-4 py-3 backdrop-blur sm:static sm:mx-0 sm:border-0 sm:bg-transparent sm:p-0">
          <Button type="submit" variant="garis" loading={busy}>Simpan {canSubmit ? "draf" : "perubahan"}</Button>
          {canSubmit && <Button type="button" loading={busy} onClick={() => save(true)}>Simpan dan ajukan verifikasi</Button>}
        </div>
      )}
    </form>
  );
}
