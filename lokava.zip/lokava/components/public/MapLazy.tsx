"use client";
import dynamic from "next/dynamic";
import { Skeleton } from "@/components/ui/misc";
import type { Pt } from "@/components/public/MapView";

const MapView = dynamic(() => import("@/components/public/MapView"), { ssr: false, loading: () => <Skeleton className="h-64 w-full" /> });
export default function MapLazy(props: { points: Pt[]; height?: number; single?: boolean }) {
  return <MapView {...props} />;
}
