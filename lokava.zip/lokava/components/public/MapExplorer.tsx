"use client";
import dynamic from "next/dynamic";
import { useMemo, useState } from "react";
import type { MapPoint } from "@/lib/data/public";
import type { CategoryDoc } from "@/types";
import { EmptyState, Skeleton } from "@/components/ui/misc";

const MapView = dynamic(() => import("@/components/public/MapView"), { ssr: false, loading: () => <Skeleton className="h-[480px] w-full" /> });

export function MapExplorer({ points, cats }: { points: MapPoint[]; cats: CategoryDoc[] }) {
  const [kind, setKind] = useState<"semua" | "bisnis" | "wisata">("semua");
  const [cat, setCat] = useState("");
  const shown = useMemo(() => points.filter((p) => (kind === "semua" || p.kind === kind) && (!cat || p.categoryIds.includes(cat))), [points, kind, cat]);
  return (
    <div>
      <div className="mb-4 flex flex-wrap gap-2">
        {(["semua", "wisata", "bisnis"] as const).map((k) => (
          <button key={k} onClick={() => setKind(k)} aria-pressed={kind === k} className={`rounded-full px-4 py-2 text-sm font-semibold ${kind === k ? "bg-samudra-700 text-white" : "border border-samudra-200 bg-white"}`}>{k === "semua" ? "Semua" : k === "wisata" ? "Wisata" : "Bisnis"}</button>
        ))}
        <label htmlFor="kat-peta" className="sr-only">Kategori</label>
        <select id="kat-peta" value={cat} onChange={(e) => setCat(e.target.value)} className="input !w-auto">
          <option value="">Semua kategori</option>
          {cats.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </div>
      {points.length === 0 ? <EmptyState title="Belum ada lokasi di peta" text="Lokasi muncul setelah admin atau pemilik usaha mengisi koordinat." /> : <MapView points={shown} height={520} />}
      <p className="mt-2 text-xs text-samudra-600">{shown.length} lokasi ditampilkan. Titik biru: bisnis, toska: wisata.</p>
    </div>
  );
}
