import Link from "next/link";
import { BusinessCard, Grid } from "@/components/cards";
import { EmptyState } from "@/components/ui/misc";
import { LinkButton } from "@/components/ui/Button";
import { getCategories, getRegions, listBusinesses } from "@/lib/data/public";
import { idsOfGroup } from "@/lib/groups";
import type { CategoryDoc } from "@/types";

/** Direktori bisnis dengan filter kategori/wilayah dan pagination berbasis cursor (tidak membaca seluruh database). */
export async function Directory({ basePath, group, sp }: { basePath: string; group?: CategoryDoc["group"]; sp: { kategori?: string; district?: string; cursor?: string } }) {
  const [cats, regions] = await Promise.all([getCategories(), getRegions()]);
  const groupCats = group ? cats.filter((c) => c.group === group) : cats;
  const categoryIds = sp.kategori ? [sp.kategori] : group ? idsOfGroup(cats, group) : undefined;
  const { items, nextCursor } = group && !categoryIds?.length ? { items: [], nextCursor: null } : await listBusinesses({ district: sp.district, categoryIds, cursor: sp.cursor ?? null, limit: 12 });
  const qs = (extra: Record<string, string | undefined>) => {
    const p = new URLSearchParams();
    const all = { kategori: sp.kategori, district: sp.district, ...extra };
    for (const [k, v] of Object.entries(all)) if (v) p.set(k, v);
    const s = p.toString();
    return s ? `${basePath}?${s}` : basePath;
  };
  return (
    <>
      <div className="mb-6 flex flex-wrap gap-2" aria-label="Filter">
        <Link href={qs({ kategori: undefined, cursor: undefined })} className={`rounded-full px-4 py-2 text-sm font-semibold ${!sp.kategori ? "bg-samudra-700 text-white" : "bg-white border border-samudra-200"}`}>Semua</Link>
        {groupCats.map((c) => (<Link key={c.id} href={qs({ kategori: c.id, cursor: undefined })} className={`rounded-full px-4 py-2 text-sm font-semibold ${sp.kategori === c.id ? "bg-samudra-700 text-white" : "bg-white border border-samudra-200"}`}>{c.icon} {c.name}</Link>))}
      </div>
      {regions.length > 0 && (
        <form action={basePath} className="mb-6 flex max-w-sm gap-2">
          {sp.kategori && <input type="hidden" name="kategori" value={sp.kategori} />}
          <label htmlFor="wilayah" className="sr-only">Kecamatan</label>
          <select id="wilayah" name="district" defaultValue={sp.district ?? ""} className="input">
            <option value="">Semua kecamatan</option>
            {[...new Set(regions.map((r) => r.district))].map((d) => <option key={d} value={d}>{d}</option>)}
          </select>
          <button className="rounded-xl bg-samudra-700 px-4 text-sm font-semibold text-white">Terapkan</button>
        </form>
      )}
      {items.length === 0 ? (
        <EmptyState title="Belum ada usaha yang cocok" text="Coba ubah filter, atau daftarkan usahamu agar tampil di sini." action={<LinkButton href="/daftar-bisnis">Daftarkan usaha</LinkButton>} />
      ) : (
        <Grid>{items.map((b) => <BusinessCard key={b.id} b={b} cats={cats} />)}</Grid>
      )}
      {nextCursor && <div className="mt-8 text-center"><LinkButton href={qs({ cursor: nextCursor })} variant="garis">Muat lebih banyak</LinkButton></div>}
    </>
  );
}
