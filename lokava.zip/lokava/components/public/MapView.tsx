"use client";
import { useEffect, useRef } from "react";
import "leaflet/dist/leaflet.css";

export interface Pt { id: string; kind: "bisnis" | "wisata"; name: string; slug: string; lat: number; lng: number; address?: string }

const DEFAULT_CENTER: [number, number] = [-7.3566, 106.4]; // sekitar Ujunggenteng; hanya pusat tampilan awal, bukan data lokasi usaha
const TILE = process.env.NEXT_PUBLIC_MAP_TILE_URL || "https://tile.openstreetmap.org/{z}/{x}/{y}.png";

export const directionsUrl = (lat: number, lng: number) => `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`;

export default function MapView({ points, height = 420, single = false }: { points: Pt[]; height?: number; single?: boolean }) {
  const el = useRef<HTMLDivElement>(null);
  useEffect(() => {
    let map: import("leaflet").Map | null = null;
    let cancelled = false;
    (async () => {
      const L = (await import("leaflet")).default;
      if (cancelled || !el.current) return;
      map = L.map(el.current, { scrollWheelZoom: false }).setView(DEFAULT_CENTER, 11);
      L.tileLayer(TILE, { maxZoom: 19, attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>' }).addTo(map);
      const bounds: [number, number][] = [];
      for (const p of points) {
        const icon = L.divIcon({ className: "", html: `<span style="display:block;width:18px;height:18px;border-radius:50%;border:3px solid #fff;box-shadow:0 1px 4px rgba(0,0,0,.4);background:${p.kind === "wisata" ? "#13a095" : "#176282"}"></span>`, iconSize: [18, 18], iconAnchor: [9, 9] });
        const box = document.createElement("div");
        const title = document.createElement("strong"); title.textContent = p.name; box.appendChild(title);
        if (p.address) { const a = document.createElement("p"); a.textContent = p.address; a.style.margin = "4px 0"; box.appendChild(a); }
        if (!single) { const d = document.createElement("a"); d.href = `/${p.kind === "wisata" ? "wisata" : "bisnis"}/${p.slug}`; d.textContent = "Lihat detail"; d.style.cssText = "display:block;margin-top:4px;font-weight:600"; box.appendChild(d); }
        const r = document.createElement("a"); r.href = directionsUrl(p.lat, p.lng); r.target = "_blank"; r.rel = "noopener noreferrer"; r.textContent = "Petunjuk arah"; r.style.cssText = "display:block;margin-top:4px;font-weight:600"; box.appendChild(r);
        L.marker([p.lat, p.lng], { icon, title: p.name, alt: p.name }).addTo(map).bindPopup(box);
        bounds.push([p.lat, p.lng]);
      }
      if (bounds.length === 1) map.setView(bounds[0]!, 15);
      else if (bounds.length > 1) map.fitBounds(bounds, { padding: [30, 30], maxZoom: 15 });
    })();
    return () => { cancelled = true; map?.remove(); };
  }, [points, single]);
  return <div ref={el} style={{ height }} className="w-full overflow-hidden rounded-2xl border border-samudra-100" role="region" aria-label="Peta lokasi" />;
}
