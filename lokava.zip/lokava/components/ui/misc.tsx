import clsx from "clsx";
import Image from "next/image";
import type { ReactNode } from "react";
import type { ImageAsset } from "@/types";

export function Badge({ children, tone = "netral" }: { children: ReactNode; tone?: "netral" | "hijau" | "biru" | "merah" | "kuning" }) {
  const t = { netral: "bg-samudra-100 text-samudra-800", hijau: "bg-daun-100 text-daun-800", biru: "bg-toska-100 text-toska-800", merah: "bg-red-100 text-red-800", kuning: "bg-amber-100 text-amber-900" }[tone];
  return <span className={clsx("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold", t)}>{children}</span>;
}

export function Skeleton({ className }: { className?: string }) {
  return <div aria-hidden className={clsx("skeleton rounded-xl", className)} />;
}

export function EmptyState({ title, text, action }: { title: string; text?: string; action?: ReactNode }) {
  return (
    <div className="kartu flex flex-col items-center gap-2 px-6 py-10 text-center">
      <svg aria-hidden width="44" height="44" viewBox="0 0 44 44" fill="none"><path d="M4 28c5 0 5-5 10-5s5 5 10 5 5-5 10-5 5 5 6 5" stroke="#3a95b6" strokeWidth="3" strokeLinecap="round" /><path d="M4 36c5 0 5-5 10-5s5 5 10 5 5-5 10-5 5 5 6 5" stroke="#93e8dc" strokeWidth="3" strokeLinecap="round" /></svg>
      <h3 className="judul text-lg font-semibold">{title}</h3>
      {text && <p className="max-w-md text-sm text-samudra-700">{text}</p>}
      {action}
    </div>
  );
}

export function ErrorState({ message = "Data tidak dapat dimuat. Periksa koneksi Anda lalu muat ulang halaman." }: { message?: string }) {
  return (
    <div role="alert" className="rounded-2xl border border-red-200 bg-red-50 px-5 py-4 text-sm text-red-900">
      {message}
    </div>
  );
}

/** Foto dengan placeholder jelas jika belum ada foto asli. */
export function Photo({ image, alt, className, sizes = "(max-width: 768px) 100vw, 400px", priority }: { image?: ImageAsset | null; alt: string; className?: string; sizes?: string; priority?: boolean }) {
  if (!image) {
    return (
      <div className={clsx("flex items-center justify-center bg-gradient-to-br from-samudra-100 to-toska-100 text-center text-xs font-medium text-samudra-600", className)} role="img" aria-label={`Foto ${alt} belum tersedia`}>
        <span className="px-3">Foto belum tersedia</span>
      </div>
    );
  }
  return (
    <div className={clsx("relative overflow-hidden bg-samudra-100", className)}>
      <Image src={image.url} alt={alt} fill sizes={sizes} priority={priority} className="object-cover" />
    </div>
  );
}

export function PageHeader({ title, text, children }: { title: string; text?: string; children?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="judul text-2xl font-semibold sm:text-3xl">{title}</h1>
        {text && <p className="mt-1 max-w-2xl text-sm text-samudra-700">{text}</p>}
      </div>
      {children}
    </div>
  );
}

export function Logo({ className, name = "LOKAVA" }: { className?: string; name?: string }) {
  return (
    <span className={clsx("inline-flex items-center gap-2", className)}>
      <svg aria-hidden width="30" height="30" viewBox="0 0 32 32"><rect width="32" height="32" rx="9" fill="#154f69" /><path d="M5 21c3 0 3-3 5.5-3S14 21 16.5 21 20 18 22.5 18 25 21 27 21" stroke="#93e8dc" strokeWidth="2.2" fill="none" strokeLinecap="round" /><path d="M5 26c3 0 3-3 5.5-3S14 26 16.5 26 20 23 22.5 23 25 26 27 26" stroke="#fff" strokeWidth="2.2" fill="none" strokeLinecap="round" /><path d="M11 6v10h8" stroke="#fff" strokeWidth="2.6" fill="none" strokeLinecap="round" strokeLinejoin="round" /></svg>
      <span className="judul text-xl font-bold tracking-wide text-samudra-800">{name}</span>
    </span>
  );
}
