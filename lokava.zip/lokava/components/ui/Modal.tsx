"use client";
import { useEffect, useRef, type ReactNode } from "react";

export function Modal({ open, onClose, title, children }: { open: boolean; onClose: () => void; title: string; children: ReactNode }) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const d = ref.current;
    if (!d) return;
    if (open && !d.open) d.showModal();
    if (!open && d.open) d.close();
  }, [open]);
  return (
    <dialog ref={ref} onClose={onClose} onClick={(e) => e.target === ref.current && onClose()} className="m-auto w-[min(92vw,34rem)] rounded-2xl p-0 shadow-2xl backdrop:bg-samudra-900/50">
      <div className="p-5">
        <div className="mb-3 flex items-start justify-between gap-3">
          <h2 className="judul text-lg font-semibold">{title}</h2>
          <button onClick={onClose} aria-label="Tutup" className="rounded-lg p-1 text-samudra-600 hover:bg-samudra-100">✕</button>
        </div>
        {open && children}
      </div>
    </dialog>
  );
}
