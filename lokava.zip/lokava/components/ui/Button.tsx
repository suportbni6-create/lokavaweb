import Link from "next/link";
import clsx from "clsx";
import type { ButtonHTMLAttributes, ReactNode } from "react";

type Variant = "utama" | "sekunder" | "garis" | "bahaya" | "hantu" | "wa";
const styles: Record<Variant, string> = {
  utama: "bg-samudra-700 text-white hover:bg-samudra-800 focus-visible:bg-samudra-800",
  sekunder: "bg-toska-500 text-white hover:bg-toska-600",
  garis: "border border-samudra-300 bg-white text-samudra-800 hover:bg-samudra-50",
  bahaya: "bg-karang-500 text-white hover:bg-karang-600",
  hantu: "text-samudra-700 hover:bg-samudra-100",
  wa: "bg-[#128c4a] text-white hover:bg-[#0e7a40]",
};
const base = "inline-flex min-h-11 items-center justify-center gap-2 rounded-xl px-4 py-2 text-sm font-semibold transition disabled:cursor-not-allowed disabled:opacity-50";

export function Button({ variant = "utama", className, loading, children, ...rest }: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant; loading?: boolean }) {
  return (
    <button className={clsx(base, styles[variant], className)} disabled={loading || rest.disabled} {...rest}>
      {loading && <span aria-hidden className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" />}
      {children}
    </button>
  );
}

export function LinkButton({ href, variant = "utama", className, children, external }: { href: string; variant?: Variant; className?: string; children: ReactNode; external?: boolean }) {
  const cls = clsx(base, styles[variant], className);
  return external ? (
    <a href={href} className={cls} target="_blank" rel="noopener noreferrer">{children}</a>
  ) : (
    <Link href={href} className={cls}>{children}</Link>
  );
}
