"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import clsx from "clsx";
import { signOut } from "firebase/auth";
import { firebaseAuth } from "@/lib/firebase/client";

export function PanelNav({ title, items, children }: { title: string; items: [string, string][]; children: React.ReactNode }) {
  const path = usePathname();
  const router = useRouter();
  async function logout() {
    await fetch("/api/auth/session", { method: "DELETE" }).catch(() => undefined);
    await signOut(firebaseAuth()).catch(() => undefined);
    router.replace("/login"); router.refresh();
  }
  return (
    <div className="wadah py-6">
      <div className="mb-4 flex items-center justify-between gap-3">
        <p className="judul text-lg font-semibold">{title}</p>
        <button onClick={logout} className="rounded-xl border border-samudra-300 px-4 py-2 text-sm font-semibold hover:bg-samudra-50">Keluar</button>
      </div>
      <nav aria-label="Menu panel" className="-mx-4 mb-6 overflow-x-auto px-4">
        <ul className="flex gap-2 whitespace-nowrap">
          {items.map(([h, l]) => (
            <li key={h}><Link href={h} aria-current={path === h ? "page" : undefined} className={clsx("block rounded-full px-4 py-2 text-sm font-semibold", path === h ? "bg-samudra-700 text-white" : "bg-white border border-samudra-200 text-samudra-800 hover:bg-samudra-50")}>{l}</Link></li>
          ))}
        </ul>
      </nav>
      {children}
    </div>
  );
}
