"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Button } from "@/components/ui/Button";
import { Modal } from "@/components/ui/Modal";
import { Badge } from "@/components/ui/misc";
import { api } from "@/components/ui/fetcher";
import { useToast } from "@/components/ui/Toast";
import { ImageUploader } from "@/components/forms/ImageUploader";
import { formatRupiah } from "@/lib/utils/format";
import type { CategoryDoc, ImageAsset, ProductDoc } from "@/types";

type Draft = { name: string; description: string; price: string; categoryId: string; kind: ProductDoc["kind"]; availability: ProductDoc["availability"]; images: ImageAsset[]; status: ProductDoc["status"] };
const empty: Draft = { name: "", description: "", price: "", categoryId: "", kind: "produk", availability: "tersedia", images: [], status: "active" };

export function ProductManager({ businessId, products, categories, maxProducts, maxPhotos }: { businessId: string; products: ProductDoc[]; categories: CategoryDoc[]; maxProducts: number; maxPhotos: number }) {
  const router = useRouter();
  const toast = useToast();
  const [editing, setEditing] = useState<{ id?: string; d: Draft } | null>(null);
  const [busy, setBusy] = useState(false);
  const full = products.length >= maxProducts;

  const open = (p?: ProductDoc) => setEditing(p ? { id: p.id, d: { name: p.name, description: p.description, price: String(p.price), categoryId: p.categoryId ?? "", kind: p.kind, availability: p.availability, images: p.images, status: p.status } } : { d: empty });
  async function save() {
    if (!editing) return;
    setBusy(true);
    const d = editing.d;
    const payload = { businessId, name: d.name, description: d.description, price: Number(d.price.replace(/\D/g, "")), categoryId: d.categoryId || null, kind: d.kind, availability: d.availability, images: d.images, status: d.status };
    try {
      if (editing.id) await api(`/api/owner/products/${editing.id}`, "PUT", payload); else await api("/api/owner/products", "POST", payload);
      toast("Produk disimpan."); setEditing(null); router.refresh();
    } catch (e) { toast((e as Error).message, "error"); } finally { setBusy(false); }
  }
  async function remove(p: ProductDoc) {
    if (!confirm(`Hapus "${p.name}"? Foto produk juga dihapus dan tidak dapat dikembalikan.`)) return;
    try { await api(`/api/owner/products/${p.id}`, "DELETE"); toast("Produk dihapus."); router.refresh(); } catch (e) { toast((e as Error).message, "error"); }
  }
  async function toggle(p: ProductDoc) {
    try { await api(`/api/owner/products/${p.id}`, "PUT", { businessId, name: p.name, description: p.description, price: p.price, categoryId: p.categoryId, kind: p.kind, availability: p.availability, images: p.images, status: p.status === "active" ? "inactive" : "active" }); router.refresh(); } catch (e) { toast((e as Error).message, "error"); }
  }
  const set = <K extends keyof Draft>(k: K, v: Draft[K]) => setEditing((s) => (s ? { ...s, d: { ...s.d, [k]: v } } : s));

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <p className="text-sm text-samudra-700">{products.length} dari {maxProducts} produk terpakai.</p>
        <Button onClick={() => open()} disabled={full}>Tambah produk</Button>
      </div>
      {full && <p className="mb-3 rounded-xl bg-amber-50 p-3 text-sm text-amber-900">Batas produk paket Anda tercapai. Tingkatkan paket di menu Langganan untuk menambah.</p>}
      <ul className="space-y-2">
        {products.map((p) => (
          <li key={p.id} className="kartu flex flex-wrap items-center gap-3 p-3">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            {p.images[0] ? <img src={p.images[0].url} alt={p.name} className="h-14 w-14 rounded-lg object-cover" /> : <span className="flex h-14 w-14 items-center justify-center rounded-lg bg-samudra-100 text-[10px]">Tanpa foto</span>}
            <div className="min-w-0 flex-1"><p className="truncate font-semibold">{p.name}</p><p className="text-sm text-samudra-700">{formatRupiah(p.price)}</p></div>
            <Badge tone={p.visible ? "hijau" : p.status === "inactive" ? "netral" : "kuning"}>{p.visible ? "Tampil" : p.status === "inactive" ? "Nonaktif" : "Belum tampil"}</Badge>
            <div className="flex gap-1"><Button variant="hantu" onClick={() => open(p)}>Ubah</Button><Button variant="hantu" onClick={() => toggle(p)}>{p.status === "active" ? "Nonaktifkan" : "Aktifkan"}</Button><Button variant="hantu" onClick={() => remove(p)} className="!text-red-700">Hapus</Button></div>
          </li>
        ))}
      </ul>
      <Modal open={!!editing} onClose={() => setEditing(null)} title={editing?.id ? "Ubah produk" : "Tambah produk"}>
        {editing && (
          <form onSubmit={(e) => { e.preventDefault(); save(); }} className="space-y-3">
            <div><label className="label" htmlFor="pn">Nama</label><input id="pn" required className="input" value={editing.d.name} onChange={(e) => set("name", e.target.value)} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="label" htmlFor="pk">Jenis</label><select id="pk" className="input" value={editing.d.kind} onChange={(e) => set("kind", e.target.value as ProductDoc["kind"])}><option value="produk">Produk</option><option value="menu">Menu makanan/minuman</option><option value="layanan">Layanan</option><option value="kamar">Kamar / unit</option></select></div>
              <div><label className="label" htmlFor="pp">Harga (Rp)</label><input id="pp" required inputMode="numeric" className="input" value={editing.d.price} onChange={(e) => set("price", e.target.value)} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className="label" htmlFor="pc">Kategori</label><select id="pc" className="input" value={editing.d.categoryId} onChange={(e) => set("categoryId", e.target.value)}><option value="">Tanpa kategori</option>{categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></div>
              <div><label className="label" htmlFor="pa">Ketersediaan</label><select id="pa" className="input" value={editing.d.availability} onChange={(e) => set("availability", e.target.value as ProductDoc["availability"])}><option value="tersedia">Tersedia</option><option value="habis">Habis</option><option value="pesan_dulu">Pesan dulu</option></select></div>
            </div>
            <div><label className="label" htmlFor="pd">Deskripsi</label><textarea id="pd" rows={3} className="input" value={editing.d.description} onChange={(e) => set("description", e.target.value)} /></div>
            <ImageUploader purpose="product" label="Foto produk" value={editing.d.images} onChange={(v) => set("images", v)} max={maxPhotos} help={`Paket Anda: maksimal ${maxPhotos} foto per produk.`} />
            <div className="flex gap-2 pt-2"><Button type="submit" loading={busy}>Simpan</Button><Button type="button" variant="hantu" onClick={() => setEditing(null)}>Batal</Button></div>
          </form>
        )}
      </Modal>
    </div>
  );
}
