"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import Image from "next/image";
import { Badge } from "@/components/ui/misc";
import { Button } from "@/components/ui/Button";
import { api } from "@/components/ui/fetcher";
import { useToast } from "@/components/ui/Toast";
import { ImageUploader } from "@/components/forms/ImageUploader";
import { TX_TONE } from "@/lib/labels";
import { formatRupiah, formatTanggal } from "@/lib/utils/format";
import { TRANSACTION_STATUS_LABEL, type ImageAsset, type TransactionStatus } from "@/types";

export interface TxView {
  id: string; transactionNumber: string; title: string; type: string; amount: number; status: TransactionStatus; createdAt: string; expiresAt: string;
  rejectionReason: string | null; hasProof: boolean; proofNote: string | null; businessName: string;
  paymentMethod: { name: string; provider: string; accountName: string; accountNumber: string; instructions: string; qr: ImageAsset | null } | null;
}

export function TransactionCard({ tx, highlight }: { tx: TxView; highlight?: boolean }) {
  const router = useRouter(); const toast = useToast();
  const [proof, setProof] = useState<ImageAsset[]>([]); const [note, setNote] = useState(""); const [busy, setBusy] = useState(false);
  const canPay = tx.status === "pending_payment" || tx.status === "rejected";
  async function send() {
    if (!proof[0]) return toast("Unggah foto bukti pembayaran dulu.", "error");
    setBusy(true);
    try { await api(`/api/transactions/${tx.id}/proof`, "POST", { publicId: proof[0].publicId, note: note || undefined }); toast("Bukti terkirim. Admin akan memeriksa pembayaran Anda."); setProof([]); router.refresh(); }
    catch (e) { toast((e as Error).message, "error"); } finally { setBusy(false); }
  }
  return (
    <li id={tx.id} className={`kartu p-4 ${highlight ? "ring-2 ring-toska-400" : ""}`}>
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div><p className="font-mono text-xs text-samudra-600">{tx.transactionNumber}</p><h3 className="font-semibold">{tx.title}</h3><p className="text-sm text-samudra-700">{tx.businessName} · {formatTanggal(tx.createdAt, true)}</p></div>
        <div className="text-right"><p className="text-lg font-bold">{formatRupiah(tx.amount)}</p><Badge tone={TX_TONE[tx.status]}>{TRANSACTION_STATUS_LABEL[tx.status]}</Badge></div>
      </div>
      {tx.rejectionReason && <p role="status" className="mt-3 rounded-xl bg-red-50 p-3 text-sm text-red-900"><b>Alasan penolakan:</b> {tx.rejectionReason}</p>}
      {tx.hasProof && <p className="mt-2 text-sm"><a className="font-semibold text-toska-700 underline" target="_blank" rel="noopener noreferrer" href={`/api/proof/${tx.id}`}>Lihat bukti yang Anda kirim</a></p>}
      {canPay && tx.paymentMethod && (
        <div className="mt-4 space-y-3 rounded-xl bg-samudra-50 p-4 text-sm">
          <p className="font-semibold">Bayar tepat <span className="text-base">{formatRupiah(tx.amount)}</span> ke:</p>
          <p><b>{tx.paymentMethod.name}</b> ({tx.paymentMethod.provider})<br />a.n. {tx.paymentMethod.accountName}{tx.paymentMethod.accountNumber && <><br />No. <span className="font-mono font-semibold">{tx.paymentMethod.accountNumber}</span></>}</p>
          {tx.paymentMethod.qr && <Image src={tx.paymentMethod.qr.url} alt={`QR pembayaran ${tx.paymentMethod.name}`} width={200} height={200} className="rounded-lg bg-white p-1" />}
          {tx.paymentMethod.instructions && <p className="whitespace-pre-line text-samudra-700">{tx.paymentMethod.instructions}</p>}
          {tx.status === "pending_payment" && <p className="text-xs text-samudra-600">Bayar sebelum {formatTanggal(tx.expiresAt, true)}.</p>}
          <ImageUploader purpose="proof" label="Bukti pembayaran" value={proof} onChange={setProof} max={1} help="Foto atau tangkapan layar bukti transfer. Hanya Anda dan admin yang dapat melihatnya." />
          <div><label className="label" htmlFor={`n-${tx.id}`}>Catatan (opsional)</label><input id={`n-${tx.id}`} className="input" maxLength={500} value={note} onChange={(e) => setNote(e.target.value)} placeholder="Mis. nama pengirim" /></div>
          <Button onClick={send} loading={busy}>{tx.status === "rejected" ? "Kirim ulang bukti" : "Kirim bukti pembayaran"}</Button>
          <p className="text-xs text-samudra-600">Layanan aktif setelah admin memeriksa dan menyetujui pembayaran. Bukti saja belum mengaktifkan layanan.</p>
        </div>
      )}
    </li>
  );
}
