"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { reauthenticateWithCredential, EmailAuthProvider, signOut } from "firebase/auth";
import { firebaseAuth } from "@/lib/firebase/client";
import { Button } from "@/components/ui/Button";
import { Modal } from "@/components/ui/Modal";
import { api } from "@/components/ui/fetcher";

export function DeleteAccount() {
  const router = useRouter();
  const [open, setOpen] = useState(false); const [pw, setPw] = useState(""); const [text, setText] = useState(""); const [busy, setBusy] = useState(false); const [err, setErr] = useState("");
  async function run() {
    setBusy(true); setErr("");
    try {
      const auth = firebaseAuth(); const u = auth.currentUser;
      if (!u?.email) throw new Error("Masuk ulang terlebih dahulu.");
      await reauthenticateWithCredential(u, EmailAuthProvider.credential(u.email, pw));
      // Perbarui sesi server dengan token terbaru agar lolos pemeriksaan autentikasi ulang
      await api("/api/auth/session", "POST", { idToken: await u.getIdToken(true) });
      await api("/api/account/delete", "POST", { confirm: text });
      await signOut(auth).catch(() => undefined);
      router.replace("/?akun=dihapus"); router.refresh();
    } catch (e) {
      const code = (e as { code?: string }).code;
      setErr(code === "auth/invalid-credential" || code === "auth/wrong-password" ? "Kata sandi salah." : (e as Error).message);
    } finally { setBusy(false); }
  }
  return (
    <div className="kartu border-red-200 p-5">
      <h2 className="judul text-lg font-semibold text-red-900">Hapus akun</h2>
      <p className="mt-1 text-sm text-samudra-800">Bisnis, produk, promosi, dan foto Anda langsung disembunyikan lalu dihapus. Catatan transaksi keuangan tetap disimpan selama masa retensi dengan data pribadi diminimalkan. Tindakan ini tidak dapat dibatalkan.</p>
      <Button variant="bahaya" className="mt-3" onClick={() => setOpen(true)}>Hapus akun saya</Button>
      <Modal open={open} onClose={() => setOpen(false)} title="Hapus akun secara permanen?">
        <div className="space-y-3 text-sm">
          <p>Ketik <b>HAPUS AKUN SAYA</b> dan masukkan kata sandi untuk melanjutkan.</p>
          <input aria-label="Konfirmasi" className="input" value={text} onChange={(e) => setText(e.target.value)} />
          <input aria-label="Kata sandi" type="password" autoComplete="current-password" className="input" value={pw} onChange={(e) => setPw(e.target.value)} placeholder="Kata sandi" />
          {err && <p role="alert" className="text-red-700">{err}</p>}
          <div className="flex gap-2"><Button variant="bahaya" loading={busy} disabled={text !== "HAPUS AKUN SAYA" || !pw} onClick={run}>Hapus permanen</Button><Button variant="hantu" onClick={() => setOpen(false)}>Batal</Button></div>
        </div>
      </Modal>
    </div>
  );
}
