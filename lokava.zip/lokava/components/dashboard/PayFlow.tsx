"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Button } from "@/components/ui/Button";
import { api } from "@/components/ui/fetcher";
import { useToast } from "@/components/ui/Toast";
import { ImageUploader } from "@/components/forms/ImageUploader";
import { formatRupiah } from "@/lib/utils/format";
import { PROMOTION_KIND_LABEL, type CategoryDoc, type ImageAsset, type PaymentMethodDoc, type PlanDoc, type ProductDoc, type PromotionTypeDoc, type BusinessDoc } from "@/types";

function PaymentPicker({ methods, value, onChange }: { methods: PaymentMethodDoc[]; value: string; onChange: (v: string) => void }) {
  if (!methods.length) return <p className="rounded-xl bg-amber-50 p-3 text-sm text-amber-900">Metode pembayaran belum tersedia. Hubungi admin LOKAVA.</p>;
  return (
    <fieldset><legend className="label">Metode pembayaran</legend>
      <div className="grid gap-2 sm:grid-cols-2">{methods.map((m) => (<label key={m.id} className={`cursor-pointer rounded-xl border p-3 text-sm ${value === m.id ? "border-toska-500 bg-toska-50" : "border-samudra-200"}`}><input type="radio" name="pm" className="sr-only" checked={value === m.id} onChange={() => onChange(m.id)} /><b>{m.name}</b><br />{m.provider}</label>))}</div>
    </fieldset>
  );
}

export function SubscriptionPicker({ businesses, plans, methods, currentPlanId }: { businesses: Pick<BusinessDoc, "id" | "name" | "verificationStatus">[]; plans: PlanDoc[]; methods: PaymentMethodDoc[]; currentPlanId: Record<string, string> }) {
  const router = useRouter(); const toast = useToast();
  const approved = businesses.filter((b) => b.verificationStatus === "approved");
  const [bid, setBid] = useState(approved[0]?.id ?? ""); const [pm, setPm] = useState(methods[0]?.id ?? ""); const [busy, setBusy] = useState("");
  if (!approved.length) return <p className="rounded-xl bg-amber-50 p-4 text-sm text-amber-900">Paket dapat dipilih setelah bisnis Anda disetujui admin.</p>;
  async function choose(p: PlanDoc) {
    setBusy(p.id);
    try {
      const r = await api<{ switched: boolean; id?: string }>("/api/owner/subscription", "POST", { businessId: bid, planId: p.id, paymentMethodId: pm || "none" });
      if (r.switched) { toast("Paket diganti."); router.refresh(); } else { toast("Transaksi dibuat. Lanjutkan pembayaran."); router.push(`/dashboard/transaksi?id=${r.id}`); }
    } catch (e) { toast((e as Error).message, "error"); } finally { setBusy(""); }
  }
  return (
    <div className="space-y-5">
      {approved.length > 1 && <div><label className="label" htmlFor="bz">Bisnis</label><select id="bz" className="input max-w-sm" value={bid} onChange={(e) => setBid(e.target.value)}>{approved.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}</select></div>}
      <PaymentPicker methods={methods} value={pm} onChange={setPm} />
      <div className="grid gap-4 sm:grid-cols-3">
        {plans.map((p) => (
          <div key={p.id} className="kartu flex flex-col p-5">
            <h3 className="font-bold">{p.name}</h3>
            <p className="text-2xl font-bold text-samudra-800">{p.price === 0 ? "Gratis" : formatRupiah(p.price)}{p.durationDays > 0 && <span className="text-sm font-normal text-samudra-600"> / {p.durationDays} hari</span>}</p>
            <p className="mt-1 text-sm text-samudra-700">{p.description}</p>
            <ul className="mt-3 flex-1 space-y-1 text-sm"><li>{p.maxBusinessPhotos} foto bisnis</li><li>{p.maxProducts} produk</li><li>{p.maxProductPhotos} foto per produk</li><li>{p.maxPromotions} promosi</li>{p.features.map((f) => <li key={f}>{f}</li>)}</ul>
            <Button className="mt-4" variant={currentPlanId[bid] === p.id ? "garis" : "utama"} loading={busy === p.id} disabled={currentPlanId[bid] === p.id || (p.price > 0 && !pm)} onClick={() => choose(p)}>{currentPlanId[bid] === p.id ? "Paket saat ini" : p.price === 0 ? "Pilih paket gratis" : "Pilih dan bayar"}</Button>
          </div>
        ))}
      </div>
      <p className="bantuan">Harga dihitung oleh server dan tidak dapat diubah dari perangkat Anda. Paket aktif setelah pembayaran diperiksa dan disetujui admin.</p>
    </div>
  );
}

export function PromotionPicker({ businesses, types, methods, products, categories }: { businesses: Pick<BusinessDoc, "id" | "name" | "categoryIds" | "verificationStatus">[]; types: PromotionTypeDoc[]; methods: PaymentMethodDoc[]; products: Pick<ProductDoc, "id" | "name" | "businessId" | "status">[]; categories: CategoryDoc[] }) {
  const router = useRouter(); const toast = useToast();
  const approved = businesses.filter((b) => b.verificationStatus === "approved");
  const [bid, setBid] = useState(approved[0]?.id ?? ""); const [tid, setTid] = useState(types[0]?.id ?? ""); const type = types.find((t) => t.id === tid);
  const [days, setDays] = useState(type?.durations[0] ?? 7); const [productId, setProductId] = useState(""); const [categoryId, setCategoryId] = useState("");
  const [banner, setBanner] = useState<ImageAsset[]>([]); const [pm, setPm] = useState(methods[0]?.id ?? ""); const [busy, setBusy] = useState(false);
  if (!approved.length) return <p className="rounded-xl bg-amber-50 p-4 text-sm text-amber-900">Promosi dapat diajukan setelah bisnis Anda disetujui.</p>;
  if (!types.length) return <p className="text-sm">Belum ada jenis promosi yang tersedia.</p>;
  const biz = approved.find((b) => b.id === bid)!;
  const price = type ? (type.durationPrices?.[String(days)] ?? Math.round((type.basePrice * days) / Math.max(type.baseDays, 1))) : 0; // hanya tampilan; server menghitung ulang
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true);
    try {
      const r = await api<{ id: string }>("/api/owner/promotions", "POST", { businessId: bid, promotionTypeId: tid, durationDays: days, productId: productId || null, categoryId: categoryId || null, bannerImage: banner[0] ?? null, paymentMethodId: pm });
      toast("Pengajuan promosi dibuat. Lanjutkan pembayaran."); router.push(`/dashboard/transaksi?id=${r.id}`);
    } catch (x) { toast((x as Error).message, "error"); } finally { setBusy(false); }
  }
  return (
    <form onSubmit={submit} className="kartu space-y-4 p-5">
      <h2 className="judul text-lg font-semibold">Ajukan promosi</h2>
      {approved.length > 1 && <div><label className="label" htmlFor="pb">Bisnis</label><select id="pb" className="input" value={bid} onChange={(e) => setBid(e.target.value)}>{approved.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}</select></div>}
      <div><label className="label" htmlFor="pt">Jenis promosi</label><select id="pt" className="input" value={tid} onChange={(e) => { setTid(e.target.value); setDays(types.find((t) => t.id === e.target.value)?.durations[0] ?? 7); }}>{types.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</select>{type && <p className="bantuan">{type.description} ({PROMOTION_KIND_LABEL[type.kind]})</p>}</div>
      <div><label className="label" htmlFor="pdur">Durasi</label><select id="pdur" className="input" value={days} onChange={(e) => setDays(Number(e.target.value))}>{type?.durations.map((d) => <option key={d} value={d}>{d} hari</option>)}</select></div>
      {type?.kind === "product" && <div><label className="label" htmlFor="pprod">Produk</label><select id="pprod" required className="input" value={productId} onChange={(e) => setProductId(e.target.value)}><option value="">Pilih produk aktif</option>{products.filter((p) => p.businessId === bid && p.status === "active").map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select></div>}
      {type?.kind === "category" && <div><label className="label" htmlFor="pcat">Kategori</label><select id="pcat" required className="input" value={categoryId} onChange={(e) => setCategoryId(e.target.value)}><option value="">Pilih kategori</option>{categories.filter((c) => biz.categoryIds.includes(c.id)).map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></div>}
      {type?.kind === "home_banner" && <ImageUploader purpose="promotion" label="Gambar banner" value={banner} onChange={setBanner} max={1} help="Disarankan rasio lebar 21:9. Banner diperiksa admin." />}
      <PaymentPicker methods={methods} value={pm} onChange={setPm} />
      <p className="text-lg font-bold">Perkiraan biaya: {formatRupiah(price)}</p>
      <p className="bantuan">Nominal final ditetapkan server saat transaksi dibuat. Masa berlaku dihitung sejak admin menyetujui pembayaran.</p>
      <Button type="submit" loading={busy} disabled={!pm}>Buat pengajuan</Button>
    </form>
  );
}
