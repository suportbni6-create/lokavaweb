import { Photo } from "@/components/ui/misc";
import type { ImageAsset } from "@/types";

export function Gallery({ cover, images, name }: { cover: ImageAsset | null; images: ImageAsset[]; name: string }) {
  const rest = images.filter((i) => i.publicId !== cover?.publicId);
  return (
    <div className="space-y-2">
      <Photo image={cover} alt={name} className="aspect-[16/10] w-full rounded-2xl" sizes="(max-width: 1024px) 100vw, 720px" priority />
      {rest.length > 0 && (
        <ul className="grid grid-cols-3 gap-2 sm:grid-cols-4">
          {rest.map((g, i) => (<li key={g.publicId}><Photo image={g} alt={`${name} foto ${i + 2}`} className="aspect-square w-full rounded-xl" sizes="200px" /></li>))}
        </ul>
      )}
    </div>
  );
}
