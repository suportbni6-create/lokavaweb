"use client";
import { useState } from "react";
import { Button } from "@/components/ui/Button";

export function ShareButton({ title, path }: { title: string; path: string }) {
  const [done, setDone] = useState(false);
  async function share() {
    const url = `${window.location.origin}${path}`;
    try {
      if (navigator.share) await navigator.share({ title, url });
      else { await navigator.clipboard.writeText(url); setDone(true); setTimeout(() => setDone(false), 2500); }
    } catch { /* dibatalkan pengguna */ }
  }
  return <Button variant="garis" onClick={share}>{done ? "Tautan disalin" : "Bagikan"}</Button>;
}
