import Link from "next/link";
import { Badge, Photo } from "@/components/ui/misc";
import { WaButton } from "@/components/cards/WaButton";
import { formatRupiah } from "@/lib/utils/format";
import type { PublicBusiness, PublicProduct } from "@/lib/data/public";
import type { CategoryDoc, DestinationDoc } from "@/types";

export function BusinessCard({ b, cats }: { b: PublicBusiness; cats?: CategoryDoc[] }) {
  const names = (cats ?? []).filter((c) => b.categoryIds.includes(c.id)).map((c) => c.name);
  return (
    <article className="kartu group flex flex-col overflow-hidden transition hover:-translate-y-0.5">
      <Link href={`/bisnis/${b.slug}`} className="block">
        <Photo image={b.coverImage} alt={b.name} className="aspect-[4/3] w-full" />
      </Link>
      <div className="flex flex-1 flex-col gap-2 p-4">
        <div className="flex flex-wrap gap-1.5">
          <Badge tone="biru">Terverifikasi</Badge>
          {names.slice(0, 2).map((n) => <Badge key={n}>{n}</Badge>)}
        </div>
        <h3 className="judul text-lg font-semibold leading-snug"><Link href={`/bisnis/${b.slug}`} className="hover:text-toska-700">{b.name}</Link></h3>
        <p className="text-xs text-samudra-600">{b.village}, {b.district}</p>
        <p className="line-clamp-2 text-sm text-samudra-700">{b.description}</p>
        <div className="mt-auto flex gap-2 pt-2">
          <Link href={`/bisnis/${b.slug}`} className="inline-flex min-h-11 flex-1 items-center justify-center rounded-xl border border-samudra-300 text-sm font-semibold text-samudra-800 hover:bg-samudra-50">Lihat detail</Link>
          {b.whatsapp && <WaButton number={b.whatsapp} intent="umum" businessName={b.name} compact />}
        </div>
      </div>
    </article>
  );
}

export function ProductCard({ p, businessName }: { p: PublicProduct; businessName?: string }) {
  return (
    <article className="kartu flex flex-col overflow-hidden">
      <Link href={`/produk/${p.slug}`}><Photo image={p.images[0]} alt={p.name} className="aspect-square w-full" /></Link>
      <div className="flex flex-1 flex-col gap-1 p-3">
        <h3 className="line-clamp-2 text-sm font-semibold"><Link href={`/produk/${p.slug}`} className="hover:text-toska-700">{p.name}</Link></h3>
        {businessName && <p className="text-xs text-samudra-600">{businessName}</p>}
        <p className="mt-auto pt-1 text-base font-bold text-samudra-800">{formatRupiah(p.price)}</p>
        {p.availability !== "tersedia" && <Badge tone="kuning">{p.availability === "habis" ? "Habis" : "Pesan dulu"}</Badge>}
      </div>
    </article>
  );
}

export function DestinationCard({ d }: { d: Omit<DestinationDoc, "searchTokens"> }) {
  return (
    <article className="kartu overflow-hidden">
      <Link href={`/wisata/${d.slug}`}><Photo image={d.coverImage} alt={d.name} className="aspect-[16/10] w-full" /></Link>
      <div className="space-y-1.5 p-4">
        <div className="flex gap-1.5">{d.verified && <Badge tone="biru">Terverifikasi</Badge>}</div>
        <h3 className="judul text-lg font-semibold"><Link href={`/wisata/${d.slug}`} className="hover:text-toska-700">{d.name}</Link></h3>
        <p className="text-xs text-samudra-600">{d.district}, {d.region}</p>
        <p className="line-clamp-2 text-sm text-samudra-700">{d.description}</p>
        {d.ticketPrice !== null && <p className="text-sm font-semibold text-samudra-800">Tiket {d.ticketPrice === 0 ? "gratis" : formatRupiah(d.ticketPrice)}</p>}
      </div>
    </article>
  );
}

export function Section({ title, text, href, children }: { title: string; text?: string; href?: string; children: React.ReactNode }) {
  return (
    <section className="wadah py-8 sm:py-10">
      <div className="mb-5 flex items-end justify-between gap-4">
        <div>
          <h2 className="judul text-2xl font-semibold sm:text-3xl">{title}</h2>
          {text && <p className="mt-1 text-sm text-samudra-700">{text}</p>}
        </div>
        {href && <Link href={href} className="shrink-0 text-sm font-semibold text-toska-700 hover:underline">Lihat semua</Link>}
      </div>
      {children}
    </section>
  );
}

export const Grid = ({ children, cols = 3 }: { children: React.ReactNode; cols?: 3 | 4 }) => (
  <div className={`grid gap-4 sm:grid-cols-2 ${cols === 4 ? "lg:grid-cols-4" : "lg:grid-cols-3"}`}>{children}</div>
);
