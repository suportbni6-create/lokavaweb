import type { OpeningHour } from "@/types";

export function Hours({ hours }: { hours: OpeningHour[] }) {
  if (!hours?.length) return <p className="text-sm text-samudra-600">Jam operasional belum diinformasikan.</p>;
  return (
    <dl className="grid grid-cols-[6rem_1fr] gap-y-1 text-sm">
      {hours.map((h) => (
        <div key={h.day} className="contents">
          <dt className="font-semibold text-samudra-800">{h.day}</dt>
          <dd className="text-samudra-700">{h.closed ? "Tutup" : `${h.open} – ${h.close}`}</dd>
        </div>
      ))}
    </dl>
  );
}
