import { buildWhatsappLink, whatsappMessage, type WaIntent } from "@/lib/utils/whatsapp";

const LABEL: Record<WaIntent, string> = { umum: "Hubungi via WhatsApp", harga: "Tanya harga", ketersediaan: "Tanya ketersediaan", informasi: "Pesan informasi" };

/** Tautan wa.me biasa. Tidak ada pesan terkirim otomatis: pengguna harus menekan tombol dan menekan kirim di WhatsApp. */
export function WaButton({ number, intent = "umum", businessName, productName, compact }: { number: string; intent?: WaIntent; businessName?: string; productName?: string; compact?: boolean }) {
  const href = buildWhatsappLink(number, whatsappMessage(intent, { businessName, productName }));
  return (
    <a href={href} target="_blank" rel="noopener noreferrer" className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-[#128c4a] px-4 text-sm font-semibold text-white hover:bg-[#0e7a40]">
      <svg aria-hidden width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M4 4h16a1 1 0 0 1 1 1v11a1 1 0 0 1-1 1H9l-5 4V5a1 1 0 0 1 1-1Z" /></svg>
      {compact ? "WhatsApp" : LABEL[intent]}
    </a>
  );
}
