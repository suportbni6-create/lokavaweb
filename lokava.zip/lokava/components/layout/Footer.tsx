import Link from "next/link";
import { Logo } from "@/components/ui/misc";
import type { AppSettings } from "@/types";

export function Footer({ s }: { s: AppSettings }) {
  return (
    <footer className="mt-16 bg-samudra-900 text-samudra-100">
      <div className="wadah grid gap-8 py-10 md:grid-cols-4">
        <div className="md:col-span-2">
          <Logo name={s.appName} className="[&_span]:!text-white" />
          <p className="mt-3 max-w-md text-sm text-samudra-200">{s.description}</p>
          <p className="mt-3 text-sm text-samudra-300">{s.footerContent}</p>
        </div>
        <nav aria-label="Jelajahi">
          <h2 className="mb-2 text-sm font-semibold text-white">Jelajahi</h2>
          <ul className="space-y-1.5 text-sm">
            {[["/wisata", "Wisata"], ["/kuliner", "Kuliner"], ["/penginapan", "Penginapan"], ["/bisnis", "Direktori bisnis"], ["/promosi", "Promosi"], ["/peta", "Peta"]].map(([h, l]) => (
              <li key={h}><Link href={h!} className="hover:text-white">{l}</Link></li>
            ))}
          </ul>
        </nav>
        <nav aria-label="Pemilik usaha">
          <h2 className="mb-2 text-sm font-semibold text-white">Pemilik usaha</h2>
          <ul className="space-y-1.5 text-sm">
            <li><Link href="/daftar-bisnis" className="hover:text-white">Daftarkan bisnis</Link></li>
            <li><Link href="/login" className="hover:text-white">Masuk</Link></li>
            <li><Link href="/privasi" className="hover:text-white">Kebijakan privasi</Link></li>
            <li><Link href="/syarat" className="hover:text-white">Syarat penggunaan</Link></li>
            {s.contactEmail && <li><a href={`mailto:${s.contactEmail}`} className="hover:text-white">{s.contactEmail}</a></li>}
          </ul>
        </nav>
      </div>
      <div className="border-t border-white/10 py-4 text-center text-xs text-samudra-300">© {new Date().getFullYear()} {s.appName}. Peta © kontributor OpenStreetMap.</div>
    </footer>
  );
}
