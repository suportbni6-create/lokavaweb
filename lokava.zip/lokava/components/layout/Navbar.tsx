"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import clsx from "clsx";
import { Logo } from "@/components/ui/misc";
import type { ImageAsset } from "@/types";

const LINKS = [
  { href: "/wisata", label: "Wisata" },
  { href: "/kuliner", label: "Kuliner" },
  { href: "/penginapan", label: "Penginapan" },
  { href: "/bisnis", label: "Bisnis" },
  { href: "/promosi", label: "Promosi" },
  { href: "/peta", label: "Peta" },
];

export function Navbar({ appName }: { appName: string; logo?: ImageAsset | null }) {
  const pathname = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [role, setRole] = useState<"owner" | "admin" | null>(null);
  const [q, setQ] = useState("");

  useEffect(() => {
    let alive = true;
    fetch("/api/auth/me", { cache: "no-store" }).then((r) => r.json()).then((d) => alive && setRole(d.role)).catch(() => undefined);
    return () => { alive = false; };
  }, [pathname]);
  useEffect(() => setOpen(false), [pathname]);

  const akun = role === "admin" ? { href: "/admin", label: "Admin" } : role === "owner" ? { href: "/dashboard", label: "Dashboard" } : { href: "/login", label: "Masuk" };

  return (
    <header className="sticky top-0 z-40 border-b border-samudra-100 bg-white/90 backdrop-blur">
      <div className="wadah flex h-16 items-center gap-4">
        <Link href="/" aria-label={`${appName} beranda`}><Logo name={appName} /></Link>
        <nav aria-label="Navigasi utama" className="ml-4 hidden items-center gap-1 lg:flex">
          {LINKS.map((l) => (
            <Link key={l.href} href={l.href} className={clsx("rounded-lg px-3 py-2 text-sm font-semibold hover:bg-samudra-50", pathname.startsWith(l.href) ? "text-toska-700" : "text-samudra-800")}>{l.label}</Link>
          ))}
        </nav>
        <form role="search" onSubmit={(e) => { e.preventDefault(); if (q.trim()) router.push(`/cari?q=${encodeURIComponent(q.trim())}`); }} className="ml-auto hidden md:block">
          <label htmlFor="cari-nav" className="sr-only">Cari</label>
          <input id="cari-nav" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cari pantai, seafood, homestay…" className="input w-64 !py-2" />
        </form>
        <Link href={akun.href} className="ml-auto rounded-xl bg-samudra-700 px-4 py-2 text-sm font-semibold text-white hover:bg-samudra-800 md:ml-0">{akun.label}</Link>
        <button className="rounded-lg p-2 lg:hidden" aria-expanded={open} aria-controls="menu-mobile" aria-label="Menu" onClick={() => setOpen((v) => !v)}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d={open ? "M6 6l12 12M18 6L6 18" : "M4 7h16M4 12h16M4 17h16"} /></svg>
        </button>
      </div>
      {open && (
        <div id="menu-mobile" className="border-t border-samudra-100 bg-white px-4 pb-4 lg:hidden">
          <form role="search" onSubmit={(e) => { e.preventDefault(); if (q.trim()) router.push(`/cari?q=${encodeURIComponent(q.trim())}`); }} className="py-3">
            <label htmlFor="cari-mobile" className="sr-only">Cari</label>
            <input id="cari-mobile" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cari wisata, kuliner, penginapan…" className="input" />
          </form>
          <ul className="grid grid-cols-2 gap-2">
            {LINKS.map((l) => (<li key={l.href}><Link href={l.href} className="block rounded-xl bg-samudra-50 px-4 py-3 text-sm font-semibold text-samudra-800">{l.label}</Link></li>))}
          </ul>
        </div>
      )}
    </header>
  );
}
