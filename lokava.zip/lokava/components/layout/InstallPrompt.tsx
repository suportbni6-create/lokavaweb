"use client";
import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/Button";

interface BIPEvent extends Event { prompt: () => Promise<void>; userChoice: Promise<{ outcome: "accepted" | "dismissed" }> }
const KEY = "lokava:install";
const COOLDOWN_MS = 14 * 24 * 3600 * 1000;

function dismissedRecently() {
  try { const v = Number(localStorage.getItem(KEY)); return v > 0 && Date.now() - v < COOLDOWN_MS; } catch { return false; }
}
const remember = () => { try { localStorage.setItem(KEY, String(Date.now())); } catch { /* penyimpanan tidak tersedia */ } };

export function InstallPrompt({ enabled }: { enabled: boolean }) {
  const [mode, setMode] = useState<"native" | "ios" | null>(null);
  const evt = useRef<BIPEvent | null>(null);

  useEffect(() => {
    if (!enabled || dismissedRecently()) return;
    const standalone = window.matchMedia("(display-mode: standalone)").matches || (navigator as unknown as { standalone?: boolean }).standalone === true;
    if (standalone) return; // sudah terpasang
    const timers: ReturnType<typeof setTimeout>[] = [];
    const onBip = (e: Event) => { e.preventDefault(); evt.current = e as BIPEvent; timers.push(setTimeout(() => setMode("native"), 4000)); };
    const onInstalled = () => { setMode(null); remember(); };
    window.addEventListener("beforeinstallprompt", onBip);
    window.addEventListener("appinstalled", onInstalled);
    const ua = navigator.userAgent;
    const isIOS = /iPhone|iPad|iPod/.test(ua) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
    const isSafari = /Safari/.test(ua) && !/CriOS|FxiOS|EdgiOS/.test(ua);
    if (isIOS && isSafari) timers.push(setTimeout(() => setMode("ios"), 6000));
    return () => { window.removeEventListener("beforeinstallprompt", onBip); window.removeEventListener("appinstalled", onInstalled); timers.forEach(clearTimeout); };
  }, [enabled]);

  if (!mode) return null;
  const close = () => { remember(); setMode(null); };
  const install = async () => {
    const e = evt.current;
    if (!e) return close();
    await e.prompt();
    await e.userChoice.catch(() => undefined);
    remember();
    setMode(null);
  };

  return (
    <div role="dialog" aria-labelledby="pasang-judul" className="fixed inset-x-3 bottom-3 z-50 mx-auto max-w-md rounded-2xl border border-samudra-100 bg-white p-4 shadow-2xl sm:bottom-6">
      <h2 id="pasang-judul" className="judul text-lg font-semibold">Pasang LOKAVA di HP kamu!</h2>
      <p className="mt-1 text-sm text-samudra-700">Jelajahi wisata, kuliner, dan keindahan Sukabumi Selatan langsung dari layar utama.</p>
      {mode === "ios" && (
        <p className="mt-2 rounded-xl bg-samudra-50 p-3 text-sm text-samudra-800">Di iPhone: ketuk tombol <b>Bagikan</b> (kotak dengan panah ke atas) di Safari, lalu pilih <b>Tambahkan ke Layar Utama</b>.</p>
      )}
      <div className="mt-3 flex gap-2">
        {mode === "native" && <Button onClick={install}>Pasang Sekarang</Button>}
        <Button variant="hantu" onClick={close}>{mode === "ios" ? "Mengerti" : "Nanti Saja"}</Button>
      </div>
    </div>
  );
}
