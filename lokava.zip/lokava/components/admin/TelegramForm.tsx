"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Button } from "@/components/ui/Button";
import { api } from "@/components/ui/fetcher";
import { useToast } from "@/components/ui/Toast";
import type { TelegramSettings } from "@/types";

export function TelegramForm({ initial, tokenConfigured, webhookSecretConfigured, canEdit }: { initial: TelegramSettings; tokenConfigured: boolean; webhookSecretConfigured: boolean; canEdit: boolean }) {
  const router = useRouter(); const toast = useToast();
  const [s, setS] = useState({ ...initial, ids: initial.allowedAdminIds.join(", "), token: "" });
  const [busy, setBusy] = useState("");
  const set = (k: string, v: unknown) => setS((x) => ({ ...x, [k]: v }));
  const notif = (k: keyof TelegramSettings["notifications"], v: boolean) => setS((x) => ({ ...x, notifications: { ...x.notifications, [k]: v } }));
  async function save() {
    setBusy("save");
    try {
      await api("/api/admin/telegram", "PUT", { enabled: s.enabled, destinationChatId: s.destinationChatId, allowedAdminIds: s.ids.split(",").map((x) => x.trim()).filter(Boolean), verificationMode: s.verificationMode, notifications: s.notifications, ...(s.token ? { botToken: s.token } : {}) });
      set("token", ""); toast("Pengaturan Telegram disimpan."); router.refresh();
    } catch (e) { toast((e as Error).message, "error"); } finally { setBusy(""); }
  }
  async function act(action: "test" | "webhook") {
    setBusy(action);
    try { const r = await api<{ ok: boolean; message: string }>("/api/admin/telegram", "POST", { action }); toast(r.message, r.ok ? "ok" : "error"); } catch (e) { toast((e as Error).message, "error"); } finally { setBusy(""); }
  }
  return (
    <form onSubmit={(e) => { e.preventDefault(); save(); }} className="space-y-5">
      {!canEdit && <p className="rounded-xl bg-amber-50 p-3 text-sm text-amber-900">Hanya admin utama yang dapat mengubah pengaturan Telegram.</p>}
      <fieldset disabled={!canEdit || !!busy} className="kartu space-y-4 p-5">
        <label className="flex items-center gap-2 font-semibold"><input type="checkbox" className="h-5 w-5" checked={s.enabled} onChange={(e) => set("enabled", e.target.checked)} />Integrasi aktif</label>
        <div><label className="label" htmlFor="tk">Bot token</label><input id="tk" type="password" autoComplete="off" className="input" value={s.token} onChange={(e) => set("token", e.target.value)} placeholder={tokenConfigured ? "Token sudah dikonfigurasi (isi untuk mengganti)" : "Tempel token dari @BotFather"} /><p className="bantuan">Status: <b>{tokenConfigured ? "Token sudah dikonfigurasi" : "Token belum dikonfigurasi"}</b>. Token dienkripsi di server dan tidak pernah ditampilkan kembali. Alternatif: isi variabel <code>TELEGRAM_BOT_TOKEN</code> di Vercel.</p></div>
        <div><label className="label" htmlFor="ch">Chat ID tujuan notifikasi</label><input id="ch" className="input" value={s.destinationChatId} onChange={(e) => set("destinationChatId", e.target.value)} /></div>
        <div><label className="label" htmlFor="ad">ID Telegram admin yang diizinkan (pisahkan koma)</label><input id="ad" className="input" value={s.ids} onChange={(e) => set("ids", e.target.value)} /><p className="bantuan">Kirim /id ke bot dalam chat pribadi untuk mengetahui ID Anda. Hanya ID ini yang dapat menekan tombol setujui/tolak.</p></div>
        <div><label className="label" htmlFor="md">Mode verifikasi pendaftaran</label><select id="md" className="input" value={s.verificationMode} onChange={(e) => set("verificationMode", e.target.value)}><option value="manual">Manual: admin memutuskan semuanya</option><option value="assisted">Berbantuan (default): data tak lengkap otomatis dikembalikan, keputusan akhir tetap admin</option><option value="auto">Auto-approval: setujui otomatis hanya jika data lengkap dan tanpa tanda curiga</option></select></div>
        <fieldset><legend className="label">Jenis notifikasi</legend><div className="flex flex-wrap gap-4 text-sm">{([["business", "Pendaftaran"], ["payment", "Pembayaran"], ["decisions", "Keputusan"], ["errors", "Error penting"]] as const).map(([k, l]) => (<label key={k} className="flex items-center gap-2"><input type="checkbox" className="h-5 w-5" checked={s.notifications[k]} onChange={(e) => notif(k, e.target.checked)} />{l}</label>))}</div></fieldset>
        <p className="text-sm">Rahasia webhook: <b>{webhookSecretConfigured ? "terkonfigurasi" : "BELUM diisi (TELEGRAM_WEBHOOK_SECRET)"}</b></p>
        <div className="flex flex-wrap gap-2"><Button type="submit" loading={busy === "save"}>Simpan</Button><Button type="button" variant="garis" loading={busy === "test"} onClick={() => act("test")}>Uji koneksi & notifikasi</Button><Button type="button" variant="garis" loading={busy === "webhook"} disabled={!webhookSecretConfigured} onClick={() => act("webhook")}>Pasang webhook</Button></div>
      </fieldset>
    </form>
  );
}
