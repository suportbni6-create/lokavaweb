"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Button } from "@/components/ui/Button";
import { Modal } from "@/components/ui/Modal";
import { api } from "@/components/ui/fetcher";
import { useToast } from "@/components/ui/Toast";

export interface ActionDef { label: string; variant?: "utama" | "bahaya" | "garis" | "sekunder"; method: "POST" | "PATCH"; body: Record<string, unknown>; needsReason?: boolean; reasonLabel?: string; confirm?: string }

/** Tombol aksi admin; aksi yang butuh alasan membuka dialog. Alasan wajib untuk penolakan. */
export function ActionButtons({ url, actions }: { url: string; actions: ActionDef[] }) {
  const router = useRouter(); const toast = useToast();
  const [pending, setPending] = useState<ActionDef | null>(null); const [reason, setReason] = useState(""); const [busy, setBusy] = useState(false);
  async function run(a: ActionDef, r?: string) {
    setBusy(true);
    try { await api(url, a.method, { ...a.body, ...(r ? { reason: r } : {}) }); toast("Berhasil."); setPending(null); setReason(""); router.refresh(); }
    catch (e) { toast((e as Error).message, "error"); } finally { setBusy(false); }
  }
  return (
    <>
      <div className="flex flex-wrap gap-2">
        {actions.map((a) => (<Button key={a.label} variant={a.variant ?? "garis"} loading={busy && !pending} onClick={() => { if (a.needsReason) setPending(a); else if (!a.confirm || confirm(a.confirm)) run(a); }}>{a.label}</Button>))}
      </div>
      <Modal open={!!pending} onClose={() => setPending(null)} title={pending?.label ?? ""}>
        <div className="space-y-3">
          <label className="label" htmlFor="alasan">{pending?.reasonLabel ?? "Alasan (wajib, dilihat pemilik)"}</label>
          <textarea id="alasan" rows={3} maxLength={500} className="input" value={reason} onChange={(e) => setReason(e.target.value)} />
          <div className="flex gap-2"><Button variant={pending?.variant ?? "utama"} loading={busy} disabled={reason.trim().length < 3} onClick={() => pending && run(pending, reason.trim())}>Konfirmasi</Button><Button variant="hantu" onClick={() => setPending(null)}>Batal</Button></div>
        </div>
      </Modal>
    </>
  );
}
