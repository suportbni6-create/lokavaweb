"use client";
import { useCallback, useEffect, useState } from "react";
import { Button } from "@/components/ui/Button";
import { Modal } from "@/components/ui/Modal";
import { Badge, EmptyState, ErrorState, Skeleton } from "@/components/ui/misc";
import { api } from "@/components/ui/fetcher";
import { useToast } from "@/components/ui/Toast";
import { ImageUploader } from "@/components/forms/ImageUploader";
import { formatRupiah, formatTanggal } from "@/lib/utils/format";
import type { ImageAsset } from "@/types";

export type FieldDef = {
  key: string; label: string; help?: string;
  type: "text" | "textarea" | "number" | "bool" | "select" | "multiselect" | "image" | "images" | "tags" | "numbers" | "datetime";
  options?: [string, string][]; required?: boolean; max?: number;
};
export type ColDef = { key: string; label: string; kind?: "text" | "rupiah" | "bool" | "date" | "list" | "image" };
export interface CrudConfig { collection: string; title: string; text?: string; nameKey: string; fields: FieldDef[]; cols: ColDef[]; defaults: Record<string, unknown>; softDelete?: boolean }

type Item = Record<string, unknown> & { id: string };
const SKIP = new Set(["id", "createdAt", "updatedAt", "searchTokens", "slug"]);

function toForm(cfg: CrudConfig, item?: Item): Record<string, unknown> {
  const src = { ...cfg.defaults, ...(item ?? {}) } as Record<string, unknown>;
  const out: Record<string, unknown> = {};
  for (const f of cfg.fields) {
    const v = src[f.key];
    if (f.type === "tags" || f.type === "numbers") out[f.key] = Array.isArray(v) ? v.join(", ") : "";
    else if (f.type === "number") out[f.key] = v === null || v === undefined ? "" : String(v);
    else if (f.type === "datetime") out[f.key] = typeof v === "string" ? new Date(new Date(v).getTime() - new Date(v).getTimezoneOffset() * 60000).toISOString().slice(0, 16) : "";
    else if (f.type === "image") out[f.key] = v ? [v] : [];
    else if (f.type === "images") out[f.key] = Array.isArray(v) ? v : [];
    else if (f.type === "multiselect") out[f.key] = Array.isArray(v) ? v : [];
    else out[f.key] = v ?? (f.type === "bool" ? false : "");
  }
  return out;
}

function toPayload(cfg: CrudConfig, form: Record<string, unknown>, item?: Item) {
  const base: Record<string, unknown> = {};
  for (const [k, v] of Object.entries({ ...cfg.defaults, ...(item ?? {}) })) if (!SKIP.has(k)) base[k] = v;
  for (const f of cfg.fields) {
    const v = form[f.key];
    if (f.type === "tags") base[f.key] = String(v).split(",").map((s) => s.trim()).filter(Boolean);
    else if (f.type === "numbers") base[f.key] = String(v).split(",").map((s) => Number(s.trim())).filter((n) => Number.isFinite(n) && n > 0);
    else if (f.type === "number") base[f.key] = String(v).trim() === "" ? (f.required ? 0 : null) : Number(v);
    else if (f.type === "datetime") base[f.key] = v ? new Date(String(v)).toISOString() : null;
    else if (f.type === "image") base[f.key] = (v as ImageAsset[])[0] ?? null;
    else base[f.key] = v;
  }
  if (cfg.collection === "categories" || cfg.collection === "destinations") base.slug = item?.slug ?? undefined;
  return base;
}

function Cell({ col, item }: { col: ColDef; item: Item }) {
  const v = item[col.key];
  switch (col.kind) {
    case "rupiah": return <>{formatRupiah(v as number)}</>;
    case "bool": return <Badge tone={v ? "hijau" : "netral"}>{v ? "Ya" : "Tidak"}</Badge>;
    case "date": return <>{formatTanggal(v as string)}</>;
    case "list": return <>{Array.isArray(v) ? v.join(", ") : ""}</>;
    case "image": /* eslint-disable-next-line @next/next/no-img-element */ return v ? <img src={(v as ImageAsset).url} alt="" className="h-10 w-16 rounded object-cover" /> : <>-</>;
    default: return <>{v === null || v === undefined ? "-" : String(v)}</>;
  }
}

export function AdminCrud({ cfg }: { cfg: CrudConfig }) {
  const toast = useToast();
  const [items, setItems] = useState<Item[] | null>(null); const [err, setErr] = useState("");
  const [editing, setEditing] = useState<{ item?: Item; form: Record<string, unknown> } | null>(null); const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try { setItems((await api<{ items: Item[] }>(`/api/admin/${cfg.collection}`, "GET")).items); setErr(""); } catch (e) { setErr((e as Error).message); }
  }, [cfg.collection]);
  useEffect(() => { load(); }, [load]);

  async function save() {
    if (!editing) return;
    setBusy(true);
    try {
      const payload = toPayload(cfg, editing.form, editing.item);
      if (editing.item) await api(`/api/admin/${cfg.collection}/${editing.item.id}`, "PUT", payload); else await api(`/api/admin/${cfg.collection}`, "POST", payload);
      toast("Tersimpan."); setEditing(null); await load();
    } catch (e) { toast((e as Error).message, "error"); } finally { setBusy(false); }
  }
  async function remove(it: Item) {
    if (!confirm(cfg.softDelete ? `Nonaktifkan "${String(it[cfg.nameKey])}"? Data lama tetap tersimpan.` : `Hapus "${String(it[cfg.nameKey])}" secara permanen?`)) return;
    try { await api(`/api/admin/${cfg.collection}/${it.id}`, "DELETE"); toast(cfg.softDelete ? "Dinonaktifkan." : "Dihapus."); await load(); } catch (e) { toast((e as Error).message, "error"); }
  }
  const setF = (k: string, v: unknown) => setEditing((s) => (s ? { ...s, form: { ...s.form, [k]: v } } : s));

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
        <div><h1 className="judul text-2xl font-semibold">{cfg.title}</h1>{cfg.text && <p className="mt-1 max-w-2xl text-sm text-samudra-700">{cfg.text}</p>}</div>
        <Button onClick={() => setEditing({ form: toForm(cfg) })}>Tambah</Button>
      </div>
      {err && <ErrorState message={err} />}
      {!items && !err && <div className="space-y-2"><Skeleton className="h-14" /><Skeleton className="h-14" /></div>}
      {items && items.length === 0 && <EmptyState title="Belum ada data" text="Tekan Tambah untuk membuat data pertama." />}
      {items && items.length > 0 && (
        <ul className="space-y-2">
          {items.map((it) => (
            <li key={it.id} className="kartu flex flex-wrap items-center gap-x-5 gap-y-2 p-3 text-sm">
              <span className="min-w-40 flex-1 font-semibold">{String(it[cfg.nameKey])}</span>
              {cfg.cols.map((c) => (<span key={c.key} className="min-w-24"><span className="block text-xs text-samudra-600">{c.label}</span><Cell col={c} item={it} /></span>))}
              <span className="flex gap-1"><Button variant="hantu" onClick={() => setEditing({ item: it, form: toForm(cfg, it) })}>Ubah</Button><Button variant="hantu" className="!text-red-700" onClick={() => remove(it)}>{cfg.softDelete ? "Nonaktifkan" : "Hapus"}</Button></span>
            </li>
          ))}
        </ul>
      )}
      <Modal open={!!editing} onClose={() => setEditing(null)} title={editing?.item ? `Ubah ${cfg.title.toLowerCase()}` : `Tambah ${cfg.title.toLowerCase()}`}>
        {editing && (
          <form onSubmit={(e) => { e.preventDefault(); save(); }} className="max-h-[70vh] space-y-3 overflow-y-auto pr-1">
            {cfg.fields.map((f) => {
              const id = `f-${f.key}`; const v = editing.form[f.key];
              return (
                <div key={f.key}>
                  {f.type === "bool" ? (
                    <label className="flex items-center gap-2 text-sm font-semibold"><input type="checkbox" className="h-5 w-5" checked={Boolean(v)} onChange={(e) => setF(f.key, e.target.checked)} />{f.label}</label>
                  ) : f.type === "image" || f.type === "images" ? (
                    <ImageUploader purpose="admin" label={f.label} value={v as ImageAsset[]} onChange={(x) => setF(f.key, x)} max={f.type === "image" ? 1 : (f.max ?? 10)} />
                  ) : f.type === "multiselect" ? (
                    <fieldset><legend className="label">{f.label}</legend><div className="flex flex-wrap gap-2">{f.options?.map(([val, lab]) => { const on = (v as string[]).includes(val); return <label key={val} className={`cursor-pointer rounded-full border px-3 py-1 text-xs font-semibold ${on ? "border-toska-500 bg-toska-100" : "border-samudra-200"}`}><input type="checkbox" className="sr-only" checked={on} onChange={() => setF(f.key, on ? (v as string[]).filter((x) => x !== val) : [...(v as string[]), val])} />{lab}</label>; })}</div></fieldset>
                  ) : (
                    <>
                      <label className="label" htmlFor={id}>{f.label}</label>
                      {f.type === "textarea" ? <textarea id={id} rows={4} className="input" value={String(v ?? "")} onChange={(e) => setF(f.key, e.target.value)} required={f.required} />
                        : f.type === "select" ? <select id={id} className="input" value={String(v ?? "")} onChange={(e) => setF(f.key, e.target.value)}>{f.options?.map(([val, lab]) => <option key={val} value={val}>{lab}</option>)}</select>
                        : <input id={id} className="input" required={f.required} inputMode={f.type === "number" ? "numeric" : undefined} type={f.type === "datetime" ? "datetime-local" : "text"} value={String(v ?? "")} onChange={(e) => setF(f.key, e.target.value)} />}
                    </>
                  )}
                  {f.help && <p className="bantuan">{f.help}</p>}
                </div>
              );
            })}
            <div className="sticky bottom-0 flex gap-2 bg-white pt-2"><Button type="submit" loading={busy}>Simpan</Button><Button type="button" variant="hantu" onClick={() => setEditing(null)}>Batal</Button></div>
          </form>
        )}
      </Modal>
    </div>
  );
}
