"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Button } from "@/components/ui/Button";
import { api } from "@/components/ui/fetcher";
import { useToast } from "@/components/ui/Toast";
import { ImageUploader } from "@/components/forms/ImageUploader";
import type { AppSettings } from "@/types";

export function SettingsForm({ initial }: { initial: AppSettings }) {
  const router = useRouter(); const toast = useToast();
  const [s, setS] = useState(initial); const [busy, setBusy] = useState(false);
  const set = <K extends keyof AppSettings>(k: K, v: AppSettings[K]) => setS((x) => ({ ...x, [k]: v }));
  async function save() {
    setBusy(true);
    try { const { updatedAt: _u, ...body } = s; void _u; await api("/api/admin/settings", "PUT", body); toast("Pengaturan disimpan."); router.refresh(); } catch (e) { toast((e as Error).message, "error"); } finally { setBusy(false); }
  }
  const T = ({ k, label, area }: { k: keyof AppSettings; label: string; area?: boolean }) => (
    <div><label className="label" htmlFor={k}>{label}</label>{area ? <textarea id={k} rows={4} className="input" value={String(s[k] ?? "")} onChange={(e) => set(k, e.target.value as never)} /> : <input id={k} className="input" value={String(s[k] ?? "")} onChange={(e) => set(k, e.target.value as never)} />}</div>
  );
  return (
    <form onSubmit={(e) => { e.preventDefault(); save(); }} className="space-y-5">
      <fieldset className="kartu space-y-4 p-5"><legend className="judul px-1 text-lg font-semibold">Identitas</legend>
        <T k="appName" label="Nama aplikasi" /><T k="tagline" label="Tagline" /><T k="description" label="Deskripsi" area />
        <ImageUploader purpose="admin" label="Logo" value={s.logo ? [s.logo] : []} onChange={(v) => set("logo", v[0] ?? null)} max={1} help="Opsional. Jika kosong, logo teks bawaan dipakai." />
      </fieldset>
      <fieldset className="kartu space-y-4 p-5"><legend className="judul px-1 text-lg font-semibold">Kontak dan footer</legend><T k="contactEmail" label="Email kontak" /><T k="contactWhatsapp" label="WhatsApp kontak" /><T k="footerContent" label="Teks footer" /><T k="defaultRegion" label="Wilayah utama" /></fieldset>
      <fieldset className="kartu space-y-4 p-5"><legend className="judul px-1 text-lg font-semibold">SEO dan PWA</legend><T k="seoTitle" label="Judul SEO (maks 70)" /><T k="seoDescription" label="Deskripsi SEO (maks 170)" area />
        <div><label className="label" htmlFor="tc">Warna tema PWA</label><input id="tc" type="color" className="h-11 w-20 rounded-lg" value={s.pwaThemeColor} onChange={(e) => set("pwaThemeColor", e.target.value)} /></div>
        <label className="flex items-center gap-2 text-sm font-semibold"><input type="checkbox" className="h-5 w-5" checked={s.installPopupEnabled} onChange={(e) => set("installPopupEnabled", e.target.checked)} />Tampilkan popup ajakan memasang aplikasi</label>
        <label className="flex items-start gap-2 text-sm"><input type="checkbox" className="mt-0.5 h-5 w-5" checked={s.reverifyOnSensitiveChange} onChange={(e) => set("reverifyOnSensitiveChange", e.target.checked)} /><span><b>Verifikasi ulang</b> bila pemilik mengubah nama atau alamat bisnis yang sudah disetujui. Bisnis disembunyikan sampai disetujui lagi.</span></label>
      </fieldset>
      <fieldset className="kartu space-y-4 p-5"><legend className="judul px-1 text-lg font-semibold">Kebijakan</legend><T k="privacyPolicy" label="Kebijakan privasi" area /><T k="termsOfUse" label="Syarat penggunaan" area /></fieldset>
      <Button type="submit" loading={busy}>Simpan pengaturan</Button>
    </form>
  );
}
