import Link from "next/link";
import { ActionButtons } from "@/components/admin/ReasonButtons";
import { Badge, EmptyState, PageHeader } from "@/components/ui/misc";
import { db, docPlain } from "@/lib/firebase/admin";
import { formatTanggal } from "@/lib/utils/format";
import type { BusinessDoc, UserDoc } from "@/types";

export const metadata = { title: "Pengguna" };
const TONE = { active: "hijau", suspended: "merah", deletion_requested: "kuning", deleted: "netral" } as const;
const LABEL = { active: "Aktif", suspended: "Ditangguhkan", deletion_requested: "Penghapusan diminta", deleted: "Dihapus" } as const;

export default async function Page({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q } = await searchParams;
  const term = (q ?? "").trim().toLowerCase();
  const snap = term
    ? await db().collection("users").orderBy("email").startAt(term).endAt(term + "\uf8ff").limit(50).get()
    : await db().collection("users").orderBy("createdAt", "desc").limit(50).get();
  const users = snap.docs.map((d) => docPlain<UserDoc>(d)!);
  const bizByOwner = new Map<string, BusinessDoc[]>();
  await Promise.all(users.map(async (u) => { const s = await db().collection("businesses").where("ownerId", "==", u.uid).limit(5).get(); bizByOwner.set(u.uid, s.docs.map((d) => docPlain<BusinessDoc>(d)!)); }));
  return (
    <>
      <PageHeader title="Pengguna" text="Tidak ada kata sandi atau rahasia autentikasi yang ditampilkan." />
      <form className="mb-4 flex max-w-md gap-2"><label htmlFor="q" className="sr-only">Cari email</label><input id="q" name="q" defaultValue={q} placeholder="Awalan email" className="input" /><button className="rounded-xl bg-samudra-700 px-4 text-sm font-semibold text-white">Cari</button></form>
      {users.length === 0 ? <EmptyState title="Tidak ada pengguna" /> : (
        <ul className="space-y-2">
          {users.map((u) => (
            <li key={u.uid} className="kartu space-y-2 p-3 text-sm">
              <div className="flex flex-wrap items-center justify-between gap-2"><div><b>{u.displayName}</b> <span className="text-samudra-600">{u.email}</span><br /><span className="text-xs text-samudra-600">Daftar {formatTanggal(u.createdAt)} · {u.role}</span></div><div className="flex gap-1.5"><Badge tone={TONE[u.status]}>{LABEL[u.status]}</Badge></div></div>
              {(bizByOwner.get(u.uid) ?? []).length > 0 && <p>Bisnis: {bizByOwner.get(u.uid)!.map((b) => (<Link key={b.id} className="mr-2 underline" href={`/admin/bisnis?id=${b.id}`}>{b.name}</Link>))}</p>}
              {u.role === "owner" && u.status === "active" && <ActionButtons url={`/api/admin/users/${u.uid}`} actions={[{ label: "Tangguhkan", variant: "bahaya", method: "PATCH", body: { status: "suspended" }, needsReason: true, reasonLabel: "Alasan penangguhan" }]} />}
              {u.status === "suspended" && <ActionButtons url={`/api/admin/users/${u.uid}`} actions={[{ label: "Aktifkan kembali", variant: "utama", method: "PATCH", body: { status: "active" }, confirm: "Aktifkan kembali akun ini?" }]} />}
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
