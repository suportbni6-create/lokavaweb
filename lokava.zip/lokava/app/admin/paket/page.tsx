import { AdminCrud } from "@/components/admin/AdminCrud";

export const metadata = { title: "Paket langganan" };
export default function Page() {
  return <AdminCrud cfg={{ collection: "plans", title: "Paket langganan", text: "Harga dan batas diperiksa server. Perubahan berlaku untuk transaksi baru; transaksi lama memakai snapshot saat dibuat.", nameKey: "name", softDelete: true,
    defaults: { name: "", description: "", price: 0, durationDays: 30, maxBusinessPhotos: 3, maxProducts: 5, maxProductPhotos: 1, maxPromotions: 0, features: [], active: true, sortOrder: 0 },
    fields: [
      { key: "name", label: "Nama paket", type: "text", required: true }, { key: "description", label: "Deskripsi", type: "textarea" },
      { key: "price", label: "Harga (Rp)", type: "number", required: true, help: "0 = paket gratis." }, { key: "durationDays", label: "Durasi (hari)", type: "number", required: true, help: "0 = tidak berakhir." },
      { key: "maxBusinessPhotos", label: "Maks foto bisnis", type: "number", required: true }, { key: "maxProducts", label: "Maks produk", type: "number", required: true },
      { key: "maxProductPhotos", label: "Maks foto per produk", type: "number", required: true }, { key: "maxPromotions", label: "Maks promosi aktif", type: "number", required: true },
      { key: "features", label: "Fitur (pisahkan dengan koma)", type: "tags" }, { key: "sortOrder", label: "Urutan", type: "number", required: true }, { key: "active", label: "Aktif", type: "bool" } ],
    cols: [{ key: "price", label: "Harga", kind: "rupiah" }, { key: "durationDays", label: "Hari" }, { key: "maxProducts", label: "Produk" }, { key: "maxBusinessPhotos", label: "Foto" }, { key: "active", label: "Aktif", kind: "bool" }] }} />;
}
