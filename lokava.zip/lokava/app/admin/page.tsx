import { AggregateField } from "firebase-admin/firestore";
import { PageHeader } from "@/components/ui/misc";
import { db, ts } from "@/lib/firebase/admin";
import { formatAngka, formatRupiah } from "@/lib/utils/format";

export const metadata = { title: "Ringkasan admin" };

const count = async (q: FirebaseFirestore.Query) => { try { return (await q.count().get()).data().count; } catch { return 0; } };

export default async function Page() {
  const c = (n: string) => db().collection(n);
  const now = new Date(); const soon = new Date(now.getTime() + 7 * 86_400_000);
  const [bTotal, bPending, bActive, bSusp, products, users, txTotal, txReview, promoActive, promoSoon, plans] = await Promise.all([
    count(c("businesses")), count(c("businesses").where("verificationStatus", "==", "pending")), count(c("businesses").where("visible", "==", true)),
    count(c("businesses").where("verificationStatus", "==", "suspended")), count(c("products").where("visible", "==", true)), count(c("users")),
    count(c("transactions")), count(c("transactions").where("status", "in", ["proof_submitted", "under_review"])),
    count(c("promotions").where("status", "==", "active").where("expiresAt", ">", ts(now))),
    count(c("promotions").where("status", "==", "active").where("expiresAt", ">", ts(now)).where("expiresAt", "<", ts(soon))),
    c("plans").orderBy("sortOrder").get().catch(() => null),
  ]);
  let revenue = 0;
  try { revenue = (await c("transactions").where("status", "==", "approved").aggregate({ total: AggregateField.sum("amount") }).get()).data().total ?? 0; } catch { /* belum ada data */ }
  const usage = plans ? await Promise.all(plans.docs.map(async (p) => ({ name: p.data().name as string, n: await count(c("subscriptions").where("planId", "==", p.id).where("status", "==", "active")) }))) : [];
  const months = await Promise.all([5, 4, 3, 2, 1, 0].map(async (i) => {
    const start = new Date(now.getFullYear(), now.getMonth() - i, 1); const end = new Date(now.getFullYear(), now.getMonth() - i + 1, 1);
    return { label: new Intl.DateTimeFormat("id-ID", { month: "short", year: "2-digit" }).format(start), n: await count(c("users").where("createdAt", ">=", ts(start)).where("createdAt", "<", ts(end))) };
  }));
  const max = Math.max(1, ...months.map((m) => m.n));
  const cards: [string, string, string?][] = [["Total bisnis", formatAngka(bTotal)], ["Menunggu verifikasi", formatAngka(bPending), "/admin/bisnis?status=pending"], ["Bisnis aktif (tampil)", formatAngka(bActive)], ["Bisnis ditangguhkan", formatAngka(bSusp), "/admin/bisnis?status=suspended"], ["Produk tampil", formatAngka(products)], ["Total pengguna", formatAngka(users), "/admin/pengguna"], ["Total transaksi", formatAngka(txTotal)], ["Transaksi perlu diperiksa", formatAngka(txReview), "/admin/transaksi?status=proof_submitted"], ["Promosi aktif", formatAngka(promoActive)], ["Promosi berakhir ≤7 hari", formatAngka(promoSoon)], ["Pendapatan disetujui", formatRupiah(revenue)]];
  return (
    <>
      <PageHeader title="Ringkasan" text="Semua angka dihitung dari database." />
      <dl className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {cards.map(([k, v, h]) => (<div key={k} className="kartu p-4">{h ? <a href={h} className="block"><dt className="text-xs text-samudra-600">{k}</dt><dd className="judul text-2xl font-bold">{v}</dd></a> : <><dt className="text-xs text-samudra-600">{k}</dt><dd className="judul text-2xl font-bold">{v}</dd></>}</div>))}
      </dl>
      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <section className="kartu p-5"><h2 className="judul text-lg font-semibold">Pendaftaran pengguna (6 bulan)</h2>
          <ul className="mt-3 flex h-32 items-end gap-3">{months.map((m) => (<li key={m.label} className="flex flex-1 flex-col items-center gap-1"><span className="text-xs font-semibold">{m.n}</span><span className="w-full rounded-t bg-toska-400" style={{ height: `${Math.max((m.n / max) * 100, 4)}%` }} /><span className="text-[11px] text-samudra-600">{m.label}</span></li>))}</ul></section>
        <section className="kartu p-5"><h2 className="judul text-lg font-semibold">Pemakaian paket (langganan aktif)</h2>
          <ul className="mt-3 space-y-2 text-sm">{usage.length === 0 && <li className="text-samudra-600">Belum ada paket.</li>}{usage.map((u) => (<li key={u.name} className="flex justify-between"><span>{u.name}</span><b>{u.n}</b></li>))}</ul></section>
      </div>
    </>
  );
}
