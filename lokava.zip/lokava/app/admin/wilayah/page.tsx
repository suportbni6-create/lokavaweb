import { AdminCrud } from "@/components/admin/AdminCrud";

export const metadata = { title: "Wilayah" };
export default function Page() {
  return <AdminCrud cfg={{ collection: "regions", title: "Wilayah", text: "Tambah desa, kecamatan, atau wilayah baru tanpa mengubah kode.", nameKey: "name",
    defaults: { name: "", district: "", active: true, sortOrder: 0 },
    fields: [{ key: "name", label: "Nama wilayah / desa", type: "text", required: true }, { key: "district", label: "Kecamatan", type: "text", required: true }, { key: "sortOrder", label: "Urutan", type: "number", required: true }, { key: "active", label: "Tampil", type: "bool" }],
    cols: [{ key: "district", label: "Kecamatan" }, { key: "active", label: "Tampil", kind: "bool" }] }} />;
}
