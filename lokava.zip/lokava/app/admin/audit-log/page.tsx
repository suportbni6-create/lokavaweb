import { Badge, EmptyState, PageHeader } from "@/components/ui/misc";
import { db, docPlain } from "@/lib/firebase/admin";
import { formatTanggal } from "@/lib/utils/format";
import type { AuditLogDoc } from "@/types";

export const metadata = { title: "Audit log" };

export default async function Page() {
  const logs = (await db().collection("auditLogs").orderBy("timestamp", "desc").limit(100).get().catch(() => null))?.docs.map((d) => docPlain<AuditLogDoc>(d)!) ?? [];
  return (
    <>
      <PageHeader title="Audit log" text="100 catatan terbaru. Catatan tidak dapat diubah dari aplikasi dan tidak memuat rahasia." />
      {logs.length === 0 ? <EmptyState title="Belum ada catatan" /> : (
        <ul className="space-y-2">{logs.map((l) => (<li key={l.id} className="kartu p-3 text-sm"><div className="flex flex-wrap items-center justify-between gap-2"><span><b>{l.action}</b> · {l.targetType}/<span className="font-mono text-xs">{l.targetId}</span></span><span className="flex items-center gap-2"><Badge tone={l.result === "success" ? "hijau" : "merah"}>{l.result === "success" ? "Berhasil" : "Gagal"}</Badge><time className="text-xs text-samudra-600" dateTime={l.timestamp}>{formatTanggal(l.timestamp, true)}</time></span></div><p className="mt-1 text-samudra-800">{l.summary}</p><p className="text-xs text-samudra-500">Aktor: {l.actorId}</p></li>))}</ul>
      )}
    </>
  );
}
