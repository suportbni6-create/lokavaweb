import { AdminCrud } from "@/components/admin/AdminCrud";

export const metadata = { title: "Kategori" };
export default function Page() {
  return <AdminCrud cfg={{ collection: "categories", title: "Kategori", text: "Kategori dinamis: tambah tanpa mengubah kode.", nameKey: "name", softDelete: true,
    defaults: { name: "", description: "", icon: "📍", group: "wisata", image: null, active: true, sortOrder: 0 },
    fields: [
      { key: "name", label: "Nama", type: "text", required: true }, { key: "icon", label: "Ikon (emoji)", type: "text" },
      { key: "group", label: "Kelompok halaman", type: "select", options: [["wisata", "Wisata"], ["kuliner", "Kuliner"], ["penginapan", "Penginapan"], ["umkm", "UMKM / produk"], ["jasa", "Jasa"]] },
      { key: "description", label: "Deskripsi", type: "textarea" }, { key: "image", label: "Gambar kategori", type: "image" },
      { key: "sortOrder", label: "Urutan tampil", type: "number", required: true }, { key: "active", label: "Aktif", type: "bool" } ],
    cols: [{ key: "icon", label: "Ikon" }, { key: "group", label: "Kelompok" }, { key: "sortOrder", label: "Urutan" }, { key: "active", label: "Aktif", kind: "bool" }] }} />;
}
