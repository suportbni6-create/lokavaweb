import { AdminCrud } from "@/components/admin/AdminCrud";
import { ActionButtons } from "@/components/admin/ReasonButtons";
import { Badge } from "@/components/ui/misc";
import { db, docPlain } from "@/lib/firebase/admin";
import { PROMO_STATUS } from "@/lib/labels";
import { formatRupiah, formatTanggal } from "@/lib/utils/format";
import { PROMOTION_KIND_LABEL, type PromotionDoc } from "@/types";

export const metadata = { title: "Promosi" };

export default async function Page() {
  const promos = (await db().collection("promotions").orderBy("createdAt", "desc").limit(40).get().catch(() => null))?.docs.map((d) => docPlain<PromotionDoc>(d)!) ?? [];
  return (
    <div className="space-y-10">
      <AdminCrud cfg={{ collection: "promotionTypes", title: "Jenis promosi", text: "Harga dasar berlaku untuk jumlah hari dasar; harga durasi lain dihitung proporsional oleh server.", nameKey: "name", softDelete: true,
        defaults: { kind: "product", name: "", description: "", basePrice: 0, baseDays: 7, durations: [7, 14, 21, 30], slotLimit: 0, requirements: {}, active: true },
        fields: [
          { key: "kind", label: "Jenis", type: "select", options: Object.entries(PROMOTION_KIND_LABEL) as [string, string][] }, { key: "name", label: "Nama", type: "text", required: true }, { key: "description", label: "Deskripsi", type: "textarea" },
          { key: "basePrice", label: "Harga dasar (Rp)", type: "number", required: true }, { key: "baseDays", label: "Hari untuk harga dasar", type: "number", required: true },
          { key: "durations", label: "Durasi tersedia (hari, pisahkan koma)", type: "numbers" }, { key: "slotLimit", label: "Batas slot aktif (0 = tanpa batas)", type: "number", required: true }, { key: "active", label: "Aktif", type: "bool" } ],
        cols: [{ key: "kind", label: "Jenis" }, { key: "basePrice", label: "Harga", kind: "rupiah" }, { key: "durations", label: "Durasi", kind: "list" }, { key: "slotLimit", label: "Slot" }, { key: "active", label: "Aktif", kind: "bool" }] }} />
      <section><h2 className="judul mb-3 text-xl font-semibold">Pengajuan dan promosi terbaru</h2>
        {promos.length === 0 ? <p className="text-sm text-samudra-600">Belum ada promosi.</p> : <ul className="space-y-2">{promos.map((p) => { const [l, t] = PROMO_STATUS[p.status]!; return (
          <li key={p.id} className="kartu flex flex-wrap items-center justify-between gap-3 p-3 text-sm"><div><b>{PROMOTION_KIND_LABEL[p.kind]}</b> · {p.durationDays} hari · {formatRupiah(p.amount)}<br /><span className="text-samudra-600">Bisnis {p.businessId}{p.expiresAt ? ` · berlaku sampai ${formatTanggal(p.expiresAt, true)}` : ""}</span></div><div className="flex items-center gap-2"><Badge tone={t}>{l}</Badge>{p.status === "active" && <ActionButtons url={`/api/admin/promotions/${p.id}`} actions={[{ label: "Nonaktifkan", variant: "bahaya", method: "PATCH", body: {}, confirm: "Nonaktifkan promosi ini sekarang?" }]} />}</div></li>); })}</ul>}
      </section>
    </div>
  );
}
