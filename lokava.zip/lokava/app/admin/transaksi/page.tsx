import Link from "next/link";
import { ActionButtons } from "@/components/admin/ReasonButtons";
import { Badge, EmptyState, PageHeader } from "@/components/ui/misc";
import { db, docPlain } from "@/lib/firebase/admin";
import { TX_TONE } from "@/lib/labels";
import { formatRupiah, formatTanggal } from "@/lib/utils/format";
import { TRANSACTION_STATUS_LABEL, type TransactionDoc, type TransactionStatus } from "@/types";

export const metadata = { title: "Transaksi" };
const FILTERS: TransactionStatus[] = ["proof_submitted", "under_review", "pending_payment", "approved", "rejected", "expired"];

export default async function Page({ searchParams }: { searchParams: Promise<{ status?: string; q?: string; id?: string }> }) {
  const sp = await searchParams;
  const status = (FILTERS as string[]).includes(sp.status ?? "") ? (sp.status as TransactionStatus) : "proof_submitted";
  let list: TransactionDoc[];
  if (sp.id) { const d = docPlain<TransactionDoc>(await db().collection("transactions").doc(sp.id).get()); list = d ? [d] : []; }
  else if (sp.q) list = (await db().collection("transactions").where("transactionNumber", "==", sp.q.trim().toUpperCase()).limit(5).get()).docs.map((d) => docPlain<TransactionDoc>(d)!);
  else list = (await db().collection("transactions").where("status", "==", status).orderBy("createdAt", "desc").limit(50).get()).docs.map((d) => docPlain<TransactionDoc>(d)!);
  return (
    <>
      <PageHeader title="Transaksi" text="Cocokkan nominal dengan mutasi rekening atau QR yang sebenarnya. Tangkapan layar bukan bukti final uang diterima." />
      <form className="mb-3 flex max-w-md gap-2"><label htmlFor="q" className="sr-only">Nomor transaksi</label><input id="q" name="q" defaultValue={sp.q} placeholder="Cari nomor, mis. LKV-20261012-AB12CD" className="input" /><button className="rounded-xl bg-samudra-700 px-4 text-sm font-semibold text-white">Cari</button></form>
      <nav className="mb-4 flex flex-wrap gap-2">{FILTERS.map((f) => <Link key={f} href={`/admin/transaksi?status=${f}`} className={`rounded-full px-4 py-2 text-sm font-semibold ${f === status && !sp.q && !sp.id ? "bg-samudra-700 text-white" : "border border-samudra-200 bg-white"}`}>{TRANSACTION_STATUS_LABEL[f]}</Link>)}</nav>
      {list.length === 0 ? <EmptyState title="Tidak ada transaksi" /> : (
        <ul className="space-y-3">
          {list.map((t) => (
            <li key={t.id} className="kartu space-y-3 p-4">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div><p className="font-mono text-xs text-samudra-600">{t.transactionNumber}</p><h2 className="font-semibold">{t.title}</h2><p className="text-sm text-samudra-700">{t.ownerName} · {t.businessName}</p></div>
                <div className="text-right"><p className="text-xl font-bold">{formatRupiah(t.amount)}</p><Badge tone={TX_TONE[t.status]}>{TRANSACTION_STATUS_LABEL[t.status]}</Badge></div>
              </div>
              <p className="text-xs text-samudra-600">Dibuat {formatTanggal(t.createdAt, true)}{t.approvedBy && ` · diproses oleh ${t.approvedBy}`}{t.approvedAt && ` pada ${formatTanggal(t.approvedAt, true)}`} · {t.paymentMethodSnapshot?.name ?? "-"}</p>
              {t.proofNote && <p className="text-sm">Catatan pemilik: {t.proofNote}</p>}
              {t.rejectionReason && <p className="text-sm text-red-800">Alasan penolakan: {t.rejectionReason}</p>}
              {t.proof && <a className="inline-block text-sm font-semibold text-toska-700 underline" target="_blank" rel="noopener noreferrer" href={`/api/proof/${t.id}`}>Buka bukti pembayaran (tautan sementara)</a>}
              <details className="text-xs text-samudra-700"><summary className="cursor-pointer font-semibold">Riwayat status</summary><ol className="mt-1 list-decimal pl-5">{t.statusHistory.map((h, i) => <li key={i}>{TRANSACTION_STATUS_LABEL[h.status]} · {formatTanggal(h.at, true)} · {h.by}{h.note ? ` · ${h.note}` : ""}</li>)}</ol></details>
              {["proof_submitted", "under_review"].includes(t.status) && <ActionButtons url={`/api/admin/transactions/${t.id}`} actions={[{ label: "Setujui", variant: "utama", method: "POST", body: { decision: "approve" }, confirm: `Pastikan ${formatRupiah(t.amount)} sudah masuk ke rekening/QR Anda. Setujui?` }, { label: "Tolak", variant: "bahaya", method: "POST", body: { decision: "reject" }, needsReason: true }]} />}
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
