import { SettingsForm } from "@/components/admin/SettingsForm";
import { PageHeader } from "@/components/ui/misc";
import { getSettings } from "@/lib/data/public";

export const metadata = { title: "Pengaturan aplikasi" };

export default async function Page() {
  return (<><PageHeader title="Pengaturan aplikasi" text="Rahasia server (kunci Firebase, Cloudinary, token) hanya diatur lewat environment variables, bukan di sini." /><SettingsForm initial={await getSettings()} /></>);
}
