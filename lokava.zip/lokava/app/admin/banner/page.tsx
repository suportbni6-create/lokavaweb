import { AdminCrud } from "@/components/admin/AdminCrud";

export const metadata = { title: "Banner" };
export default function Page() {
  return <AdminCrud cfg={{ collection: "banners", title: "Banner", text: "Banner berbayar dibuat otomatis saat pembayaran disetujui dan berhenti tampil setelah masa berlaku habis.", nameKey: "title",
    defaults: { title: "", image: null, targetUrl: "/", startsAt: null, expiresAt: null, active: true, sortOrder: 0 },
    fields: [
      { key: "title", label: "Judul", type: "text", required: true }, { key: "image", label: "Gambar", type: "image" }, { key: "targetUrl", label: "Tautan tujuan", type: "text", required: true, help: "Contoh: /bisnis/nama-usaha atau https://…" },
      { key: "startsAt", label: "Mulai", type: "datetime" }, { key: "expiresAt", label: "Berakhir", type: "datetime" }, { key: "sortOrder", label: "Urutan", type: "number", required: true }, { key: "active", label: "Aktif", type: "bool" } ],
    cols: [{ key: "image", label: "Gambar", kind: "image" }, { key: "expiresAt", label: "Berakhir", kind: "date" }, { key: "active", label: "Aktif", kind: "bool" }] }} />;
}
