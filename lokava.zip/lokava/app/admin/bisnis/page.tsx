import Link from "next/link";
import { ActionButtons } from "@/components/admin/ReasonButtons";
import { Badge, EmptyState, PageHeader } from "@/components/ui/misc";
import { assessBusiness } from "@/lib/admin/assess";
import { db, docPlain } from "@/lib/firebase/admin";
import { STATUS_LABEL } from "@/lib/labels";
import { formatTanggal } from "@/lib/utils/format";
import type { BusinessDoc } from "@/types";

export const metadata = { title: "Manajemen bisnis" };
const FILTERS = ["pending", "needs_correction", "approved", "rejected", "suspended", "draft"];

export default async function Page({ searchParams }: { searchParams: Promise<{ status?: string; id?: string }> }) {
  const sp = await searchParams;
  const status = FILTERS.includes(sp.status ?? "") ? sp.status! : "pending";
  let list: BusinessDoc[];
  if (sp.id) { const d = docPlain<BusinessDoc>(await db().collection("businesses").doc(sp.id).get()); list = d ? [d] : []; }
  else list = (await db().collection("businesses").where("verificationStatus", "==", status).orderBy("createdAt", "desc").limit(50).get()).docs.map((d) => docPlain<BusinessDoc>(d)!);
  return (
    <>
      <PageHeader title="Manajemen bisnis" text="Persetujuan didasarkan pada pemeriksaan manusia. Kelengkapan formulir tidak membuktikan identitas atau legalitas usaha." />
      <nav className="mb-4 flex flex-wrap gap-2">{FILTERS.map((f) => <Link key={f} href={`/admin/bisnis?status=${f}`} className={`rounded-full px-4 py-2 text-sm font-semibold ${f === status && !sp.id ? "bg-samudra-700 text-white" : "border border-samudra-200 bg-white"}`}>{STATUS_LABEL[f]![0]}</Link>)}</nav>
      {list.length === 0 ? <EmptyState title="Tidak ada bisnis pada status ini" /> : (
        <ul className="space-y-3">
          {list.map((b) => {
            const a = assessBusiness(b); const [lab, tone] = STATUS_LABEL[b.verificationStatus]!;
            return (
              <li key={b.id} className="kartu space-y-3 p-4">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div><h2 className="judul text-lg font-semibold">{b.name}</h2><p className="text-sm text-samudra-700">{b.village}, {b.district}, {b.region} · diajukan {formatTanggal(b.createdAt)}</p><p className="font-mono text-xs text-samudra-500">{b.id}</p></div>
                  <div className="flex gap-1.5"><Badge tone={tone}>{lab}</Badge>{b.visible && <Badge tone="hijau">Tampil</Badge>}</div>
                </div>
                <p className="line-clamp-3 text-sm">{b.description}</p>
                <p className="text-sm">{a.complete ? "✅ Data wajib lengkap." : `⚠️ Belum lengkap: ${a.missing.join(", ")}.`}{a.flags.length > 0 && <span className="block text-amber-800">Perlu dicek manusia: {a.flags.join("; ")}</span>}</p>
                <p className="text-xs text-samudra-600">WhatsApp: {b.whatsapp ?? "-"} · Koordinat: {b.latitude ?? "-"}, {b.longitude ?? "-"} · <Link className="underline" href={`/bisnis/${b.slug}`}>Halaman publik</Link></p>
                {b.reviewNote && <p className="text-sm text-amber-900"><b>Catatan terakhir:</b> {b.reviewNote}</p>}
                <ActionButtons url={`/api/admin/businesses/${b.id}`} actions={
                  b.verificationStatus === "pending" ? [
                    { label: "Setujui", variant: "utama", method: "POST", body: { decision: "approve" }, confirm: "Setujui dan tampilkan bisnis ini?" },
                    { label: "Minta perbaikan", variant: "garis", method: "POST", body: { decision: "correction" }, needsReason: true, reasonLabel: "Apa yang perlu diperbaiki?" },
                    { label: "Tolak", variant: "bahaya", method: "POST", body: { decision: "reject" }, needsReason: true } ]
                  : b.verificationStatus === "approved" ? [
                    { label: b.publicationStatus === "published" ? "Sembunyikan" : "Tampilkan", method: "PATCH", body: { action: b.publicationStatus === "published" ? "unpublish" : "publish" } },
                    { label: "Tangguhkan", variant: "bahaya", method: "PATCH", body: { action: "suspend" }, needsReason: true } ]
                  : b.verificationStatus === "suspended" ? [{ label: "Aktifkan kembali", variant: "utama", method: "PATCH", body: { action: "reactivate" }, confirm: "Aktifkan kembali bisnis ini?" }] : [] } />
              </li>
            );
          })}
        </ul>
      )}
    </>
  );
}
