import { TelegramForm } from "@/components/admin/TelegramForm";
import { PageHeader } from "@/components/ui/misc";
import { requirePageUser } from "@/lib/auth/session";
import { serverEnv } from "@/lib/env";
import { db } from "@/lib/firebase/admin";
import { getTelegramSettings, isTokenConfigured } from "@/lib/telegram";

export const metadata = { title: "Telegram" };

export default async function Page() {
  const user = await requirePageUser({ admin: true });
  const [settings, token, me] = await Promise.all([getTelegramSettings(), isTokenConfigured(), db().collection("users").doc(user.uid).get()]);
  return (<><PageHeader title="Integrasi Telegram" text="Notifikasi pendaftaran dan pembayaran, serta tombol persetujuan lewat bot." /><TelegramForm initial={settings} tokenConfigured={token} webhookSecretConfigured={Boolean(serverEnv().TELEGRAM_WEBHOOK_SECRET)} canEdit={Boolean(me.data()?.superAdmin)} /></>);
}
