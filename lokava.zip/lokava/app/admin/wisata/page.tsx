import { AdminCrud } from "@/components/admin/AdminCrud";
import { db } from "@/lib/firebase/admin";

export const metadata = { title: "Destinasi wisata" };
export default async function Page() {
  const cats = (await db().collection("categories").where("group", "==", "wisata").get().catch(() => null))?.docs.map((d) => [d.id, d.data().name as string] as [string, string]) ?? [];
  return <AdminCrud cfg={{ collection: "destinations", title: "Destinasi wisata", text: "Isi hanya informasi yang terverifikasi dari pengelola. Jangan mengarang koordinat, harga, atau jam buka. Kosongkan jika belum diketahui.", nameKey: "name",
    defaults: { name: "", description: "", categoryIds: [], address: "", district: "", region: "", latitude: null, longitude: null, accessInfo: "", openingHours: "", ticketPrice: null, facilities: [], contact: "", directions: "", coverImage: null, gallery: [], verified: false, featured: false, active: true },
    fields: [
      { key: "name", label: "Nama", type: "text", required: true }, { key: "description", label: "Deskripsi", type: "textarea", required: true },
      { key: "categoryIds", label: "Kategori", type: "multiselect", options: cats }, { key: "address", label: "Alamat", type: "text" },
      { key: "district", label: "Kecamatan", type: "text", required: true }, { key: "region", label: "Wilayah", type: "text", required: true },
      { key: "latitude", label: "Latitude", type: "number" }, { key: "longitude", label: "Longitude", type: "number" },
      { key: "accessInfo", label: "Informasi akses", type: "textarea" }, { key: "directions", label: "Petunjuk lokasi", type: "textarea" }, { key: "openingHours", label: "Jam operasional", type: "text" },
      { key: "ticketPrice", label: "Harga tiket (Rp, 0 = gratis, kosong = tidak diketahui)", type: "number" }, { key: "facilities", label: "Fasilitas (pisahkan koma)", type: "tags" }, { key: "contact", label: "Kontak pengelola", type: "text" },
      { key: "coverImage", label: "Foto utama", type: "image" }, { key: "gallery", label: "Galeri", type: "images", max: 20 },
      { key: "verified", label: "Terverifikasi", type: "bool" }, { key: "featured", label: "Unggulan di beranda", type: "bool" }, { key: "active", label: "Tampil", type: "bool" } ],
    cols: [{ key: "district", label: "Kecamatan" }, { key: "coverImage", label: "Foto", kind: "image" }, { key: "verified", label: "Verif.", kind: "bool" }, { key: "active", label: "Tampil", kind: "bool" }] }} />;
}
