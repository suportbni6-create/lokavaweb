import { ActionButtons } from "@/components/admin/ReasonButtons";
import { Badge, EmptyState, PageHeader } from "@/components/ui/misc";
import { db, docPlain } from "@/lib/firebase/admin";
import { formatTanggal } from "@/lib/utils/format";
import type { DeletionRequestDoc } from "@/types";

export const metadata = { title: "Penghapusan akun" };
const TONE = { requested: "kuning", processing: "biru", completed: "hijau", failed: "merah" } as const;
const LABEL = { requested: "Diminta", processing: "Diproses", completed: "Selesai", failed: "Gagal sebagian" } as const;

export default async function Page() {
  const reqs = (await db().collection("deletionRequests").orderBy("requestedAt", "desc").limit(50).get().catch(() => null))?.docs.map((d) => docPlain<DeletionRequestDoc>(d)!) ?? [];
  return (
    <>
      <PageHeader title="Penghapusan akun" text="Konten publik disembunyikan seketika. Proses dilanjutkan otomatis oleh cron harian jika ada langkah yang gagal." />
      {reqs.length === 0 ? <EmptyState title="Belum ada permintaan" /> : (
        <ul className="space-y-2">{reqs.map((r) => (
          <li key={r.id} className="kartu space-y-2 p-3 text-sm">
            <div className="flex flex-wrap items-center justify-between gap-2"><span className="font-mono text-xs">{r.userId}</span><Badge tone={TONE[r.status]}>{LABEL[r.status]}</Badge></div>
            <p>Diminta {formatTanggal(r.requestedAt, true)}{r.completedAt && ` · selesai ${formatTanggal(r.completedAt, true)}`}</p>
            <p className="text-xs text-samudra-700">Langkah: {Object.entries(r.steps).map(([k, v]) => `${k}: ${v}`).join(" · ")}</p>
            {r.failureReason && <p className="text-xs text-red-800">Kendala: {r.failureReason}</p>}
            <p className="text-xs text-samudra-600">{r.retentionNotes}</p>
            {r.status !== "completed" && <ActionButtons url={`/api/admin/deletion/${r.id}`} actions={[{ label: "Lanjutkan proses", variant: "utama", method: "POST", body: {}, confirm: "Lanjutkan penghapusan data akun ini?" }]} />}
          </li>))}</ul>
      )}
    </>
  );
}
