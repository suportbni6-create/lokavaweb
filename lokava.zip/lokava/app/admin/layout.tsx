import { PanelNav } from "@/components/dashboard/PanelNav";
import { requirePageUser } from "@/lib/auth/session";

export const dynamic = "force-dynamic";
export const metadata = { robots: { index: false } };

const ITEMS = [
  ["/admin", "Ringkasan"], ["/admin/bisnis", "Bisnis"], ["/admin/transaksi", "Transaksi"], ["/admin/promosi", "Promosi"], ["/admin/paket", "Paket"],
  ["/admin/pembayaran", "Pembayaran"], ["/admin/kategori", "Kategori"], ["/admin/wisata", "Wisata"], ["/admin/wilayah", "Wilayah"], ["/admin/banner", "Banner"],
  ["/admin/pengguna", "Pengguna"], ["/admin/telegram", "Telegram"], ["/admin/pengaturan", "Pengaturan"], ["/admin/audit-log", "Audit log"], ["/admin/penghapusan-akun", "Hapus akun"],
] as [string, string][];

export default async function Layout({ children }: { children: React.ReactNode }) {
  const user = await requirePageUser({ admin: true });
  return <PanelNav title={`Admin: ${user.displayName}`} items={ITEMS}>{children}</PanelNav>;
}
