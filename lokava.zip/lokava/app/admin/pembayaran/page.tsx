import { AdminCrud } from "@/components/admin/AdminCrud";

export const metadata = { title: "Metode pembayaran" };
export default function Page() {
  return <AdminCrud cfg={{ collection: "paymentMethods", title: "Metode pembayaran", text: "Masukkan hanya metode yang sah. Gambar QR biasa bukan otomatis QRIS resmi. Hanya data yang perlu untuk membayar ditampilkan kepada pemilik usaha.", nameKey: "name", softDelete: true,
    defaults: { name: "", provider: "", accountName: "", accountNumber: "", instructions: "", qrImage: null, active: true, sortOrder: 0 },
    fields: [
      { key: "name", label: "Nama metode", type: "text", required: true }, { key: "provider", label: "Bank / penyedia", type: "text" }, { key: "accountName", label: "Nama pemilik rekening", type: "text", required: true },
      { key: "accountNumber", label: "Nomor rekening", type: "text" }, { key: "instructions", label: "Instruksi pembayaran", type: "textarea" }, { key: "qrImage", label: "Gambar QR", type: "image" },
      { key: "sortOrder", label: "Urutan", type: "number", required: true }, { key: "active", label: "Aktif", type: "bool" } ],
    cols: [{ key: "provider", label: "Penyedia" }, { key: "accountName", label: "Atas nama" }, { key: "qrImage", label: "QR", kind: "image" }, { key: "active", label: "Aktif", kind: "bool" }] }} />;
}
