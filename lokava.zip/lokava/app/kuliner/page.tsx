import { Directory } from "@/components/public/Directory";
import { PageHeader } from "@/components/ui/misc";

export const metadata = { title: "Kuliner", description: "Restoran, warung makan, seafood, kedai kopi, dan jajanan khas Sukabumi Selatan." };

export default async function Page({ searchParams }: { searchParams: Promise<{ kategori?: string; district?: string; cursor?: string }> }) {
  const sp = await searchParams;
  return (
    <div className="wadah py-8">
      <PageHeader title="Kuliner" text="Restoran, warung makan, seafood, kedai kopi, dan jajanan khas Sukabumi Selatan." />
      <Directory basePath="/kuliner" group="kuliner" sp={sp} />
    </div>
  );
}
