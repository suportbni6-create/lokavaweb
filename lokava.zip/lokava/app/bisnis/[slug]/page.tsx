import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Gallery } from "@/components/cards/Gallery";
import { Hours } from "@/components/cards/Hours";
import { ProductCard } from "@/components/cards";
import { ShareButton } from "@/components/cards/ShareButton";
import { WaButton } from "@/components/cards/WaButton";
import { Badge, EmptyState } from "@/components/ui/misc";
import { getActivePromotions, getBusinessBySlug, getBusinessProducts, getCategories } from "@/lib/data/public";
import { appUrl } from "@/lib/env";
import { formatRupiah } from "@/lib/utils/format";
import MapLazy from "@/components/public/MapLazy";

export const revalidate = 60;
type P = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: P): Promise<Metadata> {
  const b = await getBusinessBySlug((await params).slug);
  if (!b) return { title: "Bisnis tidak ditemukan" };
  const desc = b.description.slice(0, 155);
  return { title: b.name, description: desc, alternates: { canonical: `/bisnis/${b.slug}` }, openGraph: { title: b.name, description: desc, images: b.coverImage ? [b.coverImage.url] : undefined, type: "website" } };
}

export default async function Page({ params }: P) {
  const b = await getBusinessBySlug((await params).slug);
  if (!b) notFound();
  const [products, cats, promos] = await Promise.all([getBusinessProducts(b.id), getCategories(), getActivePromotions()]);
  const mine = promos.filter((p) => p.business.id === b.id);
  const catNames = cats.filter((c) => b.categoryIds.includes(c.id)).map((c) => c.name);
  const hasCoord = b.latitude !== null && b.longitude !== null;
  const isMenu = products.some((p) => p.kind === "menu");
  const ld = {
    "@context": "https://schema.org", "@type": "LocalBusiness", name: b.name, description: b.description, url: `${appUrl()}/bisnis/${b.slug}`,
    image: b.coverImage?.url, address: { "@type": "PostalAddress", streetAddress: b.address, addressLocality: b.district, addressRegion: b.region, addressCountry: "ID" },
    ...(hasCoord ? { geo: { "@type": "GeoCoordinates", latitude: b.latitude, longitude: b.longitude } } : {}),
  };

  return (
    <div className="wadah py-8">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ld).replace(/</g, "\\u003c") }} />
      <div className="grid gap-8 lg:grid-cols-[1.4fr_1fr]">
        <div className="space-y-6">
          <Gallery cover={b.coverImage} images={b.gallery} name={b.name} />
          <section>
            <h2 className="judul text-xl font-semibold">Tentang usaha</h2>
            <p className="mt-2 whitespace-pre-line text-samudra-800">{b.description}</p>
          </section>
          <section>
            <h2 className="judul text-xl font-semibold">{isMenu ? "Menu" : "Produk dan layanan"}</h2>
            {products.length === 0 ? <div className="mt-3"><EmptyState title="Belum ada produk" text="Pemilik belum menambahkan produk atau layanan." /></div> : isMenu ? (
              <ul className="mt-3 divide-y divide-samudra-100 kartu">
                {products.map((p) => (<li key={p.id} className="flex items-center justify-between gap-3 px-4 py-3"><div><p className="font-semibold">{p.name}</p>{p.description && <p className="line-clamp-1 text-sm text-samudra-600">{p.description}</p>}</div><p className="shrink-0 font-bold">{formatRupiah(p.price)}</p></li>))}
              </ul>
            ) : <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-3">{products.map((p) => <ProductCard key={p.id} p={p} />)}</div>}
          </section>
        </div>
        <aside className="space-y-4 lg:sticky lg:top-20 lg:self-start">
          <div className="kartu space-y-3 p-5">
            <div className="flex flex-wrap gap-1.5"><Badge tone="biru">Terverifikasi</Badge>{catNames.map((n) => <Badge key={n}>{n}</Badge>)}{mine.length > 0 && <Badge tone="kuning">Sedang dipromosikan</Badge>}</div>
            <h1 className="judul text-2xl font-semibold">{b.name}</h1>
            <p className="text-sm text-samudra-700">{b.address}, {b.village}, {b.district}, {b.region}</p>
            <div className="flex flex-wrap gap-2">
              {b.whatsapp ? (<><WaButton number={b.whatsapp} intent="umum" businessName={b.name} /><WaButton number={b.whatsapp} intent="harga" businessName={b.name} /><WaButton number={b.whatsapp} intent="ketersediaan" businessName={b.name} /></>) : <p className="text-sm text-samudra-600">Kontak WhatsApp tidak ditampilkan.</p>}
              <ShareButton title={b.name} path={`/bisnis/${b.slug}`} />
            </div>
          </div>
          <div className="kartu p-5"><h2 className="judul mb-2 text-lg font-semibold">Jam operasional</h2><Hours hours={b.openingHours} /></div>
          {hasCoord && <div className="kartu space-y-2 p-3"><MapLazy points={[{ id: b.id, kind: "bisnis", name: b.name, slug: b.slug, lat: b.latitude!, lng: b.longitude!, address: b.address }]} height={260} single /></div>}
        </aside>
      </div>
    </div>
  );
}
