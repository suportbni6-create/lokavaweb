import { Directory } from "@/components/public/Directory";
import { PageHeader } from "@/components/ui/misc";

export const metadata = { title: "Direktori bisnis", description: "Daftar usaha lokal terverifikasi di Ujunggenteng dan Sukabumi Selatan." };

export default async function Page({ searchParams }: { searchParams: Promise<{ kategori?: string; district?: string; cursor?: string }> }) {
  const sp = await searchParams;
  return (
    <div className="wadah py-8">
      <PageHeader title="Direktori bisnis" text="Usaha lokal yang sudah diperiksa admin LOKAVA." />
      <Directory basePath="/bisnis" sp={sp} />
    </div>
  );
}
