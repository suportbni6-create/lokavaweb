import { Directory } from "@/components/public/Directory";
import { PageHeader } from "@/components/ui/misc";

export const metadata = { title: "Penginapan", description: "Homestay, vila, hotel, dan guest house. Hubungi pengelola lewat WhatsApp untuk menanyakan ketersediaan." };

export default async function Page({ searchParams }: { searchParams: Promise<{ kategori?: string; district?: string; cursor?: string }> }) {
  const sp = await searchParams;
  return (
    <div className="wadah py-8">
      <PageHeader title="Penginapan" text="Homestay, vila, hotel, dan guest house. Hubungi pengelola lewat WhatsApp untuk menanyakan ketersediaan." />
      <Directory basePath="/penginapan" group="penginapan" sp={sp} />
    </div>
  );
}
