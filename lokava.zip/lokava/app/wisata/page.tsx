import { DestinationCard, Grid } from "@/components/cards";
import { LinkButton } from "@/components/ui/Button";
import { EmptyState, PageHeader } from "@/components/ui/misc";
import { listDestinations } from "@/lib/data/public";

export const metadata = { title: "Wisata", description: "Pantai, wisata bahari, pemandangan alam, dan air terjun di Ujunggenteng dan Sukabumi Selatan." };

export default async function Page({ searchParams }: { searchParams: Promise<{ cursor?: string }> }) {
  const { cursor } = await searchParams;
  const { items, nextCursor } = await listDestinations({ cursor: cursor ?? null, limit: 12 });
  return (
    <div className="wadah py-8">
      <PageHeader title="Wisata" text="Informasi destinasi berasal dari admin dan pengelola yang disetujui." />
      {items.length === 0 ? <EmptyState title="Belum ada destinasi" text="Destinasi akan tampil setelah ditambahkan admin LOKAVA." /> : <Grid>{items.map((d) => <DestinationCard key={d.id} d={d} />)}</Grid>}
      {nextCursor && <div className="mt-8 text-center"><LinkButton variant="garis" href={`/wisata?cursor=${encodeURIComponent(nextCursor)}`}>Muat lebih banyak</LinkButton></div>}
    </div>
  );
}
