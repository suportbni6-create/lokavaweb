import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Gallery } from "@/components/cards/Gallery";
import { ShareButton } from "@/components/cards/ShareButton";
import { Badge } from "@/components/ui/misc";
import { LinkButton } from "@/components/ui/Button";
import MapLazy from "@/components/public/MapLazy";
import { directionsUrl } from "@/components/public/MapView";
import { getDestinationBySlug } from "@/lib/data/public";
import { appUrl } from "@/lib/env";
import { formatRupiah } from "@/lib/utils/format";

export const revalidate = 60;
type P = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: P): Promise<Metadata> {
  const d = await getDestinationBySlug((await params).slug);
  if (!d) return { title: "Destinasi tidak ditemukan" };
  return { title: d.name, description: d.description.slice(0, 155), alternates: { canonical: `/wisata/${d.slug}` }, openGraph: { title: d.name, images: d.coverImage ? [d.coverImage.url] : undefined } };
}

export default async function Page({ params }: P) {
  const d = await getDestinationBySlug((await params).slug);
  if (!d) notFound();
  const has = d.latitude !== null && d.longitude !== null;
  const info: [string, string][] = [["Alamat / wilayah", [d.address, d.district, d.region].filter(Boolean).join(", ")], ["Akses", d.accessInfo], ["Jam operasional", d.openingHours], ["Harga tiket", d.ticketPrice === null ? "" : d.ticketPrice === 0 ? "Gratis" : formatRupiah(d.ticketPrice)], ["Kontak pengelola", d.contact], ["Petunjuk lokasi", d.directions]];
  const ld = { "@context": "https://schema.org", "@type": "TouristAttraction", name: d.name, description: d.description, url: `${appUrl()}/wisata/${d.slug}`, image: d.coverImage?.url, ...(has ? { geo: { "@type": "GeoCoordinates", latitude: d.latitude, longitude: d.longitude } } : {}) };
  return (
    <div className="wadah py-8">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ld).replace(/</g, "\\u003c") }} />
      <div className="grid gap-8 lg:grid-cols-[1.4fr_1fr]">
        <div className="space-y-6">
          <Gallery cover={d.coverImage} images={d.gallery} name={d.name} />
          <section><h2 className="judul text-xl font-semibold">Tentang destinasi</h2><p className="mt-2 whitespace-pre-line">{d.description}</p></section>
          {d.facilities.length > 0 && <section><h2 className="judul text-xl font-semibold">Fasilitas</h2><ul className="mt-2 flex flex-wrap gap-2">{d.facilities.map((f) => <li key={f}><Badge>{f}</Badge></li>)}</ul></section>}
        </div>
        <aside className="space-y-4 lg:sticky lg:top-20 lg:self-start">
          <div className="kartu space-y-3 p-5">
            {d.verified && <Badge tone="biru">Terverifikasi</Badge>}
            <h1 className="judul text-2xl font-semibold">{d.name}</h1>
            <dl className="space-y-2 text-sm">{info.filter(([, v]) => v).map(([k, v]) => (<div key={k}><dt className="font-semibold text-samudra-800">{k}</dt><dd className="text-samudra-700">{v}</dd></div>))}</dl>
            <div className="flex flex-wrap gap-2">{has && <LinkButton external href={directionsUrl(d.latitude!, d.longitude!)} variant="sekunder">Petunjuk arah</LinkButton>}<ShareButton title={d.name} path={`/wisata/${d.slug}`} /></div>
          </div>
          {has && <div className="kartu p-3"><MapLazy points={[{ id: d.id, kind: "wisata", name: d.name, slug: d.slug, lat: d.latitude!, lng: d.longitude!, address: d.address }]} height={260} single /></div>}
        </aside>
      </div>
    </div>
  );
}
