import { LinkButton } from "@/components/ui/Button";

export const metadata = { title: "Sedang offline" };

export default function Offline() {
  return (
    <div className="wadah py-24 text-center">
      <h1 className="judul text-3xl font-semibold">Kamu sedang offline</h1>
      <p className="mx-auto mt-3 max-w-md text-samudra-700">LOKAVA memerlukan internet untuk menampilkan data terbaru. Sambungkan kembali, lalu coba lagi.</p>
      <div className="mt-6"><LinkButton href="/">Coba lagi</LinkButton></div>
    </div>
  );
}
