import { LinkButton } from "@/components/ui/Button";
import { safe } from "@/lib/data/public";
import { db, docPlain } from "@/lib/firebase/admin";
import { formatRupiah } from "@/lib/utils/format";
import type { PlanDoc } from "@/types";

export const revalidate = 120;
export const metadata = { title: "Daftarkan bisnis", description: "Daftarkan usaha Anda di LOKAVA dan jangkau wisatawan Sukabumi Selatan." };

export default async function Page() {
  const plans = await safe(async () => (await db().collection("plans").where("active", "==", true).orderBy("sortOrder").get()).docs.map((d) => docPlain<PlanDoc>(d)!), [] as PlanDoc[]);
  return (
    <div className="wadah max-w-4xl py-10">
      <h1 className="judul text-3xl font-semibold sm:text-4xl">Daftarkan bisnismu di LOKAVA</h1>
      <p className="mt-3 max-w-2xl text-samudra-800">Wisatawan menemukan usahamu dan menghubungi langsung lewat WhatsApp. Pendaftaran gratis. Tim LOKAVA memeriksa data sebelum usahamu tampil.</p>
      <ol className="mt-6 grid gap-3 sm:grid-cols-4">
        {["Buat akun", "Isi data usaha", "Diperiksa admin", "Tampil di LOKAVA"].map((t, i) => (<li key={t} className="kartu p-4"><p className="text-sm text-samudra-600">Langkah {i + 1}</p><p className="font-semibold">{t}</p></li>))}
      </ol>
      <div className="mt-6 flex gap-3"><LinkButton href="/register">Buat akun pemilik</LinkButton><LinkButton href="/login" variant="garis">Sudah punya akun</LinkButton></div>
      {plans.length > 0 && (
        <section className="mt-10"><h2 className="judul text-2xl font-semibold">Paket</h2>
          <div className="mt-4 grid gap-4 sm:grid-cols-3">
            {plans.map((p) => (<div key={p.id} className="kartu p-5"><h3 className="font-bold">{p.name}</h3><p className="text-2xl font-bold text-samudra-800">{p.price === 0 ? "Gratis" : formatRupiah(p.price)}{p.durationDays > 0 && <span className="text-sm font-normal text-samudra-600"> / {p.durationDays} hari</span>}</p><ul className="mt-3 space-y-1 text-sm text-samudra-800"><li>{p.maxBusinessPhotos} foto bisnis</li><li>{p.maxProducts} produk</li><li>{p.maxProductPhotos} foto per produk</li>{p.features.map((f) => <li key={f}>{f}</li>)}</ul></div>))}
          </div>
        </section>
      )}
    </div>
  );
}
