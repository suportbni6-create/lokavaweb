import { Suspense } from "react";
import { RegisterForm } from "@/components/forms/AuthForms";

export const metadata = { title: "Daftar", robots: { index: false } };

export default function Page() {
  return <Suspense><RegisterForm /></Suspense>;
}
