import { SubscriptionPicker } from "@/components/dashboard/PayFlow";
import { PageHeader, Badge } from "@/components/ui/misc";
import { requirePageUser } from "@/lib/auth/session";
import { getEffectivePlan } from "@/lib/data/business-core";
import { getOwnerBusinesses, getOwnerSubscriptions, getPurchasables } from "@/lib/data/owner";
import { formatTanggal } from "@/lib/utils/format";

export const metadata = { title: "Langganan" };

export default async function Page() {
  const user = await requirePageUser();
  const [businesses, ref, subs] = await Promise.all([getOwnerBusinesses(user.uid), getPurchasables(), getOwnerSubscriptions(user.uid)]);
  const current: Record<string, string> = {};
  for (const b of businesses) current[b.id] = (await getEffectivePlan(b.id)).plan.id;
  return (
    <>
      <PageHeader title="Langganan" text="Pilih paket sesuai kebutuhan usaha Anda." />
      <SubscriptionPicker businesses={businesses} plans={ref.plans} methods={ref.paymentMethods} currentPlanId={current} />
      <section className="mt-10"><h2 className="judul mb-3 text-xl font-semibold">Riwayat langganan</h2>
        {subs.length === 0 ? <p className="text-sm text-samudra-600">Belum ada riwayat.</p> : (
          <ul className="space-y-2">{subs.map((s) => (<li key={s.id} className="kartu flex flex-wrap items-center justify-between gap-2 p-3 text-sm"><span><b>{s.planSnapshot.name}</b> · {businesses.find((b) => b.id === s.businessId)?.name}</span><span>{formatTanggal(s.startsAt)} – {s.expiresAt ? formatTanggal(s.expiresAt) : "tanpa batas"}</span><Badge tone={s.status === "active" ? "hijau" : "netral"}>{s.status === "active" ? "Aktif" : s.status === "expired" ? "Berakhir" : "Diganti"}</Badge></li>))}</ul>
        )}
      </section>
    </>
  );
}
