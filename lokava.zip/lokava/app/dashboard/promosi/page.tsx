import { PromotionPicker } from "@/components/dashboard/PayFlow";
import { Badge, PageHeader } from "@/components/ui/misc";
import { requirePageUser } from "@/lib/auth/session";
import { db, docPlain } from "@/lib/firebase/admin";
import { getOwnerBusinesses, getOwnerPromotions, getPurchasables } from "@/lib/data/owner";
import { PROMO_STATUS } from "@/lib/labels";
import { formatRupiah, formatTanggal } from "@/lib/utils/format";
import { PROMOTION_KIND_LABEL, type ProductDoc } from "@/types";

export const metadata = { title: "Promosi" };

export default async function Page() {
  const user = await requirePageUser();
  const [businesses, ref, promos, prodSnap] = await Promise.all([
    getOwnerBusinesses(user.uid), getPurchasables(), getOwnerPromotions(user.uid),
    db().collection("products").where("ownerId", "==", user.uid).limit(300).get(),
  ]);
  const products = prodSnap.docs.map((d) => docPlain<ProductDoc>(d)!).filter((p) => !p.deletedAt);
  return (
    <>
      <PageHeader title="Promosi" text="Tampilkan produk atau bisnis Anda di tempat yang lebih terlihat." />
      <div className="grid gap-6 lg:grid-cols-2">
        <PromotionPicker businesses={businesses} types={ref.promotionTypes} methods={ref.paymentMethods} products={products} categories={ref.categories} />
        <section><h2 className="judul mb-3 text-xl font-semibold">Status promosi</h2>
          {promos.length === 0 ? <p className="text-sm text-samudra-600">Belum ada promosi.</p> : (
            <ul className="space-y-2">{promos.map((p) => { const [l, t] = PROMO_STATUS[p.status]!; return (<li key={p.id} className="kartu p-3 text-sm"><div className="flex items-center justify-between"><b>{PROMOTION_KIND_LABEL[p.kind]}</b><Badge tone={t}>{l}</Badge></div><p className="text-samudra-700">{p.durationDays} hari · {formatRupiah(p.amount)}</p>{p.expiresAt && <p className="text-samudra-600">Berlaku sampai {formatTanggal(p.expiresAt, true)}</p>}</li>); })}</ul>
          )}
        </section>
      </div>
    </>
  );
}
