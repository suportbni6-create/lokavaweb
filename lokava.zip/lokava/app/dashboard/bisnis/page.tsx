import Link from "next/link";
import { BusinessForm } from "@/components/forms/BusinessForm";
import { Badge, EmptyState, PageHeader } from "@/components/ui/misc";
import { LinkButton } from "@/components/ui/Button";
import { requirePageUser } from "@/lib/auth/session";
import { FALLBACK_FREE_PLAN, getEffectivePlan } from "@/lib/data/business-core";
import { getOwnerBusinesses, getPurchasables } from "@/lib/data/owner";
import { STATUS_LABEL } from "@/lib/labels";

export const metadata = { title: "Bisnis saya" };

export default async function Page({ searchParams }: { searchParams: Promise<{ id?: string; baru?: string }> }) {
  const user = await requirePageUser();
  const sp = await searchParams;
  const [list, ref] = await Promise.all([getOwnerBusinesses(user.uid), getPurchasables()]);
  const current = sp.id ? list.find((b) => b.id === sp.id) : undefined;
  const maxPhotos = current ? (await getEffectivePlan(current.id)).plan.maxBusinessPhotos : FALLBACK_FREE_PLAN.maxBusinessPhotos;

  if (current || sp.baru || list.length === 0) {
    return (
      <>
        <PageHeader title={current ? current.name : "Daftarkan bisnis"} text="Data diperiksa admin sebelum bisnis tampil di LOKAVA." />
        {current && (
          <div className="mb-5 flex flex-wrap items-center gap-2">
            <Badge tone={STATUS_LABEL[current.verificationStatus]![1]}>{STATUS_LABEL[current.verificationStatus]![0]}</Badge>
            {current.visible && <Link href={`/bisnis/${current.slug}`} className="text-sm font-semibold text-toska-700 underline">Lihat halaman publik</Link>}
            {current.reviewNote && <p role="status" className="w-full rounded-xl bg-amber-50 p-3 text-sm text-amber-900"><b>Catatan admin:</b> {current.reviewNote}</p>}
          </div>
        )}
        <BusinessForm key={current?.id ?? "baru"} business={current} categories={ref.categories} regions={ref.regions} maxPhotos={maxPhotos} />
      </>
    );
  }
  return (
    <>
      <PageHeader title="Bisnis saya"><LinkButton href="/dashboard/bisnis?baru=1">Tambah bisnis</LinkButton></PageHeader>
      {list.length === 0 ? <EmptyState title="Belum ada bisnis" /> : (
        <ul className="grid gap-3 sm:grid-cols-2">
          {list.map((b) => (<li key={b.id} className="kartu p-4"><Badge tone={STATUS_LABEL[b.verificationStatus]![1]}>{STATUS_LABEL[b.verificationStatus]![0]}</Badge><h3 className="judul mt-2 text-lg font-semibold">{b.name}</h3><p className="text-sm text-samudra-600">{b.district}</p><div className="mt-3"><LinkButton href={`/dashboard/bisnis?id=${b.id}`} variant="garis">Kelola</LinkButton></div></li>))}
        </ul>
      )}
    </>
  );
}
