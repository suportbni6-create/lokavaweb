import { TransactionCard, type TxView } from "@/components/dashboard/TransactionCard";
import { EmptyState, PageHeader } from "@/components/ui/misc";
import { requirePageUser } from "@/lib/auth/session";
import { db, docPlain } from "@/lib/firebase/admin";
import { getOwnerTransactions } from "@/lib/data/owner";
import type { PaymentMethodDoc } from "@/types";

export const metadata = { title: "Riwayat transaksi" };

export default async function Page({ searchParams }: { searchParams: Promise<{ id?: string }> }) {
  const user = await requirePageUser();
  const { id } = await searchParams;
  const txs = await getOwnerTransactions(user.uid);
  const pmIds = [...new Set(txs.map((t) => t.paymentMethodId).filter(Boolean))] as string[];
  const pms = new Map<string, PaymentMethodDoc>();
  await Promise.all(pmIds.map(async (pid) => { const p = docPlain<PaymentMethodDoc>(await db().collection("paymentMethods").doc(pid).get()); if (p) pms.set(pid, p); }));
  const views: TxView[] = txs.map((t) => {
    const pm = t.paymentMethodId ? pms.get(t.paymentMethodId) : null;
    return {
      id: t.id, transactionNumber: t.transactionNumber, title: t.title, type: t.type, amount: t.amount, status: t.status, createdAt: t.createdAt, expiresAt: t.expiresAt,
      rejectionReason: t.rejectionReason, hasProof: t.hasProof, proofNote: t.proofNote, businessName: t.businessName,
      paymentMethod: t.paymentMethodSnapshot ? { ...t.paymentMethodSnapshot, instructions: pm?.instructions ?? "", qr: pm?.qrImage ?? null } : null,
    };
  });
  return (
    <>
      <PageHeader title="Riwayat transaksi" text="Nominal ditetapkan server. Unggah bukti setelah Anda membayar." />
      {views.length === 0 ? <EmptyState title="Belum ada transaksi" /> : <ul className="space-y-3">{views.map((v) => <TransactionCard key={v.id} tx={v} highlight={v.id === id} />)}</ul>}
    </>
  );
}
