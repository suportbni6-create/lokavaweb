import Link from "next/link";
import { ProductManager } from "@/components/dashboard/ProductManager";
import { EmptyState, PageHeader } from "@/components/ui/misc";
import { LinkButton } from "@/components/ui/Button";
import { requirePageUser } from "@/lib/auth/session";
import { getEffectivePlan } from "@/lib/data/business-core";
import { getOwnerBusinesses, getOwnerProducts, getPurchasables } from "@/lib/data/owner";

export const metadata = { title: "Produk, menu, dan layanan" };

export default async function Page({ searchParams }: { searchParams: Promise<{ bisnis?: string }> }) {
  const user = await requirePageUser();
  const { bisnis } = await searchParams;
  const list = await getOwnerBusinesses(user.uid);
  if (!list.length) return (<><PageHeader title="Produk" /><EmptyState title="Daftarkan bisnis dulu" text="Produk ditambahkan ke bisnis Anda." action={<LinkButton href="/dashboard/bisnis">Daftarkan bisnis</LinkButton>} /></>);
  const b = list.find((x) => x.id === bisnis) ?? list[0]!;
  const [products, eff, ref] = await Promise.all([getOwnerProducts(user.uid, b.id), getEffectivePlan(b.id), getPurchasables()]);
  return (
    <>
      <PageHeader title="Produk, menu, dan layanan" text="Produk tampil di publik setelah bisnis disetujui." />
      {list.length > 1 && <nav className="mb-4 flex gap-2">{list.map((x) => <Link key={x.id} href={`/dashboard/produk?bisnis=${x.id}`} className={`rounded-full px-4 py-2 text-sm font-semibold ${x.id === b.id ? "bg-samudra-700 text-white" : "border border-samudra-200 bg-white"}`}>{x.name}</Link>)}</nav>}
      <ProductManager businessId={b.id} products={products} categories={ref.categories} maxProducts={eff.plan.maxProducts} maxPhotos={eff.plan.maxProductPhotos} />
    </>
  );
}
