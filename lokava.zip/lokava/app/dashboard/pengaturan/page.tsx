import { DeleteAccount } from "@/components/dashboard/DeleteAccount";
import { PageHeader } from "@/components/ui/misc";
import { requirePageUser } from "@/lib/auth/session";

export const metadata = { title: "Pengaturan akun" };

export default async function Page() {
  const user = await requirePageUser();
  return (
    <>
      <PageHeader title="Pengaturan akun" />
      <div className="space-y-6">
        <section className="kartu p-5"><h2 className="judul text-lg font-semibold">Profil</h2><dl className="mt-3 grid gap-2 text-sm sm:grid-cols-2"><div><dt className="text-samudra-600">Nama</dt><dd className="font-semibold">{user.displayName}</dd></div><div><dt className="text-samudra-600">Email</dt><dd className="font-semibold">{user.email}</dd></div></dl><p className="bantuan mt-3">Untuk mengganti kata sandi, gunakan &ldquo;Lupa kata sandi&rdquo; di halaman masuk.</p></section>
        <DeleteAccount />
      </div>
    </>
  );
}
