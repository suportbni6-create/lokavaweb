import { PanelNav } from "@/components/dashboard/PanelNav";
import { requirePageUser } from "@/lib/auth/session";

export const dynamic = "force-dynamic";
export const metadata = { robots: { index: false } };

const ITEMS = [
  ["/dashboard", "Ringkasan"], ["/dashboard/bisnis", "Bisnis"], ["/dashboard/produk", "Produk"], ["/dashboard/langganan", "Langganan"],
  ["/dashboard/promosi", "Promosi"], ["/dashboard/transaksi", "Transaksi"], ["/dashboard/pengaturan", "Akun"],
] as [string, string][];

export default async function Layout({ children }: { children: React.ReactNode }) {
  const user = await requirePageUser();
  return <PanelNav title={`Halo, ${user.displayName}`} items={ITEMS}>{children}</PanelNav>;
}
