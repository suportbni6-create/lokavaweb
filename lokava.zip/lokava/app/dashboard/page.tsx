import { LinkButton } from "@/components/ui/Button";
import { Badge, EmptyState, PageHeader } from "@/components/ui/misc";
import { requirePageUser } from "@/lib/auth/session";
import { getEffectivePlan } from "@/lib/data/business-core";
import { db } from "@/lib/firebase/admin";
import { getOwnerBusinesses, getOwnerTransactions } from "@/lib/data/owner";
import { STATUS_LABEL, TX_TONE } from "@/lib/labels";
import { formatRupiah, formatTanggal, sisaHari } from "@/lib/utils/format";
import { TRANSACTION_STATUS_LABEL, type TransactionStatus } from "@/types";

export const metadata = { title: "Ringkasan" };

export default async function Page() {
  const user = await requirePageUser();
  const [businesses, txs] = await Promise.all([getOwnerBusinesses(user.uid), getOwnerTransactions(user.uid)]);
  if (businesses.length === 0)
    return (<><PageHeader title="Ringkasan" /><EmptyState title="Daftarkan bisnis pertama Anda" text="Isi data usaha, lalu ajukan verifikasi agar tampil di LOKAVA." action={<LinkButton href="/dashboard/bisnis">Daftarkan bisnis</LinkButton>} /></>);

  const rows = await Promise.all(businesses.map(async (b) => {
    const [eff, products, promos] = await Promise.all([
      getEffectivePlan(b.id),
      db().collection("products").where("businessId", "==", b.id).get().then((s) => s.docs.filter((d) => !d.data().deletedAt).length),
      db().collection("promotions").where("businessId", "==", b.id).where("status", "==", "active").get().then((s) => s.docs.filter((d) => d.data().expiresAt.toDate() > new Date()).length),
    ]);
    return { b, eff, products, promos };
  }));
  const last = txs[0];
  return (
    <>
      <PageHeader title="Ringkasan" text="Pantau status bisnis, paket, dan transaksi Anda." />
      <div className="space-y-4">
        {rows.map(({ b, eff, products, promos }) => {
          const sisa = sisaHari(eff.subscription?.expiresAt);
          return (
            <section key={b.id} className="kartu p-5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h2 className="judul text-xl font-semibold">{b.name}</h2>
                <Badge tone={STATUS_LABEL[b.verificationStatus]![1]}>{STATUS_LABEL[b.verificationStatus]![0]}</Badge>
              </div>
              {b.reviewNote && <p className="mt-2 rounded-xl bg-amber-50 p-3 text-sm text-amber-900"><b>Catatan admin:</b> {b.reviewNote}</p>}
              {eff.expired && <p className="mt-2 rounded-xl bg-amber-50 p-3 text-sm text-amber-900">Paket Anda berakhir. Batas fitur kembali ke paket gratis, data Anda tetap aman. Perpanjang di menu Langganan.</p>}
              <dl className="mt-4 grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
                {[["Paket aktif", eff.plan.name], ["Berakhir", eff.subscription?.expiresAt ? `${formatTanggal(eff.subscription.expiresAt)}${sisa !== null ? ` (${Math.max(sisa, 0)} hari)` : ""}` : "Tidak ada batas"], ["Produk", `${products} / ${eff.plan.maxProducts}`], ["Foto bisnis", `${(b.coverImage ? 1 : 0) + b.gallery.length} / ${eff.plan.maxBusinessPhotos}`], ["Promosi aktif", String(promos)], ["Publikasi", b.visible ? "Tampil di publik" : "Belum tampil"]].map(([k, v]) => (<div key={k}><dt className="text-samudra-600">{k}</dt><dd className="font-semibold">{v}</dd></div>))}
              </dl>
              <div className="mt-4"><LinkButton href={`/dashboard/bisnis?id=${b.id}`} variant="garis">Kelola bisnis</LinkButton></div>
            </section>
          );
        })}
        <section className="kartu p-5">
          <h2 className="judul text-lg font-semibold">Transaksi terakhir</h2>
          {last ? <p className="mt-2 text-sm">{last.transactionNumber} · {last.title} · {formatRupiah(last.amount)} · <Badge tone={TX_TONE[last.status]}>{TRANSACTION_STATUS_LABEL[last.status as TransactionStatus]}</Badge></p> : <p className="mt-2 text-sm text-samudra-600">Belum ada transaksi.</p>}
        </section>
      </div>
    </>
  );
}
