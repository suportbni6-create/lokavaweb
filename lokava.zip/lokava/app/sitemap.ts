import type { MetadataRoute } from "next";
import { appUrl } from "@/lib/env";
import { getSitemapEntries } from "@/lib/data/public";

export const revalidate = 3600;

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const u = appUrl();
  const e = await getSitemapEntries();
  const fixed = ["", "/wisata", "/kuliner", "/penginapan", "/bisnis", "/promosi", "/peta", "/daftar-bisnis", "/privasi", "/syarat"].map((p) => ({ url: `${u}${p}`, changeFrequency: "daily" as const }));
  const map = (arr: { slug: string; updatedAt: string }[], prefix: string) => arr.map((x) => ({ url: `${u}${prefix}/${x.slug}`, lastModified: x.updatedAt ? new Date(x.updatedAt) : undefined }));
  return [...fixed, ...map(e.businesses, "/bisnis"), ...map(e.products, "/produk"), ...map(e.destinations, "/wisata")];
}
