import { getSettings } from "@/lib/data/public";

export const revalidate = 300;
export const metadata = { title: "Kebijakan privasi" };

export default async function Page() {
  const s = await getSettings();
  return (
    <div className="wadah max-w-3xl py-10">
      <h1 className="judul text-3xl font-semibold">Kebijakan privasi</h1>
      <p className="mt-4 whitespace-pre-line leading-relaxed text-samudra-800">{s.privacyPolicy}</p>
    </div>
  );
}
