import Link from "next/link";
import { BusinessCard, Grid, ProductCard, Section } from "@/components/cards";
import { EmptyState, Photo } from "@/components/ui/misc";
import { getActiveBanners, getActivePromotions, getCategories } from "@/lib/data/public";
import { formatTanggal } from "@/lib/utils/format";

export const revalidate = 60;
export const metadata = { title: "Promosi", description: "Promosi aktif dari usaha lokal Sukabumi Selatan." };

export default async function Page() {
  const [banners, promos, cats] = await Promise.all([getActiveBanners(), getActivePromotions(), getCategories()]);
  const biz = promos.filter((p) => p.promotion.kind === "featured_business");
  const prods = promos.filter((p) => p.product);
  const catPromos = promos.filter((p) => p.promotion.kind === "category");
  return (
    <div className="pb-6">
      <div className="wadah pt-8"><h1 className="judul text-3xl font-semibold">Promosi</h1><p className="mt-1 text-sm text-samudra-700">Hanya promosi yang masih berlaku yang ditampilkan.</p></div>
      {banners.length > 0 && <Section title="Banner"><ul className="grid gap-3 sm:grid-cols-2">{banners.map((b) => (<li key={b.id}><Link href={b.targetUrl}><Photo image={b.image} alt={b.title} className="aspect-[21/9] rounded-2xl" sizes="(max-width:640px) 100vw, 50vw" /></Link>{b.expiresAt && <p className="mt-1 text-xs text-samudra-600">Berlaku sampai {formatTanggal(b.expiresAt)}</p>}</li>))}</ul></Section>}
      {biz.length > 0 && <Section title="Bisnis unggulan"><Grid>{biz.map((p) => (<div key={p.promotion.id}><BusinessCard b={p.business} cats={cats} /><p className="mt-1 text-xs text-samudra-600">Berlaku sampai {formatTanggal(p.promotion.expiresAt)}</p></div>))}</Grid></Section>}
      {prods.length > 0 && <Section title="Produk dipromosikan"><Grid cols={4}>{prods.map((p) => <ProductCard key={p.promotion.id} p={p.product!} businessName={p.business.name} />)}</Grid></Section>}
      {catPromos.length > 0 && <Section title="Unggulan di kategori">{cats.filter((c) => catPromos.some((p) => p.promotion.categoryId === c.id)).map((c) => (<div key={c.id} className="mb-6"><h3 className="mb-2 font-semibold">{c.icon} {c.name}</h3><Grid>{catPromos.filter((p) => p.promotion.categoryId === c.id).map((p) => <BusinessCard key={p.promotion.id} b={p.business} cats={cats} />)}</Grid></div>))}</Section>}
      {promos.length === 0 && banners.length === 0 && <div className="wadah py-8"><EmptyState title="Belum ada promosi aktif" text="Pemilik usaha dapat mengajukan promosi dari dashboard." /></div>}
    </div>
  );
}
