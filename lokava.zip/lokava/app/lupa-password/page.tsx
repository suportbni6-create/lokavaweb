import { Suspense } from "react";
import { ResetForm } from "@/components/forms/AuthForms";

export const metadata = { title: "Lupa kata sandi", robots: { index: false } };

export default function Page() {
  return <Suspense><ResetForm /></Suspense>;
}
