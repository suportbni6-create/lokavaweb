import { MapExplorer } from "@/components/public/MapExplorer";
import { PageHeader } from "@/components/ui/misc";
import { getCategories, getMapPoints } from "@/lib/data/public";

export const revalidate = 120;
export const metadata = { title: "Peta wisata dan bisnis", description: "Lihat lokasi wisata dan usaha lokal Sukabumi Selatan di peta." };

export default async function Page() {
  const [points, cats] = await Promise.all([getMapPoints(), getCategories()]);
  return (
    <div className="wadah py-8">
      <PageHeader title="Peta" text="Koordinat berasal dari admin atau pemilik usaha." />
      <MapExplorer points={points} cats={cats} />
    </div>
  );
}
