import { handleError, json, parseBody, rateLimit } from "@/lib/api";
import { requireApiUser } from "@/lib/auth/session";
import { decisionSchema } from "@/lib/validation/schemas";
import { decideTransaction } from "@/lib/payments/transactions";

export const runtime = "nodejs";

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireApiUser({ admin: true });
    rateLimit(`decide:${user.uid}`, 60, 60_000);
    const { id } = await ctx.params;
    const body = await parseBody(req, decisionSchema);
    if (body.decision === "correction") return json({ error: "Gunakan setujui atau tolak." }, 400);
    return json(await decideTransaction(id, body.decision, { id: user.uid, label: user.displayName, isUser: true }, body.reason));
  } catch (e) {
    return handleError(e);
  }
}
