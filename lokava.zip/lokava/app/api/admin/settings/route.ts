import { db, now } from "@/lib/firebase/admin";
import { handleError, json, parseBody } from "@/lib/api";
import { requireApiUser } from "@/lib/auth/session";
import { settingsSchema } from "@/lib/validation/schemas";
import { getSettings } from "@/lib/data/public";
import { assertOwnedAssets, verifyAssets } from "@/lib/cloudinary";
import { audit } from "@/lib/audit";
import { revalidatePath } from "next/cache";

export const runtime = "nodejs";

export async function GET() {
  try {
    await requireApiUser({ admin: true });
    return json(await getSettings());
  } catch (e) {
    return handleError(e);
  }
}

export async function PUT(req: Request) {
  try {
    const user = await requireApiUser({ admin: true });
    const data = await parseBody(req, settingsSchema);
    const cur = await getSettings();
    if (data.logo && data.logo.publicId !== cur.logo?.publicId) {
      assertOwnedAssets([data.logo.publicId], ["admin"], user.uid, true);
      await verifyAssets([data.logo.publicId]);
    }
    await db().collection("appSettings").doc("default").set({ ...data, updatedAt: now() });
    await audit({ actorId: user.uid, action: "settings.update", targetType: "appSettings", targetId: "default", summary: "Pengaturan aplikasi diperbarui" });
    revalidatePath("/", "layout");
    return json({ ok: true });
  } catch (e) {
    return handleError(e);
  }
}
