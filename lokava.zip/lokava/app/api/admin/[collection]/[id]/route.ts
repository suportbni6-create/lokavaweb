import { handleError, json } from "@/lib/api";
import { requireApiUser, HttpError } from "@/lib/auth/session";
import { isAdminCollection } from "@/lib/validation/schemas";
import { adminDelete, adminUpdate } from "@/lib/admin/crud";

export const runtime = "nodejs";
type Ctx = { params: Promise<{ collection: string; id: string }> };

export async function PUT(req: Request, ctx: Ctx) {
  try {
    const user = await requireApiUser({ admin: true });
    const { collection, id } = await ctx.params;
    if (!isAdminCollection(collection)) throw new HttpError(404, "Koleksi tidak dikenal.");
    return json(await adminUpdate(user, collection, id, await req.json()));
  } catch (e) {
    return handleError(e);
  }
}

export async function DELETE(_req: Request, ctx: Ctx) {
  try {
    const user = await requireApiUser({ admin: true });
    const { collection, id } = await ctx.params;
    if (!isAdminCollection(collection)) throw new HttpError(404, "Koleksi tidak dikenal.");
    return json(await adminDelete(user, collection, id));
  } catch (e) {
    return handleError(e);
  }
}
