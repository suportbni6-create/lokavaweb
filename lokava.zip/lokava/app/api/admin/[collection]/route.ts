import { handleError, json } from "@/lib/api";
import { requireApiUser, HttpError } from "@/lib/auth/session";
import { isAdminCollection } from "@/lib/validation/schemas";
import { adminCreate, adminList } from "@/lib/admin/crud";

export const runtime = "nodejs";

export async function GET(_req: Request, ctx: { params: Promise<{ collection: string }> }) {
  try {
    await requireApiUser({ admin: true });
    const { collection } = await ctx.params;
    if (!isAdminCollection(collection)) throw new HttpError(404, "Koleksi tidak dikenal.");
    return json({ items: await adminList(collection) });
  } catch (e) {
    return handleError(e);
  }
}

export async function POST(req: Request, ctx: { params: Promise<{ collection: string }> }) {
  try {
    const user = await requireApiUser({ admin: true });
    const { collection } = await ctx.params;
    if (!isAdminCollection(collection)) throw new HttpError(404, "Koleksi tidak dikenal.");
    return json(await adminCreate(user, collection, await req.json()), 201);
  } catch (e) {
    return handleError(e);
  }
}
