import { db, now } from "@/lib/firebase/admin";
import { handleError, json } from "@/lib/api";
import { HttpError, requireApiUser } from "@/lib/auth/session";
import { audit } from "@/lib/audit";

export const runtime = "nodejs";

/** Menonaktifkan promosi aktif (mis. pelanggaran). Uang tidak dikembalikan otomatis. */
export async function PATCH(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireApiUser({ admin: true });
    const { id } = await ctx.params;
    const ref = db().collection("promotions").doc(id);
    const s = await ref.get();
    if (!s.exists) throw new HttpError(404, "Promosi tidak ditemukan.");
    if (s.data()!.status !== "active") throw new HttpError(409, "Hanya promosi aktif yang dapat dinonaktifkan.");
    await ref.update({ status: "deactivated", updatedAt: now() });
    await db().collection("banners").doc(`promo_${id}`).update({ active: false, updatedAt: now() }).catch(() => undefined);
    await audit({ actorId: user.uid, action: "promotion.deactivate", targetType: "promotion", targetId: id, summary: "Promosi dinonaktifkan admin" });
    return json({ ok: true });
  } catch (e) {
    return handleError(e);
  }
}
