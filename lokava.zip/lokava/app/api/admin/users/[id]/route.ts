import { adminAuth, db, now } from "@/lib/firebase/admin";
import { handleError, json, parseBody } from "@/lib/api";
import { HttpError, requireApiUser } from "@/lib/auth/session";
import { userStatusSchema } from "@/lib/validation/schemas";
import { syncOwnerBusinesses } from "@/lib/data/business-core";
import { audit } from "@/lib/audit";

export const runtime = "nodejs";

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const admin = await requireApiUser({ admin: true });
    const { id } = await ctx.params;
    const { status, reason } = await parseBody(req, userStatusSchema);
    if (id === admin.uid) throw new HttpError(400, "Anda tidak dapat mengubah status akun sendiri.");
    const ref = db().collection("users").doc(id);
    const snap = await ref.get();
    if (!snap.exists) throw new HttpError(404, "Pengguna tidak ditemukan.");
    const u = snap.data()!;
    if (u.role === "admin") throw new HttpError(403, "Status akun admin tidak dapat diubah dari sini.");
    if (!["active", "suspended"].includes(u.status)) throw new HttpError(409, "Akun sedang dihapus atau sudah dihapus.");
    await ref.update({ status, updatedAt: now() });
    if (status === "suspended") await adminAuth().revokeRefreshTokens(id).catch(() => undefined);
    await syncOwnerBusinesses(id);
    await audit({ actorId: admin.uid, action: `user.${status === "suspended" ? "suspend" : "reactivate"}`, targetType: "user", targetId: id, summary: `${u.email}${reason ? `: ${reason}` : ""}` });
    return json({ ok: true });
  } catch (e) {
    return handleError(e);
  }
}
