import { handleError, json } from "@/lib/api";
import { requireApiUser } from "@/lib/auth/session";
import { processDeletion } from "@/lib/deletion";
import { audit } from "@/lib/audit";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function POST(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireApiUser({ admin: true });
    const { id } = await ctx.params;
    const r = await processDeletion(id);
    await audit({ actorId: user.uid, action: "deletion.retry", targetType: "deletionRequest", targetId: id, summary: r.ok ? "Selesai" : "Masih gagal", result: r.ok ? "success" : "failure" });
    return json(r);
  } catch (e) {
    return handleError(e);
  }
}
