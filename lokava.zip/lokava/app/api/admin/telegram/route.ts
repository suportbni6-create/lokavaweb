import { z } from "zod";
import { db, now } from "@/lib/firebase/admin";
import { handleError, json, parseBody } from "@/lib/api";
import { requireApiUser } from "@/lib/auth/session";
import { requireSuperAdmin } from "@/lib/auth/super";
import { telegramSettingsSchema } from "@/lib/validation/schemas";
import { getTelegramSettings, isTokenConfigured, registerWebhook, saveBotToken, testConnection } from "@/lib/telegram";
import { serverEnv } from "@/lib/env";
import { audit } from "@/lib/audit";

export const runtime = "nodejs";

/** Token tidak pernah dikembalikan; hanya status terkonfigurasi. */
export async function GET() {
  try {
    await requireApiUser({ admin: true });
    const s = await getTelegramSettings();
    return json({ ...s, tokenConfigured: await isTokenConfigured(), webhookSecretConfigured: Boolean(serverEnv().TELEGRAM_WEBHOOK_SECRET) });
  } catch (e) {
    return handleError(e);
  }
}

export async function PUT(req: Request) {
  try {
    const user = await requireSuperAdmin();
    const { botToken, ...settings } = await parseBody(req, telegramSettingsSchema);
    await db().collection("telegramSettings").doc("default").set({ ...settings, updatedAt: now() });
    if (botToken) await saveBotToken(botToken);
    // Catat perubahan TANPA nilai token
    await audit({ actorId: user.uid, action: "telegram.update", targetType: "telegramSettings", targetId: "default", summary: `Pengaturan Telegram diperbarui${botToken ? " (token diganti)" : ""}; mode ${settings.verificationMode}` });
    return json({ ok: true });
  } catch (e) {
    return handleError(e);
  }
}

export async function POST(req: Request) {
  try {
    const user = await requireSuperAdmin();
    const { action } = await parseBody(req, z.object({ action: z.enum(["test", "webhook"]) }));
    const r = action === "test" ? await testConnection() : await registerWebhook();
    await audit({ actorId: user.uid, action: `telegram.${action}`, targetType: "telegramSettings", targetId: "default", summary: r.message, result: r.ok ? "success" : "failure" });
    return json(r);
  } catch (e) {
    return handleError(e);
  }
}
