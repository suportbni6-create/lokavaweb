import { z } from "zod";
import { db, now } from "@/lib/firebase/admin";
import { handleError, json, parseBody } from "@/lib/api";
import { HttpError, requireApiUser } from "@/lib/auth/session";
import { decisionSchema, businessSchema } from "@/lib/validation/schemas";
import { decideBusiness } from "@/lib/admin/decisions";
import { syncBusinessVisibility } from "@/lib/data/business-core";
import { saveBusiness } from "@/lib/data/save";
import { audit } from "@/lib/audit";

export const runtime = "nodejs";
type Ctx = { params: Promise<{ id: string }> };

export async function POST(req: Request, ctx: Ctx) {
  try {
    const user = await requireApiUser({ admin: true });
    const { id } = await ctx.params;
    const body = await parseBody(req, decisionSchema);
    return json(await decideBusiness(id, body.decision, { id: user.uid, label: user.displayName, isUser: true }, body.reason));
  } catch (e) {
    return handleError(e);
  }
}

const actionSchema = z.object({ action: z.enum(["suspend", "reactivate", "unpublish", "publish"]), reason: z.string().trim().max(300).optional() });

export async function PATCH(req: Request, ctx: Ctx) {
  try {
    const user = await requireApiUser({ admin: true });
    const { id } = await ctx.params;
    const { action, reason } = await parseBody(req, actionSchema);
    const ref = db().collection("businesses").doc(id);
    const snap = await ref.get();
    if (!snap.exists || snap.data()!.deletedAt) throw new HttpError(404, "Bisnis tidak ditemukan.");
    const cur = snap.data()!.verificationStatus as string;
    const patch: Record<string, unknown> = { updatedAt: now() };
    if (action === "suspend") { patch.verificationStatus = "suspended"; patch.publicationStatus = "unpublished"; patch.reviewNote = reason ?? "Ditangguhkan oleh admin."; }
    else if (action === "reactivate") { if (cur !== "suspended") throw new HttpError(409, "Bisnis tidak sedang ditangguhkan."); patch.verificationStatus = "approved"; patch.publicationStatus = "published"; patch.reviewNote = null; }
    else if (cur !== "approved") throw new HttpError(409, "Hanya bisnis yang disetujui yang dapat diubah status publikasinya.");
    else patch.publicationStatus = action === "publish" ? "published" : "unpublished";
    await ref.update(patch);
    await syncBusinessVisibility(id);
    await audit({ actorId: user.uid, action: `business.${action}`, targetType: "business", targetId: id, summary: `${snap.data()!.name}${reason ? `: ${reason}` : ""}` });
    return json({ ok: true });
  } catch (e) {
    return handleError(e);
  }
}

export async function PUT(req: Request, ctx: Ctx) {
  try {
    const user = await requireApiUser({ admin: true });
    const { id } = await ctx.params;
    const b = await saveBusiness(user, await parseBody(req, businessSchema), id);
    return json({ id: b.id });
  } catch (e) {
    return handleError(e);
  }
}
