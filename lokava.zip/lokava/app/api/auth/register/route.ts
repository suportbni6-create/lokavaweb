import { adminAuth, db, now } from "@/lib/firebase/admin";
import { handleError, json, parseBody, rateLimit, clientIp } from "@/lib/api";
import { registerSchema } from "@/lib/validation/schemas";
import { normalizeWhatsapp } from "@/lib/utils/whatsapp";
import { audit } from "@/lib/audit";

export const runtime = "nodejs";

/** Membuat profil Firestore. Role SELALU "owner"; admin hanya lewat skrip bootstrap. */
export async function POST(req: Request) {
  try {
    rateLimit(`register:${clientIp(req)}`, 10, 60_000);
    const body = await parseBody(req, registerSchema);
    const decoded = await adminAuth().verifyIdToken(body.idToken);
    if (!decoded.email) return json({ error: "Akun harus memiliki email." }, 400);
    const ref = db().collection("users").doc(decoded.uid);
    const snap = await ref.get();
    if (!snap.exists) {
      await ref.set({
        uid: decoded.uid, email: decoded.email, displayName: body.displayName,
        phone: normalizeWhatsapp(body.phone) ?? null, role: "owner", status: "active",
        createdAt: now(), updatedAt: now(), deletionRequestedAt: null,
      });
      await audit({ actorId: decoded.uid, action: "user.register", targetType: "user", targetId: decoded.uid, summary: "Registrasi pemilik bisnis" });
    }
    return json({ ok: true });
  } catch (e) {
    return handleError(e);
  }
}
