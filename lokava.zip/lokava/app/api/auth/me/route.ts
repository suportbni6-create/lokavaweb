import { getCurrentUser } from "@/lib/auth/session";
import { json } from "@/lib/api";

export const runtime = "nodejs";

export async function GET() {
  const u = await getCurrentUser();
  return json(u && u.status === "active" ? { role: u.role, name: u.displayName } : { role: null });
}
