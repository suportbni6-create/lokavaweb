import { cookies } from "next/headers";
import { adminAuth, db } from "@/lib/firebase/admin";
import { handleError, json, parseBody, rateLimit, clientIp } from "@/lib/api";
import { SESSION_COOKIE, SESSION_MAX_AGE_MS, HttpError } from "@/lib/auth/session";
import { sessionSchema } from "@/lib/validation/schemas";

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    rateLimit(`session:${clientIp(req)}`, 20, 60_000);
    const { idToken } = await parseBody(req, sessionSchema);
    const decoded = await adminAuth().verifyIdToken(idToken, true);
    const user = await db().collection("users").doc(decoded.uid).get();
    if (!user.exists) throw new HttpError(404, "Profil belum dibuat. Daftar terlebih dahulu.");
    const status = user.data()!.status as string;
    if (status === "suspended") throw new HttpError(403, "Akun Anda ditangguhkan. Hubungi admin LOKAVA.");
    if (status !== "active") throw new HttpError(403, "Akun sedang dalam proses penghapusan atau sudah dihapus.");
    const cookie = await adminAuth().createSessionCookie(idToken, { expiresIn: SESSION_MAX_AGE_MS });
    (await cookies()).set(SESSION_COOKIE, cookie, {
      httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", path: "/", maxAge: SESSION_MAX_AGE_MS / 1000,
    });
    return json({ ok: true, role: user.data()!.role });
  } catch (e) {
    return handleError(e);
  }
}

export async function DELETE() {
  (await cookies()).delete(SESSION_COOKIE);
  return json({ ok: true });
}
