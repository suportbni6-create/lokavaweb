import { handleError, json, parseBody, rateLimit } from "@/lib/api";
import { requireApiUser } from "@/lib/auth/session";
import { proofSchema } from "@/lib/validation/schemas";
import { submitProof } from "@/lib/payments/transactions";

export const runtime = "nodejs";

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireApiUser();
    rateLimit(`proof:${user.uid}`, 10, 60_000);
    const { id } = await ctx.params;
    return json(await submitProof(user, id, await parseBody(req, proofSchema)));
  } catch (e) {
    return handleError(e);
  }
}
