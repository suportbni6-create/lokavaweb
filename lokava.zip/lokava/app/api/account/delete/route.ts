import { cookies } from "next/headers";
import { handleError, json, parseBody, rateLimit } from "@/lib/api";
import { SESSION_COOKIE, HttpError, requireApiUser } from "@/lib/auth/session";
import { deleteAccountSchema } from "@/lib/validation/schemas";
import { processDeletion, requestAccountDeletion } from "@/lib/deletion";
import { adminAuth } from "@/lib/firebase/admin";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function POST(req: Request) {
  try {
    const user = await requireApiUser();
    if (user.role === "admin") throw new HttpError(403, "Akun admin tidak dapat dihapus dari sini.");
    rateLimit(`del:${user.uid}`, 3, 60_000);
    await parseBody(req, deleteAccountSchema);
    // Autentikasi ulang: sesi harus dibuat dalam 10 menit terakhir
    const store = await cookies();
    const decoded = await adminAuth().verifySessionCookie(store.get(SESSION_COOKIE)!.value, true);
    if (Date.now() / 1000 - decoded.auth_time > 600) throw new HttpError(401, "Masuk ulang terlebih dahulu untuk menghapus akun.");

    const r = await requestAccountDeletion(user.uid);
    store.delete(SESSION_COOKIE);
    // Proses penghapusan; bila ada langkah gagal, cron akan melanjutkan.
    const result = await processDeletion(r.id);
    return json({ ok: true, completed: result.ok, message: result.ok ? "Akun dan data Anda telah dihapus." : "Konten Anda sudah disembunyikan. Penghapusan sedang dilanjutkan di latar belakang." });
  } catch (e) {
    return handleError(e);
  }
}
