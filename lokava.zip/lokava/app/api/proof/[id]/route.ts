import { NextResponse } from "next/server";
import { handleError } from "@/lib/api";
import { HttpError, requireApiUser } from "@/lib/auth/session";
import { db } from "@/lib/firebase/admin";
import { privateProofUrl } from "@/lib/cloudinary";

export const runtime = "nodejs";

/** Bukti pembayaran hanya dapat dibuka oleh pemilik transaksi atau admin, lewat URL sementara (5 menit). */
export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireApiUser();
    const { id } = await ctx.params;
    const snap = await db().collection("transactions").doc(id).get();
    const tx = snap.data();
    if (!tx || !tx.proof) throw new HttpError(404, "Bukti tidak ditemukan.");
    if (user.role !== "admin" && tx.ownerId !== user.uid) throw new HttpError(404, "Bukti tidak ditemukan.");
    const res = NextResponse.redirect(privateProofUrl(tx.proof.publicId, tx.proof.format), 302);
    res.headers.set("Cache-Control", "private, no-store");
    return res;
  } catch (e) {
    return handleError(e);
  }
}
