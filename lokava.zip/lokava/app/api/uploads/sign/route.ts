import { handleError, json, parseBody, rateLimit } from "@/lib/api";
import { requireApiUser, HttpError } from "@/lib/auth/session";
import { signUpload } from "@/lib/cloudinary";
import { uploadSignSchema } from "@/lib/validation/schemas";

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    const user = await requireApiUser();
    rateLimit(`sign:${user.uid}`, 60, 60_000);
    const { purpose } = await parseBody(req, uploadSignSchema);
    if (purpose === "admin" && user.role !== "admin") throw new HttpError(403, "Akses ditolak.");
    if (purpose !== "admin" && user.role === "admin") throw new HttpError(403, "Gunakan unggahan admin.");
    return json(signUpload(purpose, user.uid));
  } catch (e) {
    return handleError(e);
  }
}
