import { handleError, json, parseBody } from "@/lib/api";
import { requireApiUser } from "@/lib/auth/session";
import { businessSchema } from "@/lib/validation/schemas";
import { saveBusiness } from "@/lib/data/save";

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    const user = await requireApiUser();
    const input = await parseBody(req, businessSchema);
    const b = await saveBusiness(user, input);
    return json({ id: b.id, verificationStatus: b.verificationStatus }, 201);
  } catch (e) {
    return handleError(e);
  }
}
