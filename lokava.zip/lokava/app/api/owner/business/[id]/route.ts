import { handleError, json, parseBody } from "@/lib/api";
import { requireApiUser } from "@/lib/auth/session";
import { businessSchema } from "@/lib/validation/schemas";
import { saveBusiness } from "@/lib/data/save";

export const runtime = "nodejs";

export async function PUT(req: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireApiUser();
    const { id } = await ctx.params;
    const input = await parseBody(req, businessSchema);
    const b = await saveBusiness(user, input, id);
    return json({ id: b.id, verificationStatus: b.verificationStatus });
  } catch (e) {
    return handleError(e);
  }
}
