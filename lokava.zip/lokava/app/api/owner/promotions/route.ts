import { handleError, json, parseBody, rateLimit } from "@/lib/api";
import { requireApiUser } from "@/lib/auth/session";
import { promotionTxSchema } from "@/lib/validation/schemas";
import { createPromotionTransaction } from "@/lib/payments/transactions";

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    const user = await requireApiUser();
    rateLimit(`promotx:${user.uid}`, 10, 60_000);
    return json(await createPromotionTransaction(user, await parseBody(req, promotionTxSchema)), 201);
  } catch (e) {
    return handleError(e);
  }
}
