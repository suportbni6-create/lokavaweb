import { handleError, json, parseBody } from "@/lib/api";
import { requireApiUser } from "@/lib/auth/session";
import { productSchema } from "@/lib/validation/schemas";
import { deleteProduct, saveProduct } from "@/lib/data/save";

export const runtime = "nodejs";

export async function PUT(req: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireApiUser();
    const { id } = await ctx.params;
    const p = await saveProduct(user, await parseBody(req, productSchema), id);
    return json({ id: p.id });
  } catch (e) {
    return handleError(e);
  }
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireApiUser();
    await deleteProduct(user, (await ctx.params).id);
    return json({ ok: true });
  } catch (e) {
    return handleError(e);
  }
}
