import { handleError, json, parseBody } from "@/lib/api";
import { requireApiUser } from "@/lib/auth/session";
import { productSchema } from "@/lib/validation/schemas";
import { saveProduct } from "@/lib/data/save";

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    const user = await requireApiUser();
    if (user.role !== "owner") return json({ error: "Hanya pemilik bisnis." }, 403);
    const p = await saveProduct(user, await parseBody(req, productSchema));
    return json({ id: p.id }, 201);
  } catch (e) {
    return handleError(e);
  }
}
