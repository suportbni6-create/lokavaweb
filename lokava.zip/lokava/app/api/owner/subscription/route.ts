import { handleError, json, parseBody, rateLimit } from "@/lib/api";
import { requireApiUser } from "@/lib/auth/session";
import { subscriptionTxSchema } from "@/lib/validation/schemas";
import { createSubscriptionTransaction } from "@/lib/payments/transactions";

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    const user = await requireApiUser();
    rateLimit(`subtx:${user.uid}`, 10, 60_000);
    // Nominal TIDAK diterima dari klien; hanya id paket & metode.
    return json(await createSubscriptionTransaction(user, await parseBody(req, subscriptionTxSchema)), 201);
  } catch (e) {
    return handleError(e);
  }
}
