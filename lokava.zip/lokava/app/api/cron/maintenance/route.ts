import { NextResponse } from "next/server";
import { db, now } from "@/lib/firebase/admin";
import { serverEnv } from "@/lib/env";
import { safeEqual } from "@/lib/crypto";
import { runExpiry } from "@/lib/payments/transactions";
import { processDeletion } from "@/lib/deletion";
import { deleteAssets } from "@/lib/cloudinary";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function GET(req: Request) {
  const auth = req.headers.get("authorization") ?? "";
  if (!safeEqual(auth, `Bearer ${serverEnv().CRON_SECRET}`)) return new NextResponse("Unauthorized", { status: 401 });

  const expiry = await runExpiry();

  // Lanjutkan penghapusan akun yang gagal sebagian / tertunda
  let deletions = 0;
  const pending = await db().collection("deletionRequests").where("status", "in", ["requested", "failed", "processing"]).limit(5).get();
  for (const d of pending.docs) { await processDeletion(d.id); deletions++; }

  // Retensi: hapus catatan transaksi yang melewati masa simpan beserta bukti pembayarannya
  let purged = 0;
  const old = await db().collection("transactions").where("retentionUntil", "<", now()).limit(100).get();
  for (const d of old.docs) {
    const proof = d.data().proof as { publicId: string } | null;
    if (proof) await deleteAssets([proof.publicId], "authenticated").catch(() => undefined);
    await d.ref.delete();
    purged++;
  }
  return NextResponse.json({ ok: true, expiry, deletions, purged });
}
