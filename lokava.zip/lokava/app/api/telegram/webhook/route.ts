import { NextResponse } from "next/server";
import { serverEnv } from "@/lib/env";
import { safeEqual } from "@/lib/crypto";
import { handleUpdate } from "@/lib/telegram/webhook";

export const runtime = "nodejs";
export const maxDuration = 30;

export async function POST(req: Request) {
  const expected = serverEnv().TELEGRAM_WEBHOOK_SECRET;
  const got = req.headers.get("x-telegram-bot-api-secret-token") ?? "";
  // Tanpa rahasia terkonfigurasi, endpoint menolak semuanya.
  if (!expected || !safeEqual(got, expected)) return new NextResponse("Unauthorized", { status: 401 });
  try {
    const update = await req.json();
    await handleUpdate(update);
  } catch (e) {
    console.error("[telegram] gagal memproses update:", e instanceof Error ? e.message.slice(0, 120) : "error");
  }
  return NextResponse.json({ ok: true }); // selalu 200 agar Telegram tidak mengulang
}
