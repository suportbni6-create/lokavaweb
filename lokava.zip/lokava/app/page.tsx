import Link from "next/link";
import { Section, Grid, BusinessCard, DestinationCard, ProductCard } from "@/components/cards";
import { LinkButton } from "@/components/ui/Button";
import { EmptyState, Photo } from "@/components/ui/misc";
import { getActiveBanners, getActivePromotions, getCategories, getRegions, getSettings, listBusinesses, listDestinations, listFeaturedProducts } from "@/lib/data/public";
import { idsOfGroup } from "@/lib/groups";

export const revalidate = 60;

export default async function Beranda() {
  const [s, cats, banners, dest, promos, kuliner, inap, lokal, produk, regions] = await Promise.all([
    getSettings(), getCategories(), getActiveBanners(), listDestinations({ featured: true, limit: 6 }), getActivePromotions(),
    getCategories().then((c) => listBusinesses({ categoryIds: idsOfGroup(c, "kuliner"), limit: 3 })),
    getCategories().then((c) => listBusinesses({ categoryIds: idsOfGroup(c, "penginapan"), limit: 3 })),
    listBusinesses({ limit: 6 }), listFeaturedProducts(8), getRegions(),
  ]);
  const featured = promos.filter((p) => p.promotion.kind === "featured_business").slice(0, 3);
  const promoProducts = promos.filter((p) => p.product).slice(0, 4);

  return (
    <>
      <section className="relative overflow-hidden bg-samudra-800 text-white">
        <div aria-hidden className="absolute inset-0 bg-[radial-gradient(60rem_30rem_at_80%_-10%,rgba(38,189,176,.35),transparent)]" />
        <div className="wadah relative grid gap-8 py-14 sm:py-20 lg:grid-cols-[1.2fr_.8fr] lg:items-center">
          <div>
            <p className="text-sm font-semibold text-toska-200">Ujunggenteng dan Sukabumi Selatan</p>
            <h1 className="mt-3 font-display text-4xl font-semibold leading-[1.05] tracking-tight sm:text-6xl" style={{ fontFamily: "var(--font-display)" }}>{s.tagline.replace(/\.$/, "")}.</h1>
            <p className="mt-4 max-w-xl text-base text-samudra-100 sm:text-lg">{s.description}</p>
            <form action="/cari" role="search" className="mt-6 flex max-w-xl gap-2">
              <label htmlFor="cari-hero" className="sr-only">Cari di LOKAVA</label>
              <input id="cari-hero" name="q" placeholder="Cari pantai, seafood, homestay, oleh-oleh…" className="input !rounded-2xl !py-3.5" />
              <button className="rounded-2xl bg-toska-400 px-5 text-sm font-bold text-samudra-900 hover:bg-toska-300">Cari</button>
            </form>
            <div className="mt-5 flex flex-wrap gap-3">
              <LinkButton href="/wisata" variant="sekunder">Jelajahi destinasi</LinkButton>
              <LinkButton href="/peta" variant="garis" className="!border-white/30 !bg-white/10 !text-white hover:!bg-white/20">Buka peta</LinkButton>
            </div>
          </div>
          <div className="hidden lg:block">
            {banners[0] ? (
              <Link href={banners[0].targetUrl}><Photo image={banners[0].image} alt={banners[0].title} className="aspect-[4/3] rounded-3xl" priority /></Link>
            ) : (
              <Photo image={dest.items[0]?.coverImage ?? null} alt={dest.items[0]?.name ?? "Pesisir Sukabumi Selatan"} className="aspect-[4/3] rounded-3xl" priority />
            )}
          </div>
        </div>
        <svg aria-hidden viewBox="0 0 1440 60" preserveAspectRatio="none" className="block h-8 w-full text-[#f4fafb] sm:h-12"><path fill="currentColor" d="M0 30c120 30 240 30 360 10s240-40 360-30 240 40 360 40 240-20 360-30V60H0Z" /></svg>
      </section>

      {banners.length > 1 && (
        <section aria-label="Promosi" className="wadah -mt-2 pb-2">
          <ul className="flex snap-x gap-3 overflow-x-auto pb-2">
            {banners.map((b) => (<li key={b.id} className="w-[85%] shrink-0 snap-start sm:w-[48%]"><Link href={b.targetUrl}><Photo image={b.image} alt={b.title} className="aspect-[21/9] rounded-2xl" sizes="(max-width: 640px) 85vw, 50vw" /></Link></li>))}
          </ul>
        </section>
      )}

      <Section title="Kategori populer">
        {cats.length === 0 ? <EmptyState title="Kategori belum tersedia" text="Admin dapat menambahkan kategori dari dashboard." /> : (
          <ul className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-7">
            {cats.slice(0, 14).map((c) => (
              <li key={c.id}><Link href={`/bisnis?kategori=${c.id}`} className="kartu flex flex-col items-center gap-1 px-2 py-4 text-center text-sm font-semibold hover:border-toska-300"><span aria-hidden className="text-2xl">{c.icon}</span>{c.name}</Link></li>
            ))}
          </ul>
        )}
      </Section>

      <Section title="Wisata unggulan" text="Pantai dan keindahan alam yang dicatat pengelola." href="/wisata">
        {dest.items.length ? <Grid>{dest.items.map((d) => <DestinationCard key={d.id} d={d} />)}</Grid> : <EmptyState title="Belum ada wisata unggulan" text="Destinasi akan tampil di sini setelah ditambahkan admin." />}
      </Section>

      {(featured.length > 0 || promoProducts.length > 0) && (
        <Section title="Promosi aktif" href="/promosi">
          {featured.length > 0 && <Grid>{featured.map((f) => <BusinessCard key={f.promotion.id} b={f.business} cats={cats} />)}</Grid>}
          {promoProducts.length > 0 && <div className="mt-4"><Grid cols={4}>{promoProducts.map((p) => <ProductCard key={p.promotion.id} p={p.product!} businessName={p.business.name} />)}</Grid></div>}
        </Section>
      )}

      <Section title="Kuliner populer" href="/kuliner">
        {kuliner.items.length ? <Grid>{kuliner.items.map((b) => <BusinessCard key={b.id} b={b} cats={cats} />)}</Grid> : <EmptyState title="Belum ada kuliner terdaftar" text="Pemilik warung dan restoran dapat mendaftarkan usahanya." action={<LinkButton href="/daftar-bisnis">Daftarkan usaha</LinkButton>} />}
      </Section>

      <Section title="Penginapan" href="/penginapan">
        {inap.items.length ? <Grid>{inap.items.map((b) => <BusinessCard key={b.id} b={b} cats={cats} />)}</Grid> : <EmptyState title="Belum ada penginapan terdaftar" />}
      </Section>

      {regions.length > 0 && (
        <Section title="Jelajahi per wilayah">
          <ul className="flex flex-wrap gap-2">{regions.map((r) => (<li key={r.id}><Link href={`/bisnis?district=${encodeURIComponent(r.district)}`} className="inline-block rounded-full border border-samudra-200 bg-white px-4 py-2 text-sm font-semibold hover:bg-samudra-50">{r.name}</Link></li>))}</ul>
        </Section>
      )}

      <Section title="Bisnis lokal terbaru" href="/bisnis">
        {lokal.items.length ? <Grid>{lokal.items.map((b) => <BusinessCard key={b.id} b={b} cats={cats} />)}</Grid> : <EmptyState title="Belum ada bisnis terdaftar" />}
      </Section>

      {produk.length > 0 && <Section title="Produk pilihan" href="/produk"><Grid cols={4}>{produk.map((p) => <ProductCard key={p.id} p={p} />)}</Grid></Section>}

      <section className="wadah py-10">
        <div className="rounded-3xl bg-gradient-to-br from-toska-600 to-samudra-700 p-8 text-white sm:p-12">
          <h2 className="judul !text-white text-2xl font-semibold sm:text-4xl">Punya usaha di Sukabumi Selatan?</h2>
          <p className="mt-2 max-w-xl text-samudra-100">Daftarkan usahamu gratis, tampilkan menu dan produk, lalu terima pesanan langsung lewat WhatsApp.</p>
          <div className="mt-5"><LinkButton href="/daftar-bisnis" variant="garis">Daftarkan bisnis</LinkButton></div>
        </div>
      </section>
    </>
  );
}
