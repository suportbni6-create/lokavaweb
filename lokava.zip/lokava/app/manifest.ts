import type { MetadataRoute } from "next";
import { getSettings } from "@/lib/data/public";

export const revalidate = 3600;

export default async function manifest(): Promise<MetadataRoute.Manifest> {
  const s = await getSettings();
  return {
    name: `${s.appName} — ${s.tagline}`,
    short_name: s.appName,
    description: s.description,
    lang: "id",
    start_url: "/",
    scope: "/",
    display: "standalone",
    orientation: "portrait",
    background_color: "#f4fafb",
    theme_color: s.pwaThemeColor,
    categories: ["travel", "food", "business"],
    icons: [
      { src: "/icons/icon-192.png", sizes: "192x192", type: "image/png", purpose: "any" },
      { src: "/icons/icon-512.png", sizes: "512x512", type: "image/png", purpose: "any" },
      { src: "/icons/maskable-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
    ],
  };
}
