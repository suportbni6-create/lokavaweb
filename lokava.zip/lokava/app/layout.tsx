import type { Metadata, Viewport } from "next";
import { Fraunces, Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { InstallPrompt } from "@/components/layout/InstallPrompt";
import { RegisterSW } from "@/components/layout/RegisterSW";
import { ToastProvider } from "@/components/ui/Toast";
import { getSettings } from "@/lib/data/public";
import { appUrl } from "@/lib/env";

const sans = Plus_Jakarta_Sans({ subsets: ["latin"], variable: "--font-sans", display: "swap" });
const display = Fraunces({ subsets: ["latin"], variable: "--font-display", display: "swap", axes: ["opsz"] });

export const revalidate = 120;

export async function generateMetadata(): Promise<Metadata> {
  const s = await getSettings();
  return {
    metadataBase: new URL(appUrl()),
    title: { default: s.seoTitle, template: `%s | ${s.appName}` },
    description: s.seoDescription,
    applicationName: s.appName,
    manifest: "/manifest.webmanifest",
    icons: { icon: "/favicon.png", apple: "/icons/apple-touch-icon.png" },
    appleWebApp: { capable: true, title: s.appName, statusBarStyle: "default" },
    openGraph: { type: "website", locale: "id_ID", siteName: s.appName, title: s.seoTitle, description: s.seoDescription },
    alternates: { canonical: "/" },
  };
}

export async function generateViewport(): Promise<Viewport> {
  const s = await getSettings();
  return { themeColor: s.pwaThemeColor, width: "device-width", initialScale: 1 };
}

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const s = await getSettings();
  return (
    <html lang="id" className={`${sans.variable} ${display.variable}`}>
      <body className="flex min-h-screen flex-col antialiased">
        <a href="#isi" className="sr-only focus:not-sr-only focus:absolute focus:z-[70] focus:m-2 focus:rounded-lg focus:bg-white focus:p-3">Lewati ke konten</a>
        <ToastProvider>
          <Navbar appName={s.appName} logo={s.logo} />
          <main id="isi" className="flex-1">{children}</main>
          <Footer s={s} />
          <InstallPrompt enabled={s.installPopupEnabled} />
        </ToastProvider>
        <RegisterSW />
      </body>
    </html>
  );
}
