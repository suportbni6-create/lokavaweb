import { Grid, ProductCard } from "@/components/cards";
import { LinkButton } from "@/components/ui/Button";
import { EmptyState, PageHeader } from "@/components/ui/misc";
import { listProducts } from "@/lib/data/public";

export const metadata = { title: "Produk lokal", description: "Seafood, oleh-oleh, kerajinan, dan produk UMKM Sukabumi Selatan." };

export default async function Page({ searchParams }: { searchParams: Promise<{ cursor?: string }> }) {
  const { cursor } = await searchParams;
  const { items, nextCursor } = await listProducts({ cursor: cursor ?? null });
  return (
    <div className="wadah py-8">
      <PageHeader title="Produk lokal" text="Hubungi penjual langsung lewat WhatsApp." />
      {items.length === 0 ? <EmptyState title="Belum ada produk" /> : <Grid cols={4}>{items.map((p) => <ProductCard key={p.id} p={p} />)}</Grid>}
      {nextCursor && <div className="mt-8 text-center"><LinkButton variant="garis" href={`/produk?cursor=${encodeURIComponent(nextCursor)}`}>Muat lebih banyak</LinkButton></div>}
    </div>
  );
}
