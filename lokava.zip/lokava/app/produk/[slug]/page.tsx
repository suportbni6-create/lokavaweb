import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Gallery } from "@/components/cards/Gallery";
import { WaButton } from "@/components/cards/WaButton";
import { Badge } from "@/components/ui/misc";
import { getProductBySlug } from "@/lib/data/public";
import { appUrl } from "@/lib/env";
import { formatRupiah } from "@/lib/utils/format";

export const revalidate = 60;
type P = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: P): Promise<Metadata> {
  const r = await getProductBySlug((await params).slug);
  if (!r) return { title: "Produk tidak ditemukan" };
  return { title: `${r.product.name} — ${r.business.name}`, description: (r.product.description || r.business.description).slice(0, 155), alternates: { canonical: `/produk/${r.product.slug}` }, openGraph: { images: r.product.images[0] ? [r.product.images[0].url] : undefined } };
}

export default async function Page({ params }: P) {
  const r = await getProductBySlug((await params).slug);
  if (!r) notFound();
  const { product: p, business: b } = r;
  const ld = { "@context": "https://schema.org", "@type": "Product", name: p.name, description: p.description, image: p.images.map((i) => i.url), url: `${appUrl()}/produk/${p.slug}`, offers: { "@type": "Offer", priceCurrency: "IDR", price: p.price, availability: p.availability === "habis" ? "https://schema.org/OutOfStock" : "https://schema.org/InStock", seller: { "@type": "Organization", name: b.name } } };
  return (
    <div className="wadah py-8">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ld).replace(/</g, "\\u003c") }} />
      <div className="grid gap-8 lg:grid-cols-2">
        <Gallery cover={p.images[0] ?? null} images={p.images} name={p.name} />
        <div className="space-y-4">
          <h1 className="judul text-3xl font-semibold">{p.name}</h1>
          <p className="text-2xl font-bold text-samudra-800">{formatRupiah(p.price)}</p>
          <div className="flex gap-2"><Badge tone={p.availability === "tersedia" ? "hijau" : "kuning"}>{p.availability === "tersedia" ? "Tersedia" : p.availability === "habis" ? "Habis" : "Pesan dulu"}</Badge></div>
          {p.description && <p className="whitespace-pre-line text-samudra-800">{p.description}</p>}
          <div className="kartu p-4 text-sm"><p>Dijual oleh <Link className="font-semibold text-toska-700 hover:underline" href={`/bisnis/${b.slug}`}>{b.name}</Link></p><p className="text-samudra-600">{b.village}, {b.district}</p></div>
          {b.whatsapp && <div className="flex flex-wrap gap-2"><WaButton number={b.whatsapp} intent="harga" productName={p.name} businessName={b.name} /><WaButton number={b.whatsapp} intent="ketersediaan" productName={p.name} businessName={b.name} /></div>}
        </div>
      </div>
    </div>
  );
}
