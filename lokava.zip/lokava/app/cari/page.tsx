import type { Metadata } from "next";
import { BusinessCard, DestinationCard, Grid, ProductCard, Section } from "@/components/cards";
import { EmptyState, PageHeader } from "@/components/ui/misc";
import { getCategories, getRegions, searchAll } from "@/lib/data/public";

export const metadata: Metadata = { title: "Pencarian", robots: { index: false } };
type SP = { q?: string; kategori?: string; district?: string; min?: string; max?: string; verified?: string; promo?: string };

export default async function Page({ searchParams }: { searchParams: Promise<SP> }) {
  const sp = await searchParams;
  const q = (sp.q ?? "").slice(0, 80);
  const [cats, regions] = await Promise.all([getCategories(), getRegions()]);
  const num = (v?: string) => (v && /^\d+$/.test(v) ? Number(v) : undefined);
  const r = q.trim() || sp.kategori || sp.district ? await searchAll({ q, categoryId: sp.kategori || undefined, district: sp.district || undefined, minPrice: num(sp.min), maxPrice: num(sp.max), verified: sp.verified === "1", promoted: sp.promo === "1" }) : null;
  const total = r ? r.businesses.length + r.products.length + r.destinations.length : 0;
  return (
    <div className="wadah py-8">
      <PageHeader title="Pencarian" />
      <form role="search" className="kartu mb-8 grid gap-3 p-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="sm:col-span-2 lg:col-span-4"><label className="label" htmlFor="q">Kata kunci</label><input id="q" name="q" defaultValue={q} className="input" placeholder="Nama tempat, bisnis, produk, seafood…" /></div>
        <div><label className="label" htmlFor="kategori">Kategori</label><select id="kategori" name="kategori" defaultValue={sp.kategori ?? ""} className="input"><option value="">Semua</option>{cats.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></div>
        <div><label className="label" htmlFor="district">Kecamatan</label><select id="district" name="district" defaultValue={sp.district ?? ""} className="input"><option value="">Semua</option>{[...new Set(regions.map((x) => x.district))].map((d) => <option key={d} value={d}>{d}</option>)}</select></div>
        <div><label className="label" htmlFor="min">Harga produk min (Rp)</label><input id="min" name="min" inputMode="numeric" defaultValue={sp.min} className="input" /></div>
        <div><label className="label" htmlFor="max">Harga produk maks (Rp)</label><input id="max" name="max" inputMode="numeric" defaultValue={sp.max} className="input" /></div>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="verified" value="1" defaultChecked={sp.verified === "1"} className="h-5 w-5" /> Hanya terverifikasi</label>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="promo" value="1" defaultChecked={sp.promo === "1"} className="h-5 w-5" /> Sedang dipromosikan</label>
        <button className="min-h-11 rounded-xl bg-samudra-700 px-5 text-sm font-semibold text-white sm:col-span-2 lg:col-span-1 lg:col-start-4">Cari</button>
      </form>
      {!r ? <EmptyState title="Mulai mencari" text="Ketik kata kunci atau pilih kategori dan kecamatan." /> : total === 0 ? <EmptyState title="Tidak ada hasil" text="Coba kata kunci yang lebih singkat atau hapus beberapa filter." /> : (
        <>
          {r.destinations.length > 0 && <Section title="Wisata"><Grid>{r.destinations.map((d) => <DestinationCard key={d.id} d={d} />)}</Grid></Section>}
          {r.businesses.length > 0 && <Section title="Bisnis"><Grid>{r.businesses.map((b) => <BusinessCard key={b.id} b={b} cats={cats} />)}</Grid></Section>}
          {r.products.length > 0 && <Section title="Produk"><Grid cols={4}>{r.products.map((p) => <ProductCard key={p.id} p={p} />)}</Grid></Section>}
        </>
      )}
    </div>
  );
}
