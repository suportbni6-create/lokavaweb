import { Suspense } from "react";
import { LoginForm } from "@/components/forms/AuthForms";

export const metadata = { title: "Masuk", robots: { index: false } };

export default function Page() {
  return <Suspense><LoginForm /></Suspense>;
}
