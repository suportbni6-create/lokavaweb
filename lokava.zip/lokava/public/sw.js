/* LOKAVA service worker. Strategi aman:
 *  - Halaman: jaringan dulu, jika offline tampilkan /offline.
 *  - Aset statis Next & ikon: cache dulu.
 *  - Foto Cloudinary publik: stale-while-revalidate, maksimal 80 entri.
 *  - TIDAK PERNAH menyimpan: /api, /dashboard, /admin, permintaan non-GET, atau respons bertanda private/no-store. */
const VERSION = "lokava-v1";
const STATIC = `${VERSION}-static`;
const IMAGES = `${VERSION}-img`;
const PRECACHE = ["/offline", "/icons/icon-192.png", "/icons/icon-512.png"];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(STATIC).then((c) => c.addAll(PRECACHE)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => !k.startsWith(VERSION)).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});

const PRIVATE = /^\/(api|dashboard|admin)(\/|$)/;

self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);

  if (url.origin === self.location.origin) {
    if (PRIVATE.test(url.pathname)) return; // langsung ke jaringan
    if (url.pathname.startsWith("/_next/static/") || url.pathname.startsWith("/icons/")) {
      e.respondWith(caches.open(STATIC).then(async (c) => (await c.match(req)) || fetch(req).then((r) => { if (r.ok) c.put(req, r.clone()); return r; })));
      return;
    }
    if (req.mode === "navigate") {
      e.respondWith(fetch(req).catch(() => caches.match("/offline")));
    }
    return;
  }

  if (url.hostname === "res.cloudinary.com" && !url.pathname.includes("/authenticated/") && !url.pathname.includes("/private/")) {
    e.respondWith(caches.open(IMAGES).then(async (c) => {
      const hit = await c.match(req);
      const net = fetch(req).then(async (r) => {
        if (r.ok && !/private|no-store/.test(r.headers.get("cache-control") || "")) {
          await c.put(req, r.clone());
          const keys = await c.keys();
          if (keys.length > 80) await c.delete(keys[0]);
        }
        return r;
      }).catch(() => hit);
      return hit || net;
    }));
  }
});
